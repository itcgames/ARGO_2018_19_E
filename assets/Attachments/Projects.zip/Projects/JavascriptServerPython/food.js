

class Food
{
  constructor(img, imgSpark)
  {
    this.x = (Math.random() * 800) + 1
    this.y = (Math.random() * 1400) + 60
    this.lastX = 0
    this.lastY = 0
    this.width = 50
    this.height = 50
    this.image = new Image()
    this.image.src = img
  //  this.PartImage = new Image()
    //this.PartImage.src = imgSpark
  //  this.ps = new SparkSystem(this.x,this.y - 80,this.PartImage)
  //  this.startAnime = false

  }

  updateFromNet(x,y)
  {
    this.x = x
    this.y = y
  }
  update()
  {
    console.log(this.lastX + ", " + this.lastY)

  }
  setPosition()
  {
    this.x = (Math.random() * 900) + 1
    this.y = (Math.random() * 1500) + 1
  }

  getPosition()
  {
    return [this.x, this.y]
  }

  render()
  {
    var canvas = document.getElementById("mycanvas")
    var ctx = canvas.getContext("2d")
    ctx.fillStyle ="#FFFFFF"
    ctx.drawImage(this.image, this.x, this.y, this.width, this.height)
  //  if (this.ps.count >= 20)
    //{
    //  this.ps.count = 0;
     //this.startAnime = false
  //  }
  //  if (this.startAnime === true)
    // {
        //if (this.ps.count <= 20)
      //  {
      //      this.ps.addParticle()
        //}
    //    this.ps.run()
     //}

  }

}
