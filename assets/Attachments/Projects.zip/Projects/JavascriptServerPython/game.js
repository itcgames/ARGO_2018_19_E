

class Game
{
  constructor(load)
  {
    this.ws = new WebSocket("ws://149.153.106.130:8080/wstest")
    this.player = new Player(100,100,100,100, load['TrumpImg'])
    this.otherPlayer = new Player(0,0,100,100, load['TrumpImg'])
    this.food = new Food(load['CashImg'], load["SparkImg"])
    this.timer = new Timer(400,60)
    this.background = new Image()
    this.background.src = load["FloorImg"]
    this.drawSecond = false
    this.index = 1
    gameNs.ws = this.ws
    this.time = null
    this.currentX = 0;
    this.currentY = 0;
    this.playersIngame = 0;
    this.previousTime = Date.now();
    this.startTimerForOne = false
    this.startTimerForTwo = false
    this.reset = false
    this.newPosX = 0
    this.newPosY = 0
    this.VecX = 0
    this.VecY = 0
    this.otherPosX = 0
    this.otherPosY = 0
  }

  initWorld()
  {
    console.log("Initialising Game World");
    gameNs.ws.addEventListener('message', this.handleMessage.bind(this))
    var gameOverBtn = document.getElementById("game")
    var joinButton = document.getElementById("join")
    joinButton.addEventListener("click",this.join.bind(this))
    gameOverBtn.addEventListener("click", this.gameOver.bind(this))
    document.addEventListener("keydown", this.keyDownHandler.bind(this));
		this.update = this.update.bind(this);

    document.addEventListener("touchstart", this.onTouchStart.bind(this), false);
    document.addEventListener("touchmove", this.onTouchMove.bind(this), false);
    document.addEventListener("touchend", this.onTouchEnd.bind(this), false);
    this.player.setScoreText(10,60)

    this.seconds = 0;
    this.minutes = 0;
    this.secHolder = 0;
    //this.otherPlayer.setScoreText(600,60)

  }
  handleMessage(evt)
  {
    var msg = JSON.parse(evt.data)
    //console.log(msg.type);
    //this.updateFromNet(msg.data)


    if (msg.type === "updateState")
    {
      //console.log(msg.data)
      this.otherPosX = msg.data[0]
      this.otherPosY = msg.data[1]
      this.otherPlayer.updateFromNet(msg.data[0], msg.data[1], msg.data[2], msg.data[3])
    }
    else if (msg.type === "updateNewPos")
    {
      //console.log(msg.data)
      this.otherPlayer.updateNew(msg.data[0], msg.data[1])
    }
    else if (msg.type === "updateScore")
    {
      this.otherPlayer.scoreFromNet(msg.data)
    }
    else if (msg.type === "updateFood")
    {
      //console.log(msg.data[0] + ", " + msg.data[1])
      this.food.updateFromNet(msg.data[0], msg.data[1])
    }
    else if (msg.type === "updateSeconds")
    {
      this.timer.timeFromNet(msg.data)
    }
    else if (msg.type === "updateMinutes")
    {
      this.timer.minutesFromNet(msg.data)
    }
    else if (msg.type === "Winner")
    {
      this.reset = true
      alert(msg.data);
      //this.timer.resetTime();
    }
    else if (msg.type === "join")
    {
      //console.log(msg.data)
      if (msg.data >= 1){
      this.player.setPosition(500,500)
      this.timer.startTimer = true
      this.otherPlayer.setScoreText(700,60)
      }
      else
      {
        this.otherPlayer.setScoreText(700,60)
      }
      this.update()
      console.log("join")
    }
    else
    {
      alert(msg.data);
    }
  }

  interpolate()
  {
    this.newPosX = this.player.getX() + (this.VecX / 60)
    this.newPosY = this.player.getY() + (this.VecY / 60)

    var message = {}
    //update position message for the player
    message.type = "updateNewPos"
    message.data = [this.newPosX, this.newPosY]
    //console.log(this.player.getPosition())
    if (gameNs.ws.readyState === gameNs.ws.OPEN)
    {
      gameNs.ws.send(JSON.stringify(message));
    }

  //this.player.setPosition(this.newPosX, this.newPosY)
  }



  update()
  {

    var now = Date.now();
    var dt = (now - this.previousTime);

    this.timer.checkWinner(this.player.getScore(), this.otherPlayer.getScore())

    this.previousTime = now;
    //timer for the game
    //this.gameTimer()
    this.interpolate()

    window.requestAnimationFrame(gameNs.game.update);
    var message = {}
    //update position message for the player
    message.type = "updateState"
    message.data = this.player.getPosition()
    //console.log(this.player.getPosition())
    if (gameNs.ws.readyState === gameNs.ws.OPEN)
    {
      gameNs.ws.send(JSON.stringify(message));
    }
    //update score message for the player
    message.type = "updateScore"
    message.data = this.player.getScore()
    if (gameNs.ws.readyState === gameNs.ws.OPEN)
    {
      gameNs.ws.send(JSON.stringify(message));
    }
    //checks the player collision with the money
    if (this.player.checkCollision(this.food))
    {
      this.player.addScore()
      this.food.setPosition()
      //update position of money message
      message.type = "updateFood"
      message.data = this.food.getPosition()
      if (gameNs.ws.readyState === gameNs.ws.OPEN)
      {
        gameNs.ws.send(JSON.stringify(message));
      }
    }
    //passes the current x and y positions of the touch position to the player
    this.player.update(dt, this.currentX, this.currentY);
    this.timer.update(dt)


    this.VecX = this.player.getX() - this.otherPosX
    this.VecY = this.player.getY() - this.otherPosY

    if (this.reset === true)
    {
      this.player.setScore()
      this.otherPlayer.setScore()
      this.timer.resetTime()
      this.reset = false
    }
    this.render()
  }

  onTouchStart(e)
  {
     this.touches = e.touches;
     this.time = new Date().getTime()
	   this.startX = this.touches[0].clientX;
	   this.startY = this.touches[0].clientY;
     this.currentX = this.startX
     this.currentY = this.startY
  }
  onTouchMove(e)
  {
    this.touches = e.changedTouches;

	   this.endX = this.touches.clientX;
	   this.endY = this.touches.clientY;

	   this.startX = this.touches.clientX;
	   this.startY = this.touches.clientY;
  }
  onTouchEnd(e)
  {
     var minTime = 500;
     var maxTime = 2000;
     var minDistance = 50;
     var length;
     var time2 = new Date().getTime()

     var time = time2 - this.time;
	   this.endX = this.touches[0].clientX;
 	   this.endY = this.touches[0].clientY;
     length = Math.sqrt(((this.endX - this.currentX)* (this.endX - this.currentX)) + ((this.endY - this.currentY) * (this.endY - this.currentY)))
     //console.log(length)

     if (length < minDistance || time > maxTime || time < minTime)
	   {
	       this.player.move();
	   }
  }




  join()
  {
    this.playersIngame += 1
    //console.log(this.index)
    var message = {}
    message.type = "join"
    message.data = this.index
    if (gameNs.ws.readyState === gameNs.ws.OPEN)
    {
      gameNs.ws.send(JSON.stringify(message));
    }
  }
  gameOver()
  {
    var message = {}
    console.log("pressed")
    message.type = "gameOver"
    if (gameNs.ws.readyState === gameNs.ws.OPEN)
    {
      gameNs.ws.send(JSON.stringify(message));
    }
  }



  render()
  {
    var canvas = document.getElementById("mycanvas");
		var ctx = canvas.getContext("2d");
    ctx.clearRect(0,0,canvas.width, canvas.height);
    ctx.drawImage(this.background, -100 ,-100, 1100, 2000)
		this.player.render();
    this.food.render()
    this.otherPlayer.render();
    this.timer.render()
    //this.gameTimer()
    ctx.font = '55px Arial';
    ctx.fillStyle ="#FFFFFF"
    //ctx.fillText(this.minutes + ": " + this.secHolder, 400, 60)
  }

  keyDownHandler(e)
	{
		var canvas = document.getElementById("mycanvas");
		var ctx = canvas.getContext("2d");



		if(e.keyCode === 38)
		{
			this.player.moveUp();
		}
		if(e.keyCode === 37)
		{
			this.player.moveLeft();
		}
		if(e.keyCode === 39)
		{
			this.player.moveRight();
		}
		if(e.keyCode === 40)
		{
			this.player.moveDown();
		}
  }


}
