

class Timer
{
  constructor(x,y)
  {
    this.x = x
    this.y = y
    this.textX = 0
    this.textY = 0
    this.seconds = 0
    this.minutes = 0
    this.secholder = 0
    this.startTimer = false
    }

  render()
  {
    var canvas = document.getElementById("mycanvas")
    var ctx = canvas.getContext("2d")
    ctx.font = '55px Arial';
    ctx.fillStyle ="#FFFFFF"
    ctx.fillText(this.minutes + ": " + this.secHolder, this.x, this.y)
  }
  update(dt)
  {
    if (this.startTimer === true)
    {
      var message = {}
      this.seconds = this.seconds + 1;

      // Wrapping the seconds back around to 0 once it reaches a minute
      if (Math.trunc(this.seconds/60) >= 60 && Math.trunc(this.seconds/60) <= 61)
      {
        this.seconds = 0;
        this.minutes += 1;
      }

      this.secHolder = Math.trunc(this.seconds/60) //A variable thats assigned the seconds to calculate the minutes

      message.type = "updateSeconds"
      message.data = this.secHolder
      if (gameNs.ws.readyState === gameNs.ws.OPEN)
      {
        gameNs.ws.send(JSON.stringify(message));
      }
      message.type = "updateMinutes"
      message.data = this.minutes
      if (gameNs.ws.readyState === gameNs.ws.OPEN)
      {
        gameNs.ws.send(JSON.stringify(message));
      }
    }
  }

  checkWinner(first, second)
  {
    var message = {}

    if (this.minutes >= 1){
      this.stopTimer = true
      if (first > second)
      {
        message.type = "Winner"
        message.data = "You Win"
        if (gameNs.ws.readyState === gameNs.ws.OPEN)
        {
          gameNs.ws.send(JSON.stringify(message));
        }
      }
      // else if (second > first)
      // {
      //   message.type = "Winner"
      //   message.data = "You Win"
      //   if (gameNs.ws.readyState === gameNs.ws.OPEN)
      //   {
      //     gameNs.ws.send(JSON.stringify(message));
      //   }
      // }
    }

  }
  resetTime()
  {
    this.secHolder = 0
    this.minutes = 0
  }

  timeFromNet(time)
  {
    this.secHolder = time
  }

  minutesFromNet(time)
  {
    this.minutes = time
  }
}
