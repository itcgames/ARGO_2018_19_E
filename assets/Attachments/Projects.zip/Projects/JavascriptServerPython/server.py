
from tornado import websocket, web, ioloop, httpserver
import tornado
import json

session = {}
WAITING_FOR_PLAYERS=0
GAME_IN_PROGRESS=1
game_state=WAITING_FOR_PLAYERS

class WSHandler(tornado.websocket.WebSocketHandler):

    def check_origin(self, origin):
        return True

    def open(self):
        session[self.get_player_address()] = self
        print("connection opened")
        pass


    def on_message(self, message):
        #message = {}
        print(self.request.remote_ip)
        print(self.stream.socket.getpeername()[1])
        #self.write_message(message)
        #print(game_state)
        msg = json.loads(message)
        if (msg["type"] == "join"):
            print(msg)
            #self.write_message(msg)
            self.join()
        if (msg["type"] == "gameOver"):
            self.gameOver()
        if (msg["type"] == "updateState"):
            print (msg["data"])
            self.send_to_other_player(msg)
        if (msg['type'] == "updateScore"):
            self.send_to_other_player(msg)
        if (msg['type'] == "updateFood"):
            self.send_to_other_player(msg)
        if (msg['type'] == "Winner"):
            self.write_message(msg)
        if (msg['type'] == "updateSeconds"):
            self.send_to_other_player(msg)
        if (msg['type'] == "updateMinutes"):
            self.send_to_other_player(msg)
        if (msg['type'] == "updateNewPos"):
            self.send_to_other_player(msg)

    def gameOver(self):
        msg = {}
        num = len(session)
        print("game over")
        if num >= 1:
            game_state=WAITING_FOR_PLAYERS
            msg["data"] = "gameOver"
            self.send_to_other_player(msg)
            self.write_message(msg)
            session.clear()


    def join(self):
        msg = {}
        num = len(session)
        print(num)
        if (num < 2):
            session[self.get_player_address()] = self
            game_state=GAME_IN_PROGRESS
            msg["type"] = "join"
            msg["data"] = num
            self.write_message(msg)
            print("executed")
        else:
            msg["type"] = "error"
            msg["data"] = "No available space: Two players already in the game!"
            self.write_message(msg)

    def format_message(self,type,data):
        pass


    def get_player_address(self):
        player_address = (str(self.request.remote_ip) + ':'+ str(self.stream.socket.getpeername()[1]))
        return player_address

    def send_to_other_player(self, message):
        for key, value in session.items():
            if(key != self.get_player_address()):
                #try:
                value.write_message(message)
                #except Exception:
                   # del session[key]
                   #print("Problem writing to socket")



    def on_close(self):
        pass

app= tornado.web.Application([
        	#map the handler to the URI named "test"
            (r'/wstest', WSHandler),
])

if __name__ == '__main__':
    server_port=8080
    app.listen(server_port)
    ioloop.IOLoop.instance().start()
