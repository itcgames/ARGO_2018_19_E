

class Player
{
  constructor(x,y,width,height, image)
  {
    this.id = 0
    this.x = x
    this.y = y
    this.textX = 0
    this.textY = 0;
    this.img = new Image()
    this.img.src = image
    this.width = width
    this.height = height
    this.score = 0
    this.movePlayer = false;
    this.fps = 10
    this.count = 0
    this.time = 0
    this.tickPerFrame = 1000 / this.fps
    this.movingRight = false;
    this.movingLeft = false;
    this.movingUp = false;
    this.movingDown = false;
    this.direction = 1
    this.secHolder = 0
  }

  render()
  {
    var canvas = document.getElementById("mycanvas")
    var ctx = canvas.getContext("2d")
    ctx.font = '55px Arial';
    ctx.fillStyle ="#FFFFFF"
    ctx.fillText("Score: " + this.score, this.textX, this.textY)
    if (this.direction === 0)
    ctx.drawImage(this.img, this.count * 200, 500, 200, 215, this.x, this.y, 200, 215);
    // else if (this.movingLeft === true)
    // ctx.drawImage(this.img, this.count * 200, 750, 200, 215, this.x, this.y, 200, 215);
    // else if (this.movingRight === true)
    // ctx.drawImage(this.img, this.count * 200, 250, 200, 215, this.x, this.y, 200, 215);
    else if (this.direction === 1)
    ctx.drawImage(this.img, this.count * 200, 0, 200, 215, this.x, this.y, 200, 215);
  }
  update(dt, curX, curY)
  {

      if(dt != null)
      {
          this.time += dt;
      }

          //changes position of x of the spritesheet
      if(this.tickPerFrame < this.time)
      {
          this.count +=1;
      if(this.count > 5)
      {
          this.count = 0;
      }
              this.time =0;
          }
      //console.log(curX  + ", " + curY)
      if (this.movePlayer === true)
      {
         if (this.x + 100> curX)
         {
           this.moveLeft()
         }
         if (this.x + 100< curX)
         {
           this.moveRight()
         }
         if (this.y +200> curY)
         {
           this.moveUp()
         }
         if (this.y  +50< curY)
         {
           this.moveDown()
         }
     }


  }
  setId(num)
  {
    this.id = num
  }
  checkCollisionBetween(x,y,width,height)
 {
   var collides = false;

   if ((this.x < x + width) &&
       (this.x + this.width > x) &&
       (this.y + this.height > y) &&
       (this.y< y + height))
   {
     collides = true;
   }
   return collides;
 }

  scoreFromNet(score)
  {
    this.score = score
  }


  setScore()
  {
    this.score = 0
  }

  getScore()
  {
    return this.score;
  }

  setScoreText(x, y)
  {
    this.textX = x
    this.textY = y
  }

  updateFromNet(x,y, current, count)
  {
    this.x = x
    this.y = y
    this.direction = current
    this.count = count
  }
  /**
	* subtracts 10 to the y co-ordinate
	*/
	moveUp()
	{
		this.y -= 3;
    this.direction = 0;
	}
/**
 * subtracts 10 to the x co-ordinate
 */
	moveLeft()
	{
		this.x -= 3;

	}
/**
 * adds 10 to the x co-ordinate
 */
	moveRight()
	{
		this.x += 3;
	}
/**
	* adds 10 to the y co-ordinate
	*/
	moveDown()
	{
		this.y += 3;
    this.direction = 1
	}

  move()
  {
    this.movePlayer = true
  }

  getPosition()
  {
    return [this.x, this.y, this.direction, this.count]
  }
  setPosition(x,y)
  {
    this.x = x
    this.y = y
  }

  updateNew(x, y)
  {
    this.x = x
    this.y = y
  }

  checkCollision(e)
	{
		var collides = false;

		if ((this.x < e.x + e.width) &&
				(this.x + this.width > e.x) &&
				(this.y + this.height > e.y) &&
				(this.y < e.y + e.height))
		{
			collides = true;

		}
		return collides;
	}

  addScore()
  {
    this.score += 10
  }

  getX()
  {
    return this.x
  }

  getY()
  {
    return this.y
  }
}
