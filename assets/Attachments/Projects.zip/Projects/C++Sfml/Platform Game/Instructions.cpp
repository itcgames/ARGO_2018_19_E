#include "Header\Instructions.h"



Instructions::Instructions(Game & game, sf::Font font, KeyHandler & key) :
	m_game(&game),
	m_keyhandler(key),
	m_font(font)
{
	//sdetting up arrow sprites
	//left
	m_arrowBtnsTexture[0].loadFromFile("resources/images/leftarrow.png");
	m_arrowBtns[0].setTexture(m_arrowBtnsTexture[0]);
	m_arrowBtns[0].setPosition(50, 200);

	//right
	m_arrowBtnsTexture[1].loadFromFile("resources/images/rightarrow.png");
	m_arrowBtns[1].setTexture(m_arrowBtnsTexture[1]);
	m_arrowBtns[1].setPosition(550, 290);
	m_arrowBtns[1].setScale(.75, .75);

	//up
	m_arrowBtnsTexture[2].loadFromFile("resources/images/uparrow.png");
	m_arrowBtns[2].setTexture(m_arrowBtnsTexture[2]);
	m_arrowBtns[2].setPosition(1300, 600);
	m_arrowBtns[2].setScale(.35, .25);

	//down
	m_arrowBtnsTexture[3].loadFromFile("resources/images/downarrow.png");
	m_arrowBtns[3].setTexture(m_arrowBtnsTexture[3]);
	m_arrowBtns[3].setPosition(1500, 570);
	m_arrowBtns[3].setScale(.55, .70);

	//up again because it needs a duplicate
	m_arrowBtns[4].setTexture(m_arrowBtnsTexture[2]);
	m_arrowBtns[4].setPosition(1400, 200);
	m_arrowBtns[4].setScale(.35, .25);

	//shader set up
	m_blankTexture.loadFromFile("resources/images/blank.png");
	m_blankSprite.setTexture(m_blankTexture);
	m_blankSprite.setScale(2, 1.5);

	//set up text objects
	m_arrows[0].setFont(m_font);
	m_arrows[0].setCharacterSize(100);
	m_arrows[0].setPosition(200, 30);
	m_arrows[0].setFillColor(sf::Color(0,0,0));
	m_arrows[0].setString("Navigation");

	// jumping title
	m_arrows[1].setFont(m_font);
	m_arrows[1].setCharacterSize(100);
	m_arrows[1].setPosition(1300, 30);
	m_arrows[1].setFillColor(sf::Color(0, 0, 0));
	m_arrows[1].setString("Jumping");

	m_arrows[2].setFont(m_font);
	m_arrows[2].setCharacterSize(50);
	m_arrows[2].setPosition(250, 700);
	m_arrows[2].setFillColor(sf::Color(0, 0, 200));
	m_arrows[2].setString("Left and Right arrow keys");

	m_arrows[3].setFont(m_font);
	m_arrows[3].setCharacterSize(50);
	m_arrows[3].setPosition(1400, 475);
	m_arrows[3].setFillColor(sf::Color(0, 0, 200));
	m_arrows[3].setString("Single jump");

	m_arrows[4].setFont(m_font);
	m_arrows[4].setCharacterSize(50);
	m_arrows[4].setPosition(1400, 875);
	m_arrows[4].setFillColor(sf::Color(0, 0, 200));
	m_arrows[4].setString("Power jump");

	//Screen divider
	m_divider.setFillColor(sf::Color(0, 0, 0));
	m_divider.setPosition(1000, 100);
	m_divider.setSize(sf::Vector2f(800, 10));
	m_divider.setRotation(90);

	//return messsage
	m_returnText.setFont(m_font);
	m_returnText.setCharacterSize(50);
	m_returnText.setPosition(475, 980);
	m_returnText.setFillColor(sf::Color(0, 0, 200));
	m_returnText.setString("( Press backspace to return to the main menu )");


	if (!m_skyShader.loadFromFile("sky.frag", sf::Shader::Fragment))
	{
		std::cout << "shader not loaded" << std::endl;
	}

	m_skyShader.setUniform("time", 0.0f);
	m_skyShader.setUniform("resolution", sf::Vector2f(2000, 700));

	m_blankSprite.setPosition(0, 0);
}


Instructions::~Instructions()
{
}

void Instructions::update(sf::Time dt)
{
	if (m_keyhandler.isPressed(sf::Keyboard::BackSpace))
	{
		m_game->setGameState(GameState::MainMenu);
	}
}

void Instructions::render(sf::RenderWindow & window)
{

	//drawing shader
	window.draw(m_blankSprite, &m_skyShader);

	//drwaing arrows
	for (int i = 0; i <= 4; i++)
	{
		window.draw(m_arrowBtns[i]);
	}

	window.draw(m_arrows[0]);
	window.draw(m_arrows[1]);
	window.draw(m_arrows[2]);
	window.draw(m_arrows[3]);
	window.draw(m_arrows[4]);
	window.draw(m_divider);
	window.draw(m_returnText);
}

void Instructions::menuControl()
{

}