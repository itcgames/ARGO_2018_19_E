#include "Header/ParticleSystem.h"



ParticleSystem::ParticleSystem(sf::Vector2f& position):
	m_position(position)
{
}


ParticleSystem::~ParticleSystem()
{
}

void ParticleSystem::addParticle()
{
	auto particle = new Particle(m_position);
	//m_particles->push_back(particle);
}

void ParticleSystem::render(sf::RenderWindow& window)
{
	
	/*for (std::list<Particle>::const_iterator i = m_particles->cbegin(); i != m_particles->cend(); i++)
	{
		i->run();
		if (i->isDead())
		{
			m_particles->remove();
		}
	}*/

	for (int i = 0; i < m_particles->size(); i++)
	{
		//m_particles[i]
	}

}
