#include "Header/Splash.h"
#include <iostream>

Splash::Splash(Game & game, sf::Font font) :
	m_game(&game),
	m_font(font)

{
	texture.loadFromFile("resources/images/Splash.png");
	splashSprite.setTexture(texture);
	text.setFont(m_font);
	text.setString("The Great Escape");
	text.setFillColor(sf::Color::Red);
	text.setOutlineColor(sf::Color::Black);
	text.setOutlineThickness(10);
	text.setPosition(250, 100);
	text.setCharacterSize(200);

	m_shderTexture.loadFromFile("resources/images/blank.png");
	m_shaderSprite.setTexture(m_shderTexture);
	m_shaderSprite.setScale(2, 1.5);
	if (!m_shader.loadFromFile("ShaderGrass.frag", sf::Shader::Fragment))
	{
		std::cout << "shader not loaded" << std::endl;
	}
	m_shader.setUniform("time", 0.0f);
	m_shader.setUniform("resolution", sf::Vector2f(2000, 700));

	m_shaderSprite.setPosition(0, 0);
}

Splash::~Splash()
{
	std::cout << "destructing Splash" << std::endl;

}


void Splash::update(sf::Time deltaTime)
{
	time += deltaTime;
	m_cumulativeTime += deltaTime;
	
	m_shaderTime += deltaTime;
	m_updateShader = m_shaderTime.asSeconds();
	m_shader.setUniform("time", m_updateShader);
	

	if (time.asSeconds() > 3)
	{
		m_game->setGameState(GameState::MainMenu);
	}


}

void Splash::changeState()
{

}

void Splash::render(sf::RenderWindow & window)
{

	window.clear(sf::Color::Yellow);
	//window.draw(splashSprite);
	window.draw(m_shaderSprite, &m_shader);
	window.draw(text);
}

