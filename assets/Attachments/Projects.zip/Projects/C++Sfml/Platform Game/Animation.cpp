#include "Header/Animation.h"


Animation::Animation()
{

}
Animation::Animation(sf::Texture * texture, sf::Vector2u imageCount, sf::Time switchTime, Game& game):
	m_game(&game)
{
	this->m_imageCount = imageCount;
	this->m_switchTime = switchTime;
	m_totalTime = sf::Time::Zero;
	m_currentImage.x = 0;

	m_uvRect.width = texture->getSize().x / float(imageCount.x);
	m_uvRect.height = texture->getSize().y / float(imageCount.y);
}


Animation::~Animation()
{
}

void Animation::update(int row, sf::Time deltaTime)
{
	m_currentImage.y = row;
	m_totalTime += deltaTime;

	if (m_totalTime >= m_switchTime)
	{
		m_totalTime -= m_switchTime;
		m_currentImage.x++;

		if (m_currentImage.x >= m_imageCount.x )
		{
			m_currentImage.x = 0;
		}
	}

	m_uvRect.left = m_currentImage.x * m_uvRect.width;
	m_uvRect.top = m_currentImage.y * m_uvRect.height;
}

void Animation::setCurrentImageX()
{
	m_currentImage.x = 0   ;
}
