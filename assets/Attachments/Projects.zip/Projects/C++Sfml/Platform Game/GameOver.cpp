#include "Header/GameOver.h"



GameOver::GameOver(Game & game, sf::Font font, KeyHandler & key) :
	m_game(&game),
	m_font(font),
	m_keyhandle(&key),
	m_score(0),
	m_coinsScore(0),
	m_enemiesShot(0),
	m_returnToMenu(false)
{
	m_texture.loadFromFile("./resources/images/GameOver.png");
	m_sprite.setTexture(m_texture);
	m_sprite.setPosition(0, 0);
	m_sprite.setScale(.75, .75);

	//Outputs the coin score
	m_coinTotal.setFillColor(sf::Color(0, 255, 0));
	m_coinTotal.setCharacterSize(25);
	m_coinTotal.setFont(m_font);

	// The column for coins
	m_coinTitle.setFillColor(sf::Color(0, 255, 0));
	m_coinTitle.setCharacterSize(25);
	m_coinTitle.setFont(m_font);
	m_coinTitle.setString("Coins");

	//Outputs the enemy kill count
	m_enemyTotal.setFillColor(sf::Color(0, 255, 0));
	m_enemyTotal.setCharacterSize(25);
	m_enemyTotal.setFont(m_font);


	//The enemy kill count column
	m_enemyTitle.setFillColor(sf::Color(0, 255, 0));
	m_enemyTitle.setCharacterSize(25);
	m_enemyTitle.setFont(m_font);
	m_enemyTitle.setString("Enemies Killed");

	//Outputs total score
	m_totalScore.setFillColor(sf::Color(0, 255, 0));
	m_totalScore.setCharacterSize(25);
	m_totalScore.setFont(m_font);


	//The total score column
	m_titleScore.setFillColor(sf::Color(0, 255, 0));
	m_titleScore.setCharacterSize(25);
	m_titleScore.setFont(m_font);
	m_titleScore.setString("Total score");

	//prompt to continue in the game
	m_finText.setFillColor(sf::Color::Yellow);
	m_finText.setCharacterSize(20);
	m_finText.setFont(m_font);
	m_finText.setString("( Press spacebar to continue )");
}


GameOver::~GameOver()
{
	std::cout << "destroying GAMEOVER" << std::endl;
}

void GameOver::update(sf::Vector2f pos, Player &player)
{
	if (m_keyhandle->isPressed(sf::Keyboard::Space))
	{
		m_returnToMenu = true;
		m_game->initial = false;
		m_game->levelSet = false;
		player.m_caught = false;
		m_game->setGameState(GameState::MainMenu);
	}

	m_sprite.setPosition(pos.x - 650, pos.y -450);

	//coin scoring and positions
	m_coinsScore = m_game->GetCoins();
	m_coinTotal.setString(std::to_string(m_coinsScore));
	m_coinTotal.setPosition(pos.x-410, pos.y + 40);
	m_coinTitle.setPosition(pos.x-425, pos.y);

	//enemy scoring and positions
	m_enemiesShot = m_game->GetDeadEnemies() * 5;
	m_enemyTotal.setString(std::to_string(m_enemiesShot));
	m_enemyTotal.setPosition(pos.x-250, pos.y + 40);
	m_enemyTitle.setPosition(pos.x-300, pos.y);
	
	// continue prompt position
	m_finText.setPosition(pos.x - 275, pos.y - 50);

	//the total score and positions
	if (m_enemiesShot == 0)
	{
		m_score = m_coinsScore;
	}
	else
	{
		m_score = (m_coinsScore * m_enemiesShot);
	}
	
	m_totalScore.setString(std::to_string(m_score));
	m_totalScore.setPosition(pos.x +50, pos.y + 40);
	m_titleScore.setPosition(pos.x , pos.y);

	winOrLose();
	
}

void GameOver::render(sf::RenderWindow &window)
{
	window.draw(m_sprite);
	window.draw(m_titleScore);
	window.draw(m_coinTitle);
	window.draw(m_enemyTitle);
	window.draw(m_coinTotal);
	window.draw(m_totalScore);
	window.draw(m_enemyTotal);
	window.draw(m_finText);
}

void GameOver::winOrLose()
{
	if (m_game->checkLoser() == true)
	{
		//m_texture.loadFromFile("./resources/images/GameOver.png");
		m_sprite.setTexture(m_texture);
	}
	if (m_game->checkWinner() == true)
	{
		//m_texture.loadFromFile("./resources/images/youWin.jpg");
		m_sprite.setTexture(m_texture);
	}
}

