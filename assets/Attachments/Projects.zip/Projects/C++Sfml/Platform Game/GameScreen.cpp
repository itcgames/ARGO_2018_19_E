#include "Header/GameScreen.h"
#include <iostream>

GameScreen::GameScreen(Game & game, sf::Font font, int coins) :
	m_game(&game),
	m_font(font),
	m_coins(coins),
	m_countdown(3),
	m_size(0),
	m_textRect(m_loserText.getLocalBounds()),
	m_maxSprites(3)

{
	m_portalTexture.loadFromFile("resources/images/Portal.png");
	m_portalRec.setSize(sf::Vector2f(80, 80));
	m_portalRec.setTexture(&m_portalTexture);

	//loading in the sound
	m_songBuff.loadFromFile("resources/sounds/Pim_Poy_Pocket.wav");
	m_song.setBuffer(m_songBuff);

	//m_portalRec.setPosition(800, 1000);
	m_blackText.loadFromFile("resources/images/blackTexture.png");
	m_blackSprite.setTexture(m_blackText);
	m_blackSprite.setPosition(420, 0);

	
	//m_sprite.setScale(1.2, 1.0);
	m_sprite.setPosition(0, -400);
	m_text.setFont(m_font);
	m_text.setString("");


	if (!m_shader.loadFromFile("./resources/shaders/lightning.frag", sf::Shader::Fragment))
	{
		std::cout << "Shader is not available" << std::endl;
	}
	m_shader.setUniform("time", 0.0f);
	m_shader.setUniform("resolution", sf::Vector2f(1000.0f, 800.0f));

	for (int i = 0; i < m_maxSprites; i++)
	{
		m_heartTexture.loadFromFile("./resources/images/liveHeart.png");
		m_heartSprite[i].setTexture(m_heartTexture);
		m_heartSprite[i].setScale(.2, .2);
	}
	m_tutFont.loadFromFile("resources/BAUHS93.TTF");
	m_scoreText.setFont(m_font);
	m_scoreText.setString("");
	m_scoreText.setFillColor(sf::Color::White);
	m_scoreText.setOutlineColor(sf::Color::Black);
	m_scoreText.setOutlineThickness(3);
	m_scoreText.setCharacterSize(30);
	m_countdown = 4;

	m_text.setFillColor(sf::Color::Black);
	m_text.setOutlineColor(sf::Color::Yellow);
	m_text.setOutlineThickness(2);
	m_text.setCharacterSize(120);
	
	m_timerText.setFont(m_font);
	m_timerText.setOutlineColor(sf::Color::Black);
	m_timerText.setOutlineThickness(10);
	m_timerText.setCharacterSize(35);

	m_textWin.setFont(m_font);
	m_textWin.setOutlineColor(sf::Color::Black);
	m_textWin.setOutlineThickness(10);
	m_textWin.setCharacterSize(35);
	
	m_loserText.setFont(m_font);
	m_loserText.setOutlineColor(sf::Color::Black);
	m_loserText.setOutlineThickness(10);
	m_loserText.setCharacterSize(m_size);


	m_textMessage.setFont(m_tutFont);
	m_textMessage.setString("PRESS LEFT ARROW TO MOVE LEFT!");
	m_textMessage.setOutlineColor(sf::Color::Black);
	m_textMessage.setOutlineThickness(10);
	m_textMessage.setCharacterSize(22);


		m_song.play();
	
}
void GameScreen::initBackground()
{
	if (m_game->m_currentLevel == 2)
	{
		m_texture.loadFromFile("resources/images/gameScreen.png");
	}
	else if (m_game->m_currentLevel == 1)
	{
		m_texture.loadFromFile("resources/images/tutGameScreen.png");
	}

	m_sprite.setTexture(m_texture);
}

GameScreen::~GameScreen()
{
	std::cout << "destructing Splash" << std::endl;
	
}


void GameScreen::update(sf::Time deltaTime, sf::Vector2f guiPos, sf::Vector2f playerPos)
{

	
	m_song.setLoop(true);
	m_time += deltaTime;
	m_shaderTime += deltaTime;
	updateShader = m_shaderTime.asSeconds();
	m_shader.setUniform("time", updateShader);
	m_portalRec.setOrigin(40, 40);
	m_portalRec.rotate(1);
	if (m_game->m_bulletShot == true || m_game->m_currentLevel == 2)
	{
		if (m_counting)
		{
			if (m_time.asMilliseconds() > 1000)
			{

				m_countdown--;
				m_time = sf::Time::Zero;
			}
			if (m_countdown > 0)
			{
				m_text.setString(std::to_string(m_countdown));
				m_text.setPosition(guiPos.x - 200, guiPos.y - 340);
			}
			else
			{
				m_text.setString("GO!");
				m_text.setPosition(guiPos.x - 300, guiPos.y - 340);
				m_resetTime += deltaTime;
				(m_timer) += deltaTime;
				//m_fTime = roundf(m_timer.asSeconds()*100.0f) / 100.0f;
				//trunc
				//std::cout << m_fTime << std::endl;
			}
		}
		if (m_resetTime.asMilliseconds() > 2000)
		{
			m_counting = false;
			m_timer += deltaTime;
			m_text.setString("");
		}

		//if the player has not completed the course 
		if (!m_win) {
			m_fTime = roundf(m_timer.asSeconds()*100.0f) / 100.0f;
			m_timerText.setString(std::to_string(m_fTime));
			m_timerText.setPosition(guiPos.x, guiPos.y - 300);
			m_inText = m_timer.asSeconds();
		}
		//if the player has completed the course 
		else {

			m_timerText.setString("Your Time:  " + std::to_string(m_inText));
			m_timerText.setPosition(guiPos.x - 190, guiPos.y - 300);
		}
	}

	m_scoreText.setString(std::to_string(m_game->GetCoins()) + " coins");
	m_scoreText.setPosition(guiPos.x - 480, guiPos.y - 300);

	m_posHearts = sf::Vector2f(guiPos.x - 480, guiPos.y + 50);
	for (int i = 0; i < m_maxSprites; i++)
	{
		m_heartSprite[i].setPosition(m_posHearts);
		m_posHearts.x += 50;
	}
	


	if (m_loser){
		m_game->setGameState(GameState::GameOver);
		m_textRect = m_loserText.getLocalBounds();
		m_loserText.setString("You Lose");
		m_loserText.setOrigin(m_textRect.left + m_textRect.width / 2.0f,
			m_textRect.top + m_textRect.height / 2.0f);
		m_loserText.setPosition(guiPos.x - 180, guiPos.y - 150);
		if (m_size < 100)
		m_size+=2.0f;
		m_loserText.setCharacterSize(m_size);
	}


	if (m_game->m_currentLevel == 1)
	{
		m_textMessage.setPosition(playerPos.x - 120, playerPos.y - 50);
	}
	setPortalPosition();
}
void GameScreen::setPortalPosition() {
	if (m_game->m_currentLevel == 1)
	{
		m_portalRec.setPosition(1250, 60);
	}
	if (m_game->m_currentLevel == 2)
	{
		m_portalRec.setPosition(800, 40);
	}
}
void GameScreen::render(sf::RenderWindow & window)
{	
	
	//window.draw(m_blackSprite, &m_shader);
	window.draw(m_sprite);
	window.draw(m_text);
	for (int i = 0; i < m_maxSprites; i++)
	{
		window.draw(m_heartSprite[i]);
	}
	if (m_game->m_currentLevel == 1)
	window.draw(m_textMessage);
	window.draw(m_portalRec);
}

sf::Text GameScreen::getText()
{
	return m_timerText;
}

sf::Text GameScreen::getLoserText()
{
	return m_loserText;
}

sf::Text GameScreen::getScoreText()
{
	return m_scoreText;
}


void GameScreen::retrieveWinner(bool win)
{
	m_win = win;
}

void GameScreen::retrieveLoser(bool lose)
{
	m_loser = lose;
}

void GameScreen::changeLives()
{
	m_maxSprites--;
}

void GameScreen::changeString(sf::String string)
{
	m_string = string;
	m_textMessage.setString(m_string);
}


