#include "Header/Platform.h"



Platform::Platform(Game & game, sf::Font font) :
	m_game(&game)
{
	if (!m_texture.loadFromFile("LargePlat.png"))
	{
		std::string s("error loading texture from file");
		throw std::exception(s.c_str());
	}
	m_sprite.setTexture(m_texture);
	m_sprite.setScale(.2, .1);
	m_xPos = 50;
	m_yPos = 50;

	m_posVec = { m_xPos, m_yPos };

}


Platform::~Platform()
{
}

void Platform::update()
{
	//setPosition();
}

void Platform::setPosition(float x, float y)
{
	m_posVec = { x,y };
	m_sprite.setPosition(m_posVec);
}

void Platform::render(sf::RenderWindow & window)
{
	window.draw(m_sprite);
}