#include "Header/Game.h"
#include "SFML/Audio.hpp"
#include "Header/CollisionDetector.h"

static double const MS_PER_UPDATE = 10.0;

Game::Game() :
	m_window(sf::VideoMode(1920, 1080, 32), "Platform Game"),
	m_currentGameState(GameState::Splash),
	m_coinCollection(0),
	m_enemiesShot(0)
	
	
{
	m_thumpBuffer.loadFromFile("resources/sounds/thump.wav");
	m_thumpSound.setBuffer(m_thumpBuffer);

	m_coinbuf.loadFromFile("resources/sounds/Ting.wav");
	m_coinSound.setBuffer(m_coinbuf);

	m_enemybuf.loadFromFile("resources/sounds/Pain.wav");
	m_enemySound.setBuffer(m_enemybuf);

	if (!m_texture.loadFromFile("Resources/images/platforms.png"))
	{
		std::string s("Error loading texture");
		throw std::exception(s.c_str());
	}
	
	time1 = sf::seconds(0.1f);
	//time2 = sf::seconds(0.2f);
	m_font.loadFromFile("resources/Adventure.otf");
	
	m_keyHandler = new KeyHandler();
	m_mainMenu = new MainMenu(*this, m_font, *m_keyHandler);
	m_preGame = new PreGame(*this, m_font, *m_keyHandler);
	m_gameScreen = new GameScreen(*this, m_font, m_coinCollection);
	m_player = new Player(*this, *m_keyHandler, *m_gameOver);
	m_splashScreen = new Splash(*this, m_font);
	m_instructions = new Instructions(*this, m_font, *m_keyHandler);	
	m_gameOver = new GameOver(*this, m_font, *m_keyHandler);
	m_preGame = new PreGame(*this, m_font, *m_keyHandler);
	m_splashScreen = new Splash(*this, m_font);
	m_gameOver = new GameOver(*this, m_font, *m_keyHandler);
	m_player = new Player(*this, *m_keyHandler, *m_gameOver);
	m_instructions = new Instructions(*this, m_font, *m_keyHandler);	
	m_bullet = new Bullet(*this, *m_keyHandler, *m_player);
	m_settings = new Settings(*this, m_font, *m_keyHandler);
	m_bullet = new Bullet(*this, *m_keyHandler, *m_player);
	
	
	
}

Game::~Game()
{

	std::cout << "destructing game" << std::endl;
}


/// <summary>
/// Main game entry point - runs until user 
/// </summary>
void Game::run()
{
	sf::Clock clock;
	sf::Time timeSinceLastUpdate = sf::Time::Zero;
	sf::Time timePerFrame = sf::seconds(1.f / 60.f);


	while (m_window.isOpen())
	{
		processEvents();
		timeSinceLastUpdate += clock.restart();

		while (timeSinceLastUpdate > timePerFrame)
		{
			timeSinceLastUpdate -= timePerFrame;
			update(timePerFrame);
		}
		render();
	}
}



/// <summary>
/// @brief Check for events
/// 
/// Allows window to function and exit. 
/// Events are passed on to the Game::processGameEvents() method
/// </summary>
void Game::processEvents()
{
	sf::Event event;
	while (m_window.pollEvent(event))
	{
		if (event.type == sf::Event::Closed)
		{
			m_window.close();
		}

		if (m_mainMenu->close == true)
		{
			m_window.close();
		}

		//To check for the Akeypress to transition from splash screen to main menu
		processGameEvents(event);
	}

}

/// <summary>
/// sets the current game state 
/// </summary>
/// <param name="gameState"></param>
void Game::setGameState(GameState gameState)
{
	m_currentGameState = gameState;
}

/// <summary>
/// @brief Handle all user input.
/// 
/// Detect and handle keyboard input.
/// </summary>
/// <param name="event">system event</param>
void Game::processGameEvents(sf::Event& event)
{
	
	switch (event.type)
	{
	case sf::Event::KeyPressed:
		m_keyHandler->updateKey(event.key.code, true);
		//m_player->m_pressed = true;
		//m_player->m_colliding = false;
		break;

	case sf::Event::KeyReleased:
		m_keyHandler->updateKey(event.key.code, false);
		rightDown = false;
		leftDown = false;
		break;
	default:
		break;

		

	}

	
}
/// <summary>
/// this is where the walls are generated and created 
/// </summary>
void Game::generatePath()
{
	//the rectangle for the wall from the spritesheet 
	sf::IntRect pathRect(12, 32, 492, 102);
	for (PathData const &path : m_level.m_paths)
	{
		//sets each individual component of the targets to the corresponding 
		//in the yaml file 
		std::unique_ptr<sf::Sprite> sprite(new sf::Sprite());
		sprite->setTexture(m_texture);
		sprite->setTextureRect(pathRect);
		sprite->setOrigin(pathRect.width / 2.0, pathRect.height / 2.0);
		sprite->setPosition(path.m_position);
		sprite->setScale(.3, .2);
		m_pathSprites.push_back(std::move(sprite));

	}
}

void Game::generateJumpers()
{
	for (int i = 0; i < m_level.m_jumperData.size(); i++)
	{
		float x = m_level.m_jumperData[i].m_position.x;
		float y = m_level.m_jumperData[i].m_position.y;

		std::shared_ptr<JumperEnemy> temp = std::make_shared<JumperEnemy>(*this, x, y);
		m_jumperPaths.push_back(temp);
	}
}



void Game::generateCoins()
{
	
	for (int i = 0; i < m_level.m_coinData.size(); i++)
	{
		float x = m_level.m_coinData[i].m_position.x;
		float y = m_level.m_coinData[i].m_position.y;

		std::shared_ptr<Collectable> temp = std::make_shared < Collectable>(*this, x, y, *m_player);
		m_coinSprites.push_back(temp);
	}
}




void Game::generateEnemies()
{
	for (int i = 0; i < m_level.m_enemyData.size(); i++)
	{
		float x = m_level.m_enemyData[i].m_position.x;
		float y = m_level.m_enemyData[i].m_position.y;

		std::shared_ptr<Enemy> temp = std::make_shared<Enemy>(*this, x,y);
		m_enemyPaths.push_back(temp);
		

	}
}
/// <summary>
/// this is where the walls are generated and created 
/// </summary>
void Game::generateFalling()
{
	//the rectangle for the wall from the spritesheet 
	sf::IntRect pathRect(10, 364, 492, 92);
	for (FallingPathData const &path : m_level.m_fallingPaths)
	{
		//sets each individual component of the targets to the corresponding 
		//in the yaml file 
		std::unique_ptr<sf::Sprite> sprite(new sf::Sprite());
		sprite->setTexture(m_texture);
		sprite->setTextureRect(pathRect);
		sprite->setOrigin(pathRect.width / 2.0, pathRect.height / 2.0);
		sprite->setPosition(path.m_position);
		sprite->setScale(.3, .2);
		m_fallingPathSprites.push_back(std::move(sprite));

	}
}

/// <summary>
/// this is where the walls are generated and created 
/// </summary>
void Game::generateSticky()
{
	//the rectangle for the wall from the spritesheet 
	sf::IntRect pathRect(20, 515, 465, 85);
	for (StickyPathData const &path : m_level.m_stickyPaths)
	{
		//sets each individual component of the targets to the corresponding 
		//in the yaml file 
		std::unique_ptr<sf::Sprite> sprite(new sf::Sprite());
		sprite->setTexture(m_texture);
		sprite->setTextureRect(pathRect);
		sprite->setOrigin(pathRect.width / 2.0, pathRect.height / 2.0);
		sprite->setPosition(path.m_position);
		sprite->setScale(.3, .2);
		m_stickyPathSprites.push_back(std::move(sprite));

	}
}

void Game::generateSlippy()
{
	//the rectangle for the wall from the spritesheet 
	sf::IntRect pathRect(10, 206, 492, 100);
	for (SlipPathData const &path : m_level.m_slipPaths)
	{
		//sets each individual component of the targets to the corresponding 
		//in the yaml file 
		std::unique_ptr<sf::Sprite> sprite(new sf::Sprite());
		sprite->setTexture(m_texture);
		sprite->setTextureRect(pathRect);
		sprite->setOrigin(pathRect.width / 2.0, pathRect.height / 2.0);
		sprite->setPosition(path.m_position);
		sprite->setScale(.3, .2);
		m_slippyPaths.push_back(std::move(sprite));

	}
}

void Game::init()
{
	if (levelSet) {
		
		m_player->init();
		m_gameScreen->initBackground();
		m_animationPlayer = new Animation(&m_player->m_texture, sf::Vector2u(6, 4), time1, *this);

		if (!LevelLoader::load(m_currentLevel, m_level))
		{
			return;
		}
		generateFalling();
		generatePath();
		generateSticky();

		generateCoins();
		m_animationCoin = new Animation(&m_coinSprites[0]->m_texture, sf::Vector2u(10, 1), time1, *this);

		generateEnemies();
		m_animationEnemy = new Animation(&m_enemyPaths[0]->m_texture, sf::Vector2u(6, 4), time1, *this);

		if (m_currentLevel > 1) {
			generateJumpers();
			m_animationJumpers = new Animation(&m_jumperPaths[0]->m_texture, sf::Vector2u(6, 4), time1, *this);
		}
		initial = true;
	}
}


/// <summary>
/// Method to handle all game updates
/// </summary>
/// <param name="time">update delta time</param>
void Game::update(sf::Time time)
{
	sf::Time deltaTime;
	m_timeSinceLastUpdate += m_clock.restart().asMilliseconds();
	/*controller->update();*/
	switch (m_currentGameState)
	{
	case GameState::None:
		//	m_splashScreen->print(time);
		std::cout << "no GameState" << std::endl;
		break;
	case GameState::Splash:
		m_splashScreen->update(time);
		break;
	case GameState::MainMenu:
		m_mainMenu->update(time);
		break;
	case GameState::GameSettings:
		m_settings->update(time);
		break;
	case GameState::Instructions:
		m_instructions->update(time);
		break;
	case GameState::PreGame:
		m_preGame->update(time);
		break;
	case GameState::GameScreen:
		if (initial == false) {
			init();
			//m_player->init();
		}
		if (levelSet)
		{
			m_player->update(time, *m_gameScreen);
			//m_enemy->update(time);
			for (int i = 0; i < m_level.m_enemyData.size(); i++)
			{
				m_enemyPaths[i]->update(time);
			}
			if (m_currentLevel > 1)
			{
				for (int i = 0; i < m_level.m_jumperData.size(); i++)
				{
					m_jumperPaths[i]->update(time);
				}
			}

			m_bullet->update(time);
			m_gameScreen->update(time, m_player->m_follow.getCenter(), m_player->getPosition());
			m_gameScreen->retrieveWinner(m_player->getWinner());
			m_gameScreen->retrieveLoser(m_player->getLoser());
			m_animationCoin->update(0, time);

			for (int i = 0; i < m_level.m_coinData.size(); i++)
			{

				m_coinSprites[i]->m_coinRec.setTextureRect(m_animationCoin->m_uvRect);
				m_coinSprites[i]->update(time);

			}
			if (rightDown)
			{
				m_animationPlayer->update(0, time);
				facingRight = true;
				facingLeft = false;
			}
			else if (leftDown)
			{
				m_animationPlayer->update(1, time);
				facingLeft = true;
				facingRight = false;
			}
			else if (m_pressed && m_lastPressed == sf::Keyboard::Key::Right)
			{
				m_animationPlayer->update(2, time);

			}
			else if (m_pressed && m_lastPressed == sf::Keyboard::Key::Left)
			{
				m_animationPlayer->update(3, time);

			}

			for (int i = 0; i < m_level.m_enemyData.size(); i++)
			{
				if (m_enemyPaths[i]->m_moveRight && m_enemyPaths[i]->m_alive)
				{
					m_animationEnemy->update(0, time);
				}
				else if (m_enemyPaths[i]->m_moveLeft && m_enemyPaths[i]->m_alive)
				{
					m_animationEnemy->update(1, time);
				}
			}

			for (int i = 0; i < m_level.m_enemyData.size(); i++)
			{
				m_enemyPaths[i]->m_enemyRec.setTextureRect(m_animationEnemy->m_uvRect);
			}

			if (m_currentLevel > 1) {
				for (int i = 0; i < m_level.m_jumperData.size(); i++)
				{
					if (m_jumperPaths[i]->m_moveRight && m_jumperPaths[i]->m_alive)
					{
						m_animationJumpers->update(0, time);
					}
					if (m_jumperPaths[i]->m_moveLeft && m_jumperPaths[i]->m_alive)
					{
						m_animationJumpers->update(1, time);
					}
					if (m_jumperPaths[i]->m_moveLeft && !m_jumperPaths[i]->m_onPlatform)
					{
						m_animationJumpers->update(3, time);
					}
					if (m_jumperPaths[i]->m_moveRight && !m_jumperPaths[i]->m_onPlatform)
					{
						m_animationJumpers->update(2, time);
					}

				}
				for (int i = 0; i < m_level.m_jumperData.size(); i++)
				{
					m_jumperPaths[i]->m_enemyRec.setTextureRect(m_animationJumpers->m_uvRect);
				}
				jumperPlatformCollision(time);
			}
			playerGoalCollision();
			// Collision between the player and the coin collectables
			for (int i = 0; i < m_level.m_coinData.size(); i++)
			{
				if (true == collisionPlayerCoin(i) && true == m_level.m_coinData[i].m_alive)
				{
					m_coinCollection += 10;
					m_coinAlive[i] = false;
					m_coinSound.play();
					m_level.m_coinData[i].m_alive = false;


				}
			}

			m_player->m_playerRec.setTextureRect(m_animationPlayer->m_uvRect);

			collision();
			collisionFallingPaths(time);
			collisionStickyPaths();
			collisionSlippyPaths();
			collisionEnemyPlayer();
			enemyPlatformCollision(time);
			handleTextChanges(time);

			for (int i = 0; i < m_level.m_coinData.size(); i++)
			{
				if (true == collisionArrowCoin(i) && true == m_level.m_coinData[i].m_alive)
				{
					m_coinCollection++;
					m_coinAlive[i] = false;
					m_level.m_coinData[i].m_alive = false;
				}
			}


			m_player->m_playerRec.setTextureRect(m_animationPlayer->m_uvRect);
			collision();
			collisionFallingPaths(time);
			collisionStickyPaths();
			collisionSlippyPaths();
			handleKeyInput();
		}
		break;

	case GameState::GameOver:

		m_gameOver->update(m_player->m_follow.getCenter(), *m_player);

		break;

	default:
		break;

		
	}
	std::cout << checkLoser() << std::endl;
}
		
void Game::enemyPlatformCollision(sf::Time time)
{
	for (std::unique_ptr<sf::Sprite> const & sprite : m_pathSprites)
	{
		sf::Vector2f currentPos;
		sf::Vector2f platPos(0, 0);

		for (int i = 0; i < m_level.m_enemyData.size(); i++)
		{
			//top of the platform collision
			if (m_enemyPaths[i]->getPosition().y < sprite->getPosition().y && m_enemyPaths[i]->getPosition().y > sprite->getPosition().y - 65 &&
				m_enemyPaths[i]->getPosition().x > sprite->getPosition().x - 100 && m_enemyPaths[i]->getPosition().x < sprite->getPosition().x + 50)
			{
				currentPos = sf::Vector2f(m_enemyPaths[i]->getPosition().x, sprite->getPosition().y - 65);
				m_enemyPaths[i]->setPosition(currentPos);
				m_enemyPaths[i]->m_velocity.y = 0;
				platPos = sprite->getPosition();
				m_enemyPaths[i]->m_onPlatform = true;
				if (m_enemyPaths[i]->getPosition().x >= platPos.x + 40 && m_enemyPaths[i]->m_moveRight == true)
				{
					m_enemyPaths[i]->m_moveLeft = true;

					m_enemyPaths[i]->m_moveRight = false;
				}
				if (m_enemyPaths[i]->getPosition().x <= platPos.x - 80 && m_enemyPaths[i]->m_moveLeft == true)
				{
					m_enemyPaths[i]->m_moveRight = true;

					m_enemyPaths[i]->m_moveLeft = false;
				}
			}
		}
		
	}
}
void Game::jumperPlatformCollision(sf::Time time)
{
	for (std::unique_ptr<sf::Sprite> const & sprite : m_pathSprites)
	{
		sf::Vector2f currentPos;
		sf::Vector2f platPos(0, 0);
		sf::Vector2f lastPos(0, 0);

		for (int i = 0; i < m_level.m_jumperData.size(); i++)
		{
			//top of the platform collision
			if (m_jumperPaths[i]->getPosition().y < sprite->getPosition().y && m_jumperPaths[i]->getPosition().y > sprite->getPosition().y - 65 &&
				m_jumperPaths[i]->getPosition().x > sprite->getPosition().x - 100 && m_jumperPaths[i]->getPosition().x < sprite->getPosition().x + 50)
			{
				currentPos = sf::Vector2f(m_jumperPaths[i]->getPosition().x, sprite->getPosition().y - 65);
				m_jumperPaths[i]->setPosition(currentPos);
				m_jumperPaths[i]->m_velocity.y = 0;
				platPos = sprite->getPosition();
				m_jumperPaths[i]->m_onPlatform = true;
				if (m_jumperPaths[i]->getPosition().x >= platPos.x + 45 && m_jumperPaths[i]->m_moveRight == true)
				{
					if (m_jumperPaths[i]->m_jumpedRight == false)
					{
						m_jumperPaths[i]->jumpOne();
						m_jumperPaths[i]->m_onPlatform = false;
						lastPos = platPos;
					}
				}
				if (m_jumperPaths[i]->getPosition().x >= platPos.x + 45 && m_jumperPaths[i]->m_moveRight == true)
				{
					if (m_jumperPaths[i]->m_jumpedRight == true && lastPos.x != platPos.x)
					{
						m_jumperPaths[i]->m_moveLeft = true;
						m_jumperPaths[i]->m_subtract = true;
						m_jumperPaths[i]->m_moveRight = false;
						m_jumperPaths[i]->m_jumpedLeft = false;
						m_jumperPaths[i]->m_inAir = false;
					}
				}
				if (m_jumperPaths[i]->getPosition().x <= platPos.x - 90 && m_jumperPaths[i]->m_moveLeft == true)
				{
					if (m_jumperPaths[i]->m_jumpedLeft == false/* && lastPos.x != platPos.x*/)
					{
						
						m_jumperPaths[i]->jumpTwo();
						m_jumperPaths[i]->m_onPlatform = false;
						lastPos = platPos;
					}
				}
				if (m_jumperPaths[i]->getPosition().x <= platPos.x -90 && m_jumperPaths[i]->m_moveLeft == true)
				{
					if (m_jumperPaths[i]->m_jumpedLeft == true && lastPos.x != platPos.x)
					{
						m_jumperPaths[i]->m_moveLeft = false;
						m_jumperPaths[i]->m_add = true;
						m_jumperPaths[i]->m_moveRight = true;
						m_jumperPaths[i]->m_jumpedRight = false;
						m_jumperPaths[i]->m_inAir = false;
					}
				}

			}
		}

	}
}
	

void Game::collision()
{
	for (std::unique_ptr<sf::Sprite> const & sprite : m_pathSprites)
	{
		sf::Vector2f currentPos;
		
			//top of the platform collision
			if (m_player->getPosition().y < sprite->getPosition().y && m_player->getPosition().y > sprite->getPosition().y - 65&&
				m_player->getPosition().x > sprite->getPosition().x -100 && m_player->getPosition().x < sprite->getPosition().x + 50)
			{
				currentPos = sf::Vector2f(m_player->getPosition().x, sprite->getPosition().y - 65);
				m_player->setPosition(currentPos);
				m_player->m_pressed = false;
				m_player->m_colliding = false;
				m_player->m_doubleJump = false;
				m_player->setSpeed(5);
				m_player->m_velocity.y = 0;
				
			}

			//Bottom of the platform position
			if (m_player->getPosition().y > sprite->getPosition().y && m_player->getPosition().y < sprite->getPosition().y + 7 &&
				m_player->getPosition().x > sprite->getPosition().x - 100 && m_player->getPosition().x < sprite->getPosition().x + 70)
			{
				currentPos = sf::Vector2f(m_player->getPosition().x, sprite->getPosition().y + 7);
				m_player->setPosition(currentPos);
				m_thumpSound.play();
				m_player->m_velocity.y = -1;
			}

			//side of the platform
			if (m_player->getPosition().y < sprite->getPosition().y + 10 && m_player->getPosition().y > sprite->getPosition().y - 40 &&
				m_player->getPosition().x > sprite->getPosition().x + 50 && m_player->getPosition().x < sprite->getPosition().x + 70)
			{
				currentPos = sf::Vector2f(m_player->getPosition().x + 8, sprite->getPosition().y - 10);
				m_player->setPosition(currentPos);
				m_player->m_colliding = true;
				m_player->m_velocity.y = 0;
			}
			//side of the platform
			if (m_player->getPosition().y < sprite->getPosition().y + 10 && m_player->getPosition().y > sprite->getPosition().y - 40 &&
				m_player->getPosition().x > sprite->getPosition().x - 110 && m_player->getPosition().x < sprite->getPosition().x - 100)
			{
				currentPos = sf::Vector2f(m_player->getPosition().x - 8, sprite->getPosition().y - 10);
				m_player->setPosition(currentPos);
				m_player->m_colliding = true;
				m_player->m_velocity.y = 0;
			}
			
	}

	

	
}
void Game::collisionFallingPaths(sf::Time time)
{
	int maxDistUp = 50;

	sf::Vector2f newPos(0, 0);
	for (std::unique_ptr<sf::Sprite> const & sprite : m_fallingPathSprites)
	{
		sf::Vector2f currentPos;
		sf::Vector2f platPos(0,0);
		//top of the platform collision
		if (m_player->getPosition().y < sprite->getPosition().y && m_player->getPosition().y > sprite->getPosition().y - 65 &&
			m_player->getPosition().x > sprite->getPosition().x - 100 && m_player->getPosition().x < sprite->getPosition().x + 50)
		{
			currentPos = sf::Vector2f(m_player->getPosition().x, sprite->getPosition().y - 65);
			m_player->setPosition(currentPos);
			m_player->m_pressed = false;
			m_player->m_colliding = false;
			m_player->m_doubleJump = false;
			m_player->setSpeed(5);
			//m_startFalling = true;	
			
			m_player->m_velocity.y = 0;
			platPos = sprite->getPosition();
		}
		
		
		
		//Bottom of the platform position
		if (m_player->getPosition().y > sprite->getPosition().y && m_player->getPosition().y < sprite->getPosition().y + 7 &&
			m_player->getPosition().x > sprite->getPosition().x - 100 && m_player->getPosition().x < sprite->getPosition().x + 70)
		{
			currentPos = sf::Vector2f(m_player->getPosition().x, sprite->getPosition().y + 7);
			m_player->setPosition(currentPos);
			m_thumpSound.play();
			m_player->m_velocity.y = -1;
		}

		//side of the platform
		if (m_player->getPosition().y < sprite->getPosition().y + 10 && m_player->getPosition().y > sprite->getPosition().y - 40 &&
			m_player->getPosition().x > sprite->getPosition().x + 50 && m_player->getPosition().x < sprite->getPosition().x + 70)
		{
			currentPos = sf::Vector2f(m_player->getPosition().x + 10, sprite->getPosition().y - 10);
			m_player->setPosition(currentPos);
			m_player->m_colliding = true;
			m_player->m_velocity.y = 0;
		}
		//side of the platform
		if (m_player->getPosition().y < sprite->getPosition().y + 10 && m_player->getPosition().y > sprite->getPosition().y - 40 &&
			m_player->getPosition().x > sprite->getPosition().x - 110 && m_player->getPosition().x < sprite->getPosition().x - 100)
		{
			currentPos = sf::Vector2f(m_player->getPosition().x - 10, sprite->getPosition().y - 10);
			m_player->setPosition(currentPos);
			m_player->m_colliding = true;
			m_player->m_velocity.y = 0;
		}

		if (m_player->getPosition().y < sprite->getPosition().y - 10 &&
			m_player->getPosition().x > sprite->getPosition().x - 100 && m_player->getPosition().x < sprite->getPosition().x + 50) {

		}
		newPos = platPos;
		//if (m_startFalling == true)
		//{
		//	
		//}
		////std::cout << platPos.x << " , " << platPos.y;
		//if (m_startTimer == true)
		//{
		//	
		//}
		//if(m_fallTime.asSeconds() > 1 && platPos == sprite->getPosition())
		//{
		//	sprite->setPosition(sprite->getPosition().x, sprite->getPosition().y + 10);
		//}
		m_fallTime += time;
		if (m_fallTime.asSeconds() > 1 && m_fallTime.asSeconds() < 3)
		{
			sprite->setPosition(sprite->getPosition().x, sprite->getPosition().y + 1);

		}
		if (m_fallTime.asSeconds() > 5 && m_fallTime.asSeconds() < 7)
		{
			sprite->setPosition(sprite->getPosition().x, sprite->getPosition().y - 1);

		}
		if (m_fallTime.asSeconds() >= 7)
		{
			m_fallTime = sf::Time::Zero;

		}
		
		
	}
}
/// <summary>
/// This is where the text changes for the tutorial are hadled
/// when a button is pressed the text change function is called
/// this will only run in the tutorial
/// </summary>
/// <param name="time"></param>
void Game::handleTextChanges(sf::Time time)
{
	
	if (m_lastPressed == sf::Keyboard::Key::Left && !m_leftPressed)
	{
		m_textTime += time;
		if (m_textTime.asSeconds() > 2)
		{
			m_gameScreen->changeString("PRESS RIGHT ARROW TO MOVE RIGHT!");
			m_leftPressed = true;
			m_textTime = sf::Time::Zero;
		}
		
	}
	if (m_lastPressed == sf::Keyboard::Key::Right && !m_rightPressed && m_leftPressed)
	{
		m_textTime += time;
		if (m_textTime.asSeconds() > 2)
		{
			m_gameScreen->changeString("PRESS UP ARROW TO JUMP!");
			m_rightPressed = true;
			m_textTime = sf::Time::Zero;
		}
	}
	if (m_otherPressed == sf::Keyboard::Key::Up && !m_upPressed && m_rightPressed)
	{
		m_textTime += time;
		if (m_textTime.asSeconds() > 2)
		{
			m_gameScreen->changeString("PRESS DOWN IN MID AIR TO ENGAGE JET PACK!");
			m_upPressed = true;
			m_textTime = sf::Time::Zero;
		}
	}
	if (m_otherPressed == sf::Keyboard::Key::Down && !m_downPressed && m_upPressed)
	{
		m_textTime += time;
		if (m_textTime.asSeconds() > 2)
		{
			m_gameScreen->changeString("PRESS SPACE TO SHOOT!");
			m_downPressed = true;
			m_textTime = sf::Time::Zero;
		}
	}
	if (m_otherPressed == sf::Keyboard::Key::Space && !m_bulletShot && m_downPressed)
	{
		m_textTime += time;
		if (m_textTime.asSeconds() > 3)
		{
			m_gameScreen->changeString("WHEN THE TIMER ENDS THE SCREEN WILL MOVE!");
		}
		if (m_textTime.asSeconds() > 6)
		{
			m_gameScreen->changeString("JUMP ON PLATFORMS AND MOVE UP TO COMPLETE TUTORIAL!");
		}
		if (m_textTime.asSeconds() > 9)
		{
			m_gameScreen->changeString("COLLECT COINS AND KILL ENEMIES FOR BONUS");
		}
		if (m_textTime.asSeconds() > 12)
		{
			m_gameScreen->changeString("GOOD LUCK!");
		}
		if (m_textTime.asSeconds() > 15)
		{
			m_gameScreen->changeString("");
			m_bulletShot = true;
		}
	}

}
void Game::playerGoalCollision()
{
	if (m_player->getPosition().x > m_gameScreen->m_portalRec.getPosition().x  - 40&& m_player->getPosition().x < m_gameScreen->m_portalRec.getPosition().x + 40 &&
		m_player->getPosition().y > m_gameScreen->m_portalRec.getPosition().y - 40 && m_player->getPosition().y < m_gameScreen->m_portalRec.getPosition().y + 100)
	{
		m_win = true;
	}
	//std::cout << m_gameScreen->m_portalRec.getOrigin().x << ", " << m_gameScreen->m_portalRec.getPosition().y << std::endl;
}
void Game::collisionStickyPaths()
{
	for (std::unique_ptr<sf::Sprite> const & sprite : m_stickyPathSprites)
	{
		sf::Vector2f currentPos;

		//top of the platform collision
		if (m_player->getPosition().y < sprite->getPosition().y && m_player->getPosition().y > sprite->getPosition().y - 65 &&
			m_player->getPosition().x > sprite->getPosition().x - 100 && m_player->getPosition().x < sprite->getPosition().x + 50)
		{
			currentPos = sf::Vector2f(m_player->getPosition().x, sprite->getPosition().y - 65);
			m_player->setPosition(currentPos);
			m_player->m_pressed = false;
			m_player->m_colliding = false;
			m_player->m_doubleJump = false;
			m_player->setSpeed(2);
			m_onStickyPath = true;
			m_player->m_velocity.y = 0;
		}
		

		//Bottom of the platform position
		if (m_player->getPosition().y > sprite->getPosition().y && m_player->getPosition().y < sprite->getPosition().y + 7 &&
			m_player->getPosition().x > sprite->getPosition().x - 100 && m_player->getPosition().x < sprite->getPosition().x + 70)
		{
			currentPos = sf::Vector2f(m_player->getPosition().x, sprite->getPosition().y + 7);
			m_player->setPosition(currentPos);
			m_thumpSound.play();
			m_player->m_velocity.y = -1;
		}

		//side of the platform
		if (m_player->getPosition().y < sprite->getPosition().y + 10 && m_player->getPosition().y > sprite->getPosition().y - 40 &&
			m_player->getPosition().x > sprite->getPosition().x + 50 && m_player->getPosition().x < sprite->getPosition().x + 70)
		{
			currentPos = sf::Vector2f(m_player->getPosition().x + 8, sprite->getPosition().y - 10);
			m_player->setPosition(currentPos);
			m_player->m_colliding = true;
			m_player->m_velocity.y = 0;
		}
		//side of the platform
		if (m_player->getPosition().y < sprite->getPosition().y + 10 && m_player->getPosition().y > sprite->getPosition().y - 40 &&
			m_player->getPosition().x > sprite->getPosition().x - 110 && m_player->getPosition().x < sprite->getPosition().x - 100)
		{
			currentPos = sf::Vector2f(m_player->getPosition().x - 8, sprite->getPosition().y - 10);
			m_player->setPosition(currentPos);
			m_player->m_colliding = true;
			m_player->m_velocity.y = 0;
		}

		if (m_player->getPosition().y < sprite->getPosition().y - 10 &&
			m_player->getPosition().x > sprite->getPosition().x - 100 && m_player->getPosition().x < sprite->getPosition().x + 50) {

		}

	}




}

void Game::collisionSlippyPaths()
{
	for (std::unique_ptr<sf::Sprite> const & sprite : m_slippyPaths)
	{
		sf::Vector2f currentPos;

		//top of the platform collision
		if (m_player->getPosition().y < sprite->getPosition().y && m_player->getPosition().y > sprite->getPosition().y - 65 &&
			m_player->getPosition().x > sprite->getPosition().x - 100 && m_player->getPosition().x < sprite->getPosition().x + 50)
		{
			currentPos = sf::Vector2f(m_player->getPosition().x, sprite->getPosition().y - 65);
			m_player->setPosition(currentPos);
			m_player->m_pressed = false;
			m_player->m_colliding = false;
			m_player->m_doubleJump = false;
			m_player->setSpeed(8);
			m_player->m_velocity.y = 0;
		}
		

		//Bottom of the platform position
		if (m_player->getPosition().y > sprite->getPosition().y && m_player->getPosition().y < sprite->getPosition().y + 7 &&
			m_player->getPosition().x > sprite->getPosition().x - 100 && m_player->getPosition().x < sprite->getPosition().x + 70)
		{
			currentPos = sf::Vector2f(m_player->getPosition().x, sprite->getPosition().y + 7);
			m_player->setPosition(currentPos);
			m_thumpSound.play();
			m_player->m_velocity.y = -1;
		}

		//side of the platform
		if (m_player->getPosition().y < sprite->getPosition().y + 10 && m_player->getPosition().y > sprite->getPosition().y - 40 &&
			m_player->getPosition().x > sprite->getPosition().x + 50 && m_player->getPosition().x < sprite->getPosition().x + 70)
		{
			currentPos = sf::Vector2f(m_player->getPosition().x + 8, sprite->getPosition().y - 10);
			m_player->setPosition(currentPos);
			m_player->m_colliding = true;
			m_player->m_velocity.y = 0;
		}
		//side of the platform
		if (m_player->getPosition().y < sprite->getPosition().y + 10 && m_player->getPosition().y > sprite->getPosition().y - 40 &&
			m_player->getPosition().x > sprite->getPosition().x - 110 && m_player->getPosition().x < sprite->getPosition().x - 100)
		{
			currentPos = sf::Vector2f(m_player->getPosition().x - 8, sprite->getPosition().y - 10);
			m_player->setPosition(currentPos);
			m_player->m_colliding = true;
			m_player->m_velocity.y = 0;
		}

		if (m_player->getPosition().y < sprite->getPosition().y - 10 &&
			m_player->getPosition().x > sprite->getPosition().x - 100 && m_player->getPosition().x < sprite->getPosition().x + 50) {

		}

	}
}
void Game::handleKeyInput()
{

	if (m_keyHandler->isPressed(sf::Keyboard::Key::Left)&& m_player->m_colliding == false)
	{
		rightDown = false;
		leftDown = true;
		
		m_player->moveLeft();
		m_lastPressed = sf::Keyboard::Key::Left;
		
	}
	else if (m_keyHandler->isPressed(sf::Keyboard::Key::Right)&& m_player->m_colliding == false)
	{
		leftDown = false;
		rightDown = true;
		m_player->moveRight();
		m_lastPressed = sf::Keyboard::Key::Right;
	}
	else
	{

	}

	if (m_keyHandler->isPressed(sf::Keyboard::Key::Up) && !m_player->m_pressed && m_player->m_colliding == false)
	{
		m_player->jump();
		m_otherPressed = sf::Keyboard::Key::Up;
		count++;
	}
	if (m_keyHandler->isPressed(sf::Keyboard::Key::Down) && !m_player->m_doubleJump && m_player->m_pressed== true)
	{
		m_player->doubleJump();
		m_otherPressed = sf::Keyboard::Key::Down;
	}
	if (m_keyHandler->isPressed(sf::Keyboard::Key::Space))
	{
		m_pressed = true;
		m_otherPressed = sf::Keyboard::Key::Space;
	}
	if (!m_keyHandler->isPressed(sf::Keyboard::Key::Space))
	{
		m_pressed = false;
	}
	//std::cout << m_player->m_pressed << std::endl;

}

/// <summary>
///  Checks collision between the player and the coin collectable
///  Returns true or false
///  Called in the method for drawing purposes.
///  Called in the update for scoring purposes.
/// </summary>
/// <param name="i"></param>
/// <returns></returns>
bool Game::collisionPlayerCoin(int i)
{

	if ((m_player->getPosition().x + 30 >= m_coinSprites[i]->getPosition().x && m_player->getPosition().x <= m_coinSprites[i]->getPosition().x + 30
		&& m_player->getPosition().y + 50 >= m_coinSprites[i]->getPosition().y && m_player->getPosition().y < m_coinSprites[i]->getPosition().y + 30))
	{
		return true;
	}
	else
	{
		return false;
	}

}
/// <summary>
/// collision between all enemies in the game and the player 
/// also checks for the colisions between the bullets and the enemies
/// </summary>
void Game::collisionEnemyPlayer()
{
	//std::cout << m_lastPressed << std::endl;
	//checks the enemy and player collision
	for (int i = 0; i < m_enemyPaths.size(); i++)
	{
		if (m_player->getPosition().x + 40 > m_enemyPaths[i]->getPosition().x && m_player->getPosition().x < m_enemyPaths[i]->getPosition().x + 40
			&& m_player->getPosition().y - 60 < m_enemyPaths[i]->getPosition().y &&  m_player->getPosition().y > m_enemyPaths[i]->getPosition().y - 60)
		{
			if (m_enemyPaths[i]->m_alive)//checks if the enemies are alive 
			{
				m_gameScreen->changeLives();//decrements lives 
				m_player->changeLives();
				m_player->resetPlayer();//resets the player position
				
			}
			
		}
		//checks the bullet and enemy collision
		if (m_enemyPaths[i]->m_alive)
		{
			if (m_bullet->getPosition().x + 30 > m_enemyPaths[i]->getPosition().x && m_bullet->getPosition().x < m_enemyPaths[i]->getPosition().x + 40
				&& m_bullet->getPosition().y < m_enemyPaths[i]->getPosition().y + 60 && m_bullet->getPosition().y > m_enemyPaths[i]->getPosition().y - 20)
			{
				m_enemySound.play();
				m_enemyPaths[i]->m_alive = false;//kills the enemy
				m_enemiesShot++;
				std::cout << m_enemiesShot << std::endl;
				m_bullet->m_alive = false;
				m_bullet->resetBullet();
				if (m_lastPressed == sf::Keyboard::Key::Right)
				{
					m_bullet->m_aliveRight = true;
				}
				else
				{
					m_bullet->m_aliveLeft = false;
				}
				m_bullet->m_fired = false;
				//createCoin(m_enemyPaths[i]->getPosition());
			}
		}
		
	}
	
	if (m_currentLevel > 1) {

		for (int i = 0; i < m_jumperPaths.size(); i++)
		{
			if (m_player->getPosition().x + 40 > m_jumperPaths[i]->getPosition().x && m_player->getPosition().x < m_jumperPaths[i]->getPosition().x + 40
				&& m_player->getPosition().y - 60 < m_jumperPaths[i]->getPosition().y &&  m_player->getPosition().y > m_jumperPaths[i]->getPosition().y - 60)
			{
				if (m_jumperPaths[i]->m_alive)//checks if the enemies are alive 
				{
					m_gameScreen->changeLives();//decrements lives 
					m_player->changeLives();
					m_player->resetPlayer();//resets the player position

				}

			}
			//checks the bullet and enemy collision

				if (m_bullet->getPosition().x + 30 > m_jumperPaths[i]->getPosition().x && m_bullet->getPosition().x < m_jumperPaths[i]->getPosition().x + 40
					&& m_bullet->getPosition().y - 60 < m_jumperPaths[i]->getPosition().y &&  m_bullet->getPosition().y > m_jumperPaths[i]->getPosition().y - 60)
				{
					m_jumperPaths[i]->m_alive = false;//kills the enemy
					//m_jumperPaths[i]-
					m_jumperPaths[i]->setVelocity(0);
				}

			}
			
		}
	}

void Game::setCurrentLevel(int level)
{
	/*levelSet = false;
	initial = false;*/
	if (!playedOnce)
	{
		m_currentLevel = level;
		levelSet = true;
	}
	else
	{
		m_currentLevel = level;
		levelSet = true;
	}
	
}

/// <summary>
/// collision between the Arrow and the coins 
/// </summary>
/// <param name="ind"></param>
/// <param name="i"></param>
/// <returns></returns>
bool Game::collisionArrowCoin(int i)
{
	
	if ((m_bullet->getPosition().x+ 30 >= m_coinSprites[i]->getPosition().x && m_bullet->getPosition().x <= m_coinSprites[i]->getPosition().x + 30
		&& m_bullet->getPosition().y + 50 >= m_coinSprites[i]->getPosition().y && m_bullet->getPosition().y < m_coinSprites[i]->getPosition().y + 30))
	{

		return true;
	}
	else
	{
		return false;
	}

}

/// <summary>
/// @brief draw the window for the game.
/// 
/// draw buttons and text on left side
/// </summary>
void Game::render()
{
	m_window.clear(sf::Color::Black);
	switch (m_currentGameState)
	{
	case GameState::Splash:
		m_splashScreen->render(m_window);
		break;
	case GameState::MainMenu:
		m_player->m_follow.setViewport(sf::FloatRect(0, 0, 1, 1));
		m_player->m_follow.setViewport(sf::FloatRect(0, 0, 1.5, 1.5));
		m_player->m_follow.setSize(1920, 1080);
		inGame = false;
		m_mainMenu->render(m_window);
		break;
	case GameState::GameSettings:
		inGame = false;
		m_settings->render(m_window);
		break;
	case GameState::Instructions:
		inGame = false;
		m_instructions->render(m_window);
		break;
	case GameState::PreGame:
		inGame = false;
		m_preGame->render(m_window);
		break;
	case GameState::GameScreen:
		
		inGame = true;
		
		if (levelSet && initial) {
			m_gameScreen->render(m_window);
			m_player->render(m_window);
			//m_enemy->render(m_window);
			for (int i = 0; i < m_level.m_enemyData.size(); i++)
			{
				m_enemyPaths[i]->render(m_window);
			}
			if (m_currentLevel > 1) {
				for (int i = 0; i < m_level.m_jumperData.size(); i++)
				{
					m_jumperPaths[i]->render(m_window);
				}
			}

			m_bullet->draw(m_window);


			// Checking collision with the player and if false then draw the coins array.
			for (int i = 0; i < m_level.m_coinData.size(); i++)
			{
				if (collisionPlayerCoin(i) == false && m_level.m_coinData[i].m_alive == true)
				{
					m_coinSprites[i]->render(m_window);
				}
				if (collisionPlayerCoin(i) == true)
				{
					m_level.m_coinData[i].m_alive = false;
				}

			}

			for (auto &m_sprite : m_pathSprites)
			{
				m_window.draw(*m_sprite);
			}
			for (auto &m_sprite : m_fallingPathSprites)
			{
				m_window.draw(*m_sprite);
			}
			for (auto &m_sprite : m_stickyPathSprites)
			{
				m_window.draw(*m_sprite);
			}
			for (auto &m_sprite : m_slippyPaths)
			{
				m_window.draw(*m_sprite);
			}
			m_window.draw(m_gameScreen->getText());
			m_window.draw(m_gameScreen->getLoserText());
			m_window.draw(m_gameScreen->getScoreText());
		}
		break;
	case GameState::GameOver:
		m_gameOver->render(m_window);
	default:
		break;
	}
	m_window.display();
}

// Two methods to pass the score attributes to the final screen
int Game::GetCoins()
{
	return m_coinCollection;
}

int Game::GetDeadEnemies()
{
	return m_enemiesShot;
}


//returns the win or lose to the gameOver screen
bool Game::checkWinner()
{
	return m_player->getWinner();
}

bool Game::checkLoser()
{
	
	return m_player->getLoser();
}
