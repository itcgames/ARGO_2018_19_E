#include "Header\Settings.h"



Settings::Settings(Game & game, sf::Font font, KeyHandler & key) :
	m_game(&game),
	m_font(font),
	m_keyhandler(key),
	m_index(0),
	m_pressed(false),
	m_soundFX(true),
	m_musicFX(true),
	m_toggle(false),
	m_eZhard(false)
{

	//Icon set up
	m_marker.setFillColor(sf::Color(sf::Color::Red));
	m_marker.setRadius(25);
	m_marker.setPosition(200, 140);

	// Setting up the general messages.
	m_textMessage[0].setFont(m_font);
	m_textMessage[0].setCharacterSize(100);
	m_textMessage[0].setPosition(300, 100);
	m_textMessage[0].setFillColor(sf::Color(0, 0, 255));
	m_textMessage[0].setString("Music");

	m_textMessage[1].setFont(m_font);
	m_textMessage[1].setCharacterSize(100);
	m_textMessage[1].setPosition(300, 250);
	m_textMessage[1].setFillColor(sf::Color(200, 200, 0));
	m_textMessage[1].setString("Sound FX");

	m_textMessage[2].setFont(m_font);
	m_textMessage[2].setCharacterSize(100);
	m_textMessage[2].setPosition(300, 400);
	m_textMessage[2].setFillColor(sf::Color(200, 200, 0));
	m_textMessage[2].setString("Difficulty");


	//Setting up difficulty messages
	m_difficulty[0].setFont(m_font);
	m_difficulty[0].setCharacterSize(85);
	m_difficulty[0].setPosition(880, 400);
	m_difficulty[0].setFillColor(sf::Color(0, 200, 0));
	m_difficulty[0].setString("Easy");

	m_difficulty[1].setFont(m_font);
	m_difficulty[1].setCharacterSize(85);
	m_difficulty[1].setPosition(1100, 400);
	m_difficulty[1].setFillColor(sf::Color(255, 0, 0));
	m_difficulty[1].setString(" Hard");


	//Setting up sound FX messages.
	m_music.setFont(m_font);
	m_music.setCharacterSize(85);
	m_music.setPosition(880, 250);
	m_music.setFillColor(sf::Color(0, 200, 0));
	m_music.setString("On");


	//Setting up music messages.
	m_sound.setFont(m_font);
	m_sound.setCharacterSize(85);
	m_sound.setPosition(880, 100);
	m_sound.setFillColor(sf::Color(0, 200, 0));
	m_sound.setString("On");

	//shader set up
	m_blankTexture.loadFromFile("resources/images/blank.png");
	m_blankSprite.setTexture(m_blankTexture);
	m_blankSprite.setScale(2, 1.5);
	if (!m_grassShader.loadFromFile("ShaderGrass.frag", sf::Shader::Fragment))
	{
		std::cout << "shader not loaded" << std::endl;
	}

	m_grassShader.setUniform("time", 0.0f);
	m_grassShader.setUniform("resolution", sf::Vector2f(2000, 700));

	m_blankSprite.setPosition(0, 0);
}


Settings::~Settings()
{
}

void Settings::update(sf::Time dt)
{
	//shader update section
	m_shaderTime += dt;
	m_updateShader = m_shaderTime.asSeconds();
	m_grassShader.setUniform("time", m_updateShader);


	if (m_keyhandler.isPressed(sf::Keyboard::BackSpace))
	{
		m_game->setGameState(GameState::MainMenu);
	}
	
	menuControl();
}

void Settings::render(sf::RenderWindow &window)
{
	//shader render
	window.draw(m_blankSprite, &m_grassShader);
	for (int i = 0; i <= 2; i++)
	{
		window.draw(m_textMessage[i]);
		
	}

	for (int i = 0; i < 2; i++)
	{
		window.draw(m_difficulty[i]);
	}
	window.draw(m_sound);
	window.draw(m_music);
	window.draw(m_marker);
}

void Settings::menuControl()
{
	if (m_keyhandler.isPressed(sf::Keyboard::Key::Up) == false && m_keyhandler.isPressed(sf::Keyboard::Key::Down) == false)
	{
		m_pressed = false;
	}

	//indexing down
	if (m_keyhandler.isPressed(sf::Keyboard::Down) && m_index == 0 && m_pressed == false)
	{
		m_marker.setPosition(200, 290);
		m_textMessage[0].setFillColor(sf::Color(200, 200, 0));
		m_textMessage[1].setFillColor(sf::Color(0, 0, 255));
		m_index++;
		m_pressed = true;
	}
	if (m_keyhandler.isPressed(sf::Keyboard::Down) && m_index == 1 && m_pressed == false)
	{
		m_marker.setPosition(200, 440);
		m_textMessage[1].setFillColor(sf::Color(200, 200, 0));
		m_textMessage[2].setFillColor(sf::Color(0, 0, 255));
		m_index++;
		m_pressed = true;
	}
	if (m_keyhandler.isPressed(sf::Keyboard::Down) && m_index == 2 && m_pressed == false)
	{
		m_marker.setPosition(200, 140);
		m_textMessage[2].setFillColor(sf::Color(200, 200, 0));
		m_textMessage[0].setFillColor(sf::Color(0, 0, 255));
		m_index = 0;
		m_pressed = true;
	}

	// indexing up
	if (m_keyhandler.isPressed(sf::Keyboard::Up) && m_index == 0 && m_pressed == false)
	{
		m_marker.setPosition(200, 440);
		m_textMessage[0].setFillColor(sf::Color(200, 200, 0));
		m_textMessage[2].setFillColor(sf::Color(0, 0, 255));
		m_index = 2;
		m_pressed = true;
	}
	if (m_keyhandler.isPressed(sf::Keyboard::Up) && m_index == 1 && m_pressed == false)
	{
		m_marker.setPosition(200, 140);
		m_textMessage[1].setFillColor(sf::Color(200, 200, 0));
		m_textMessage[0].setFillColor(sf::Color(0, 0, 255));
		m_index = 0;
		m_pressed = true;
	}
	if (m_keyhandler.isPressed(sf::Keyboard::Up) && m_index == 2 && m_pressed == false)
	{
		m_marker.setPosition(200, 290);
		m_textMessage[2].setFillColor(sf::Color(200, 200, 0));
		m_textMessage[1].setFillColor(sf::Color(0, 0, 255));
		m_index = 1;
		m_pressed = true;
	}


	if ((m_keyhandler.isPressed(sf::Keyboard::Space) == false && m_keyhandler.isPressed(sf::Keyboard::Return) == false))
	{
		m_toggle = false;
	}
	//Toggling buttons sound FX
	if (m_index == 0 && true == m_soundFX && (m_keyhandler.isPressed(sf::Keyboard::Space) || m_keyhandler.isPressed(sf::Keyboard::Return)) && false == m_toggle )
	{	
		m_sound.setString("On");
		m_sound.setFillColor(sf::Color(0, 200, 0));
		
		m_soundFX = false;
		m_toggle = true;
		m_pressed = true;
	}
	else if (m_index == 0 && false == m_soundFX && (m_keyhandler.isPressed(sf::Keyboard::Space) || m_keyhandler.isPressed(sf::Keyboard::Return)) && false == m_toggle)
	{
		m_sound.setString("OFF");
		m_sound.setFillColor(sf::Color(200, 0, 0));

		m_soundFX = true;
		m_toggle = true;
		m_pressed = true;
	}

	//Toggling buttons Music
	if (m_index == 1 && true == m_musicFX && (m_keyhandler.isPressed(sf::Keyboard::Space) || m_keyhandler.isPressed(sf::Keyboard::Return)) && false == m_toggle)
	{
		m_music.setString("On");
		m_music.setFillColor(sf::Color(0, 200, 0));

		m_musicFX = false;
		m_toggle = true;
	}
	else if (m_index == 1 && false == m_musicFX && (m_keyhandler.isPressed(sf::Keyboard::Space) || m_keyhandler.isPressed(sf::Keyboard::Return)) && false == m_toggle)
	{
		m_music.setString("OFF");
		m_music.setFillColor(sf::Color(200, 0, 0));

		m_musicFX = true;
		m_toggle = true;

	}

	//toggling difficulty
	if (m_index == 2 && true == m_eZhard && (m_keyhandler.isPressed(sf::Keyboard::Space) || m_keyhandler.isPressed(sf::Keyboard::Return)) && false == m_toggle)
	{
		m_difficulty[0].setFillColor(sf::Color(0, 200, 0));

		m_difficulty[1].setFillColor(sf::Color(200, 0, 0));

		m_eZhard = false;
		m_toggle = true;
	}
	else if (m_index == 2 && false == m_eZhard && (m_keyhandler.isPressed(sf::Keyboard::Space) || m_keyhandler.isPressed(sf::Keyboard::Return)) && false == m_toggle)
	{
		m_difficulty[1].setFillColor(sf::Color(0, 200, 0));

		m_difficulty[0].setFillColor(sf::Color(200, 0, 0));

		m_eZhard = true;
		m_toggle = true;

	}

}