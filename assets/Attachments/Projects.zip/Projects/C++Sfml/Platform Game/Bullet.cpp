#include "Header/Bullet.h"



Bullet::Bullet(Game & game, KeyHandler & keyhandle, Player & player) :
	m_game(&game),
	m_keyhandle(&keyhandle),
	m_alive(false),
	m_aliveRight(true),
	m_aliveLeft(false),
	m_fired(false),
	m_player(&player),
	m_velocity(20, 0)
	
{
	m_texture.loadFromFile("./resources/images/projectile.png");
	m_sprite.setTexture(m_texture);
	
	m_sprite.scale(.025, .025);
	
	m_pos = m_player->m_position;

	m_laserbuf.loadFromFile("resources/sounds/laser.wav");
	m_lasersound.setBuffer(m_laserbuf);
}


Bullet::~Bullet()
{
	std::cout << "destructing Bullet";
}

void Bullet::initialize()
{

}

void Bullet::update(sf::Time dt)
{
	m_time += dt;

	// Assigns the bullet direction while it hasn't been fired

	//if (m_keyhandle->isPressed(sf::Keyboard::Key::Space) == false && m_keyhandle->isPressed(sf::Keyboard::Key::X) == false && boundaryCollision() == true)
	if (boundaryCollision() == true)
	{
	 	m_fired = false;
	
	}

	if (m_fired != true)
	{
	
		//m_pos = m_player->m_position;
		//m_sprite.setPosition(m_pos);
		if (m_keyhandle->isPressed(sf::Keyboard::Key::Right))
		{
			m_aliveRight = true;
			m_aliveLeft = false;
			
		}
		if (m_keyhandle->isPressed(sf::Keyboard::Key::Left))
		{			
			m_aliveRight = false;
			m_aliveLeft = true;		
		}
	}
	
	

	
	//Bullet activation

		// Ignore this if bullet still onscreen
	if (m_keyhandle->isPressed(sf::Keyboard::Key::Space) && m_fired == false)
	{		
		m_fired = true;		
		m_alive = true;
		m_pos = m_player->m_position;
		m_lasersound.play();
		//m_sprite.setPosition(m_pos);
	}
	//else
	/*{
		m_fired = false;
	}*/

	//Calls method to add velocity going right to the bullet based upon the direction previously assigned
	if (true == m_fired && true == m_aliveRight && boundaryCollision()==false)
	//if (true == m_aliveRight  && boundaryCollision() == false)
	{
		fireRight();
	}

	//Calls method to add velocity going left to the bullet based upon the direction previously assigned
	if (true == m_fired && true == m_aliveLeft && boundaryCollision() == false)
	//if (true == m_aliveLeft && boundaryCollision() == false)
	{
		//m_game->m_animationPlayer->update(3, m_time);
		fireLeft();
	}



}

//Adds Velocity to the bullet going right
void Bullet::fireRight()
{
	m_alive = true;
	m_pos.x += m_velocity.x;	
	
}

//Adds Velocity to the bullet going left
void Bullet::fireLeft()
{	
	m_alive = true;
	m_pos.x -= m_velocity.x;
}

void Bullet::draw(sf::RenderWindow & window)
{
	//Checks alive right and left to not fire whem its stationary
	if (true == m_fired&& boundaryCollision() == false && m_alive) // (true == m_aliveRight || true == m_aliveLeft))
	{
		// Have to assign the position here again or the sprite position doesn't change pn screen
		// even when the value is changing
		m_sprite.setPosition(m_pos.x, m_pos.y+20);
		window.draw(m_sprite);
		

	}
}

void Bullet::resetBullet()
{
	m_pos = sf::Vector2f(m_player->m_position.x, m_player->m_position.y+ 30);
	m_sprite.setPosition(m_pos);
}


bool Bullet::boundaryCollision()
{
	bool hasCollided = false;
	if (m_pos.x <= 450 || m_pos.x >= 1450)
	{
		
		
		if (m_pos.x <= 450)
		{			
			m_aliveLeft = true;
			m_fired = false;

			m_pos = m_player->m_position;
			m_sprite.setPosition(m_pos.x, m_pos.y - 70);
			resetBullet();

			hasCollided = true;
			return hasCollided;
		}
		else if (m_pos.x >= 1450)
		{
			m_aliveRight = true;
			m_fired = false;

			m_pos = m_player->m_position;
			m_sprite.setPosition(m_pos.x, m_pos.y -70);
			resetBullet();

			hasCollided = true;
			return hasCollided;
		}
		//else if ()
	}
	return hasCollided;
}



sf::Vector2f Bullet::getPosition()
{
	return m_pos;
}