#include "Header/PreGame.h"
#include <iostream>

PreGame::PreGame(Game & game, sf::Font font, KeyHandler& key) :
	m_game(&game),
	m_font(font),
	m_keyhandler(key)
{
	m_levelText[0].setFont(m_font);
	m_levelText[0].setCharacterSize(100);
	m_levelText[0].setPosition(550, 100);
	m_levelText[0].setFillColor(sf::Color(0, 0, 255));
	m_levelText[0].setString("Tutorial Level 1");
	
	m_levelText[1].setFont(m_font);
	m_levelText[1].setCharacterSize(100);
	m_levelText[1].setPosition(700, 300);
	m_levelText[1].setFillColor(sf::Color(0, 0, 255));
	m_levelText[1].setString("Level 2");
}

PreGame::~PreGame()
{
	std::cout << "destructing Splash" << std::endl;
	
}


void PreGame::update(sf::Time deltaTime)
{
	m_time += deltaTime;
	if (m_keyhandler.isPressed(sf::Keyboard::Key::Up) == false && m_keyhandler.isPressed(sf::Keyboard::Key::Down) == false)
	{
		m_pressed = false;
	}

	//indexing down
	if (m_keyhandler.isPressed(sf::Keyboard::Down) && m_index == 0 && m_pressed == false)
	{
		//m_marker.setPosition(200, 290);
		m_levelText[0].setFillColor(sf::Color(200, 200, 0));
		m_levelText[1].setFillColor(sf::Color(0, 0, 255));
		m_index++;
		m_pressed = true;
	}
	if (m_keyhandler.isPressed(sf::Keyboard::Down) && m_index == 1 && m_pressed == false)
	{
		//m_marker.setPosition(200, 440);
		m_levelText[1].setFillColor(sf::Color(200, 200, 0));
		m_levelText[0].setFillColor(sf::Color(0, 0, 255));
		m_index = 0;
		m_pressed = true;
	}
	if (m_keyhandler.isPressed(sf::Keyboard::Up) && m_index == 0 && m_pressed == false)
	{
		//m_marker.setPosition(200, 440);
		m_levelText[0].setFillColor(sf::Color(200, 200, 0));
		m_levelText[1].setFillColor(sf::Color(0, 0, 255));
		m_index = 1;
		m_pressed = true;
	}
	if (m_keyhandler.isPressed(sf::Keyboard::Up) && m_index == 1 && m_pressed == false)
	{
		//m_marker.setPosition(200, 140);
		m_levelText[1].setFillColor(sf::Color(200, 200, 0));
		m_levelText[0].setFillColor(sf::Color(0, 0, 255));
		m_index = 0;
		m_pressed = true;
	}
	//Toggling buttons sound FX
	if (m_time.asSeconds() > 2)
	{
		m_change = false;
	}
	if (m_change == false && m_index == 0 && (m_keyhandler.isPressed(sf::Keyboard::Space) || m_keyhandler.isPressed(sf::Keyboard::Return)))
	{
		m_game->setCurrentLevel(2);
		m_game->setGameState(GameState::GameScreen);
		m_change = true;
		m_time = sf::Time::Zero;
	}
	if (m_change == false && m_index == 1 && (m_keyhandler.isPressed(sf::Keyboard::Space) || m_keyhandler.isPressed(sf::Keyboard::Return)))
	{
		m_game->setCurrentLevel(1);
		m_game->setGameState(GameState::GameScreen);
		m_change = true;
		m_time = sf::Time::Zero;
	}
}

void PreGame::render(sf::RenderWindow & window)
{	
	
	for (int i = 0; i < 2; i++)
	{
		window.draw(m_levelText[i]);
	}
	window.draw(m_sprite);
	
}

