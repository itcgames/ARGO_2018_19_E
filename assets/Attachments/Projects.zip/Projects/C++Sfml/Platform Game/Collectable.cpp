#include "Header/Collectable.h"



Collectable::Collectable(Game& Game, float x, float y, Player &player) :
	m_game(&Game),
	m_position(x, y),
	m_player(&player)
{
	m_texture.loadFromFile("./resources/images/coin_spriteSheet.png");
	m_coinRec.setTexture(&m_texture);
	m_coinRec.setPosition(m_position);
	m_coinRec.setSize(sf::Vector2f(30, 30));
	
}

void Collectable::update(sf::Time deltaTime)
{
	m_time += deltaTime;

	m_coinRec.setPosition(m_position);
}

void Collectable::render(sf::RenderWindow & window)
{
	window.draw(m_coinRec);
	
}

Collectable::~Collectable()
{
	std::cout << "destructing collectable";
}


///
/// 
/// collision detection with the player charachter(trump)
sf::Vector2f Collectable::getPosition()
{
	return m_position;
}