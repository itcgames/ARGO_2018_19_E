#include "Header/Enemy.h"



Enemy::Enemy(Game& game, float x, float y) :
	m_game(&game),
	m_position(x, y),
	m_moveLeft(false),
	m_moveRight(true),
	m_velocity(0,0),
	m_onPlatform(false)
{
	m_enemyRec.setPosition(sf::Vector2f(m_position));
	m_enemyRec.setSize(sf::Vector2f(50, 60));
	m_texture.loadFromFile("./resources/images/spritesheet.png");
	m_enemyRec.setTexture(&m_texture);
}


Enemy::~Enemy()
{
}

void Enemy::update(sf::Time deltaTime)
{
	m_cumulativeTime += deltaTime;
	m_position.y = m_position.y + m_velocity.y * m_cumulativeTime.asSeconds()
		+ 0.5 * (9.81 * 150) * m_cumulativeTime.asSeconds()  * m_cumulativeTime.asSeconds();
	if (m_onPlatform == true && m_alive == true)
	{
		if (m_moveRight == true) {
			m_position.x = m_position.x + 1;
		}
		else if (m_moveLeft == true) {
			m_position.x = m_position.x - 1;
		}
	}
	
	
	if (m_position.y < 1000)
	{
		m_velocity.y = m_velocity.y + (9.81 * 150) * m_cumulativeTime.asSeconds();
	}
	
	//stops the enemy from moving under starting Pos
	if (m_position.y > 1000)
	{
		m_velocity.y = 0;
		m_position.y = 1000;
	}

	m_enemyRec.setPosition(m_position);
	m_cumulativeTime = sf::Time::Zero;
}

sf::Vector2f Enemy::getPosition()
{
	return m_position;
}

void Enemy::setPosition(sf::Vector2f curPosition)
{
	m_position = curPosition;
}

void Enemy::setVelocity(float curVelocity)
{
	m_velocity.y = curVelocity;
}

void Enemy::render(sf::RenderWindow& window)
{
	if (m_alive)
	window.draw(m_enemyRec);
}
