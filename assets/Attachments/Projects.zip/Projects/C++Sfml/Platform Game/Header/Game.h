#pragma once
#include <SFML\Graphics.hpp>
#include <memory>
#include <iostream>

#include "Header\MainMenu.h"
#include "Header\GameScreen.h"
#include "Header\Player.h"
#include "Header\Platform.h"
#include "Header\KeyHandler.h"
#include "Header\JumperEnemy.h"
#include "Header\Enemy.h"
#include "Header\Splash.h"
#include "Header\Animation.h"
#include "Header\LevelLoader.h"
#include "Header\Bullet.h"
#include "Header\Collectable.h"
#include "Header\GameOver.h"
#include "Header\Settings.h"
#include "Header\Instructions.h"
#include "Header\PreGame.h"
#include <SFML\Audio.hpp>

/// <summary>
/// @brief Main class for the SFML Playground project.
/// authors James Condon and Conor O'Toole.
/// 
/// </summary>

//each class is declared

class MainMenu;
class GameScreen;
class Player;
class Platform;
class Splash;
class Animation;
class Bullet;
class Collectable;
class Enemy;
class JumperEnemy;
class GameOver;
class Settings;
class Instructions;
class PreGame;

enum class
	GameState
{
	None,
	Splash,
	MainMenu,
	GameScreen,
	PreGame,
	Instructions,
	AudioSettings,
	GameSettings,
	GameOver

};

class Game
{
public:
	Game();
	~Game();
	void run();
	GameState m_currentGameState;
	GameState m_previousGameState;
	void setGameState(GameState gameState);
	bool colliding = false;
	std::vector<sf::CircleShape> m_nodes;
	void generatePath();
	void generateFalling();
	void generateSticky();
	void generateSlippy();
	void generateCoins();
	void generateEnemies();
	void generateJumpers();
	void playerGoalCollision();
	void init();
	bool checkLoser();
	void setCurrentLevel(int level);
	void checkOverUnder();
	void handleTextChanges(sf::Time time);
	int m_currentLevel;
	bool m_bulletShot = false;
	bool m_win = false;
	int GetCoins();
	int GetDeadEnemies();
	bool levelSet = false;
	bool checkWinner();
	bool initial = false;
	bool playedOnce = false;
	bool inGame = false;
protected:
	void update(sf::Time deltaTime);
	void render();
	void processEvents();
	void handleKeyInput();
	void processGameEvents(sf::Event&);
	void collision();
	void enemyPlatformCollision(sf::Time deltaTime);
	void jumperPlatformCollision(sf::Time deltaTime);
	void collisionFallingPaths(sf::Time time);
	void createCoin(sf::Vector2f pos);
	void collisionStickyPaths();
	void collisionSlippyPaths();
	void collisionEnemyPlayer();
	bool collisionPlayerCoin(int i);
	bool collisionArrowCoin(int i);
	bool getReturnToMenu(bool bl);
	/************************************/
	sf::Clock m_clock;
	sf::Time time1;
	sf::Time m_fallTime;
	// main window
	sf::RenderWindow m_window;
	sf::Font m_font;
	double m_timeSinceLastUpdate;
	//pointers set for all screens
	MainMenu * m_mainMenu;
	Splash * m_splashScreen;
	GameScreen * m_gameScreen;
	PreGame *  m_preGame;
	Player * m_player;
	Enemy * m_enemy;
	Platform * m_platform[12];
	KeyHandler * m_keyHandler;
	Animation * m_animationPlayer;
	Bullet * m_bullet;
	Collectable * m_coin[5];
	Animation * m_animationCoin;
	Animation * m_animationEnemy;
	Animation * m_animationJumpers;
	GameOver * m_gameOver;
	Settings * m_settings;
	Instructions * m_instructions;
	bool rightDown = false;
	bool leftDown = false;
	sf::Texture m_texture;
	sf::Texture m_textureEnemy;
	std::vector<std::unique_ptr<sf::Sprite>> m_pathSprites;
	std::vector<std::unique_ptr<sf::Sprite>> m_fallingPathSprites;
	std::vector<std::unique_ptr<sf::Sprite>> m_stickyPathSprites;
	std::vector<std::unique_ptr<sf::Sprite>> m_slippyPaths;
	std::vector<std::shared_ptr<Collectable>> m_coinSprites;

	std::vector<std::shared_ptr<JumperEnemy>> m_jumperPaths;
	std::vector<std::shared_ptr<Enemy>> m_enemyPaths;

	LevelData m_level;
	bool over = false;
	bool under = false;
	sf::SoundBuffer m_thumpBuffer;
	sf::Sound m_thumpSound;
	bool m_falling = false;
	bool m_startFalling = false;
	bool m_startTimer = false;
	bool m_onStickyPath = false;
	int count = 0;
	int m_enemiesShot;
	int m_coinCollection;
	bool m_onPlatform = false;
	bool m_coinAlive[5];
	sf::Time m_dieTime;
	sf::Keyboard::Key m_lastPressed;
	sf::Keyboard::Key m_otherPressed;
	bool m_pressed = false;
	bool facingLeft = false;
	bool facingRight = false;
	std::vector<std::shared_ptr<sf::Vector2f>> m_startPos;
	sf::Time m_textTime;
	bool m_leftPressed = false;
	bool m_rightPressed = false;
	bool m_upPressed = false;
	bool m_downPressed = false;
	
	//coin collection 
	sf::SoundBuffer m_coinbuf;
	sf::Sound m_coinSound;

	//enemy death sounds
	sf::SoundBuffer m_enemybuf;
	sf::Sound m_enemySound;
};
