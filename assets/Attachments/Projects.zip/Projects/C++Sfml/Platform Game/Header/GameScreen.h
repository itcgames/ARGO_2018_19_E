#pragma once
#ifndef GAMESCREEN
#define GAMESCREEN	
#include "Header\Game.h"
#include <math.h>     
#include <SFML\Graphics.hpp>
#include <SFML\Audio.hpp>

class Game;

class GameScreen
{
public:
	GameScreen(Game& Game, sf::Font font, int coins);
	~GameScreen();
	void update(sf::Time time, sf::Vector2f position, sf::Vector2f playerPos);
	void render(sf::RenderWindow& window);
	void setPortalPosition();
	sf::Text getText();
	sf::Text getScoreText();
	void retrieveWinner(bool win);
	void retrieveLoser(bool lose);
	void changeLives();
	sf::Text getLoserText();
	void changeString(sf::String string);
	void initBackground();
	sf::RectangleShape m_portalRec;
private:
	Game *m_game;//pointer to games class 
	sf::Font m_font;
	sf::Window m_window;
	sf::Time m_time;
	sf::Time m_resetTime;
	sf::Time m_timer;
	sf::Texture m_texture;
	sf::Sprite m_sprite;
	sf::Texture m_heartTexture;
	int m_maxSprites;
	sf::Sprite m_heartSprite[3];
	sf::Vector2f m_posHearts;
	sf::Text m_text;

	sf::Text m_scoreText;

	int m_countdown;
	bool m_counting = true;
	int m_coins;
	
	//background track
	sf::SoundBuffer m_songBuff;
	sf::Sound m_song;

	sf::Text m_timerText;
	sf::Text m_loserText;
	sf::Vector2f m_timerPos;

	bool m_win;
	bool m_loser;
	float m_size;
	sf::Texture m_blackText;
	sf::Sprite m_blackSprite;
	sf::FloatRect m_textRect;
	sf::Text m_textWin;
	float m_inText;
	float m_fTime;
	sf::Shader m_shader;
	sf::Time m_shaderTime;;
	float updateShader;
	sf::String m_string;
	sf::Text m_textMessage;
	sf::Font m_tutFont;
	
	sf::Sprite m_portalSprite;
	sf::Texture m_portalTexture;
	
};
#endif // !
