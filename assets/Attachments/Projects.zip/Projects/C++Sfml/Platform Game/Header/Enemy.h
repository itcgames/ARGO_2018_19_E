#pragma once
#ifndef ENEMY
#define ENEMY	
#include "Game.h"
#include <SFML\Graphics.hpp>
#include "KeyHandler.h"
#include <SFML\Audio.hpp>

class Game;


class Enemy
{
public:
	Enemy(Game& game, float x, float y);
	~Enemy();
	void update(sf::Time deltaTime);
	void render(sf::RenderWindow& window);
	void setPosition(sf::Vector2f curPos);
	void setVelocity(float curVel);
	sf::Vector2f getPosition();
	sf::Texture m_texture;
	sf::RectangleShape m_enemyRec;
	bool m_moveRight;
	bool m_moveLeft; 
	sf::Vector2f m_velocity;
	bool m_onPlatform;
	bool m_alive = true;
	bool m_onFloor = false;
private:
	Game *m_game;
	sf::Time m_cumulativeTime;
	sf::Window m_window;
	sf::Time m_deadTime;
	sf::Vector2f m_position;

	
};

#endif // !