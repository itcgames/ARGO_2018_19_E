#pragma once
#ifndef ANIMATION
#define ANIMATION	
#include "Header/Game.h"
#include <SFML\Graphics.hpp>
#include "Header/KeyHandler.h"

class Game;


class Animation
{
public:
	Animation(sf::Texture * texture, sf::Vector2u imageCount, sf::Time switchTime, Game& game);
	Animation();
	~Animation();
	void setCurrentImageX();
	void update(int row, sf::Time deltaTime);
	sf::IntRect m_uvRect;
	bool m_stopAnime = false;
private:
	sf::Vector2u m_imageCount;
	sf::Vector2u m_currentImage;
	Game *m_game;
	sf::Time m_totalTime;
	sf::Time m_switchTime;

};
#endif // !

