#pragma once

#include <SFML/System/Vector2.hpp>
#include <SFML\Graphics.hpp>
#include <vector>
#include <sstream>
#include <fstream>
#include <iostream>
#include "yaml-cpp\yaml.h"


struct PathData
{
	std::string m_type;
	sf::Vector2f m_position;
	double m_rotation;
};

struct EnemyData
{
	std::string m_type;
	sf::Vector2f m_position;
	bool m_alive;
};

struct JumperData
{
	std::string m_type;
	sf::Vector2f m_position;
	bool m_alive;
};

struct FallingPathData
{
	std::string m_type;
	sf::Vector2f m_position;
	double m_rotation;
};

struct StickyPathData
{
	std::string m_type;
	sf::Vector2f m_position;
	double m_rotation;
};

struct SlipPathData
{
	std::string m_type;
	sf::Vector2f m_position;
	double m_rotation;
};

struct CoinData
{
	std::string m_type;
	sf::Vector2f m_position;
	bool m_alive;
};

struct LevelData
{
	std::vector<PathData> m_paths;
	std::vector<FallingPathData> m_fallingPaths;
	std::vector<StickyPathData> m_stickyPaths;
	std::vector<SlipPathData> m_slipPaths;
	std::vector<CoinData> m_coinData;
	std::vector<EnemyData> m_enemyData;
	std::vector<JumperData> m_jumperData;
	FallingPathData send(FallingPathData data);
	EnemyData send(EnemyData data);
	PathData send(PathData data);
	StickyPathData send(StickyPathData data);
	SlipPathData send(SlipPathData data);
	CoinData send(CoinData data);
	JumperData send(JumperData data);
	sf::Vector2f current;
	bool m_bool;
};

class LevelLoader
{
public:

	LevelLoader();

	static bool load(int nr, LevelData& level);
};
