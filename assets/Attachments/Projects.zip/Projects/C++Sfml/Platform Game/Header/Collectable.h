#pragma once

#ifndef COLLECTABLE
#define COLLECTABLE	
#include "Game.h"
#include <SFML\Graphics.hpp>
#include "Header/KeyHandler.h"

class Game;
class KeyHandler;
class Player;

class Collectable
{
public:
	Collectable(Game& Game, float x, float y, Player &player);
	~Collectable();
	void update(sf::Time deltaTime);
	void render(sf::RenderWindow& window);
	void setPosition(sf::Vector2f pos);
	sf::Vector2f getPosition();
	sf::Sprite m_sprite;
	sf::Texture m_texture;
	sf::RectangleShape m_coinRec;
	sf::Vector2f m_position;
	
	Player * m_player;

private:
	Game *m_game;//pointer to games class 
	sf::Time m_time;
	KeyHandler m_keyhandler;
	
};

#endif //Collectable