/// <summary>
/// @author  Conor O'Toole - C00206724
/// simple class for explaining the game controls.
/// </summary>

#pragma once
#ifndef INSTRUCTIONS
#define INSTRUCTIONS
#include "Header\Game.h"
#include <SFML\Graphics.hpp>
#include "Header\KeyHandler.h"

class Instructions
{
public:
	Instructions(Game & game, sf::Font font, KeyHandler & key);
	~Instructions();
	void update(sf::Time deltaTime);
	void render(sf::RenderWindow& window);
	void menuControl();

private:

	Game *m_game;

	//Actual reading for players
	sf::Text m_arrows[5];
	sf::Sprite m_arrowBtns[5];
	sf::RectangleShape m_divider;
	sf::Text m_returnText;
	sf::Texture m_arrowBtnsTexture[4];
	sf::Texture m_doubleJumpTexture;

	KeyHandler & m_keyhandler;
	sf::Font m_font;

	//Shades to make our menu not boring
	sf::Shader m_skyShader;
	sf::Texture m_blankTexture;
	sf::Sprite m_blankSprite;
	float m_updateShader;
	sf::Time m_shaderTime;


};

#endif // INSTRUCTIONS
