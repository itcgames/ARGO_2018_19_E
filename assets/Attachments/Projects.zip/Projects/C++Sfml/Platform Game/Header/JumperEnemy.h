#pragma once
#ifndef JUMPERENEMY
#define JUMPERENEMY	
#include "Header/Game.h"
#include <SFML\Graphics.hpp>
#include <SFML\Audio.hpp>

class Game;

class JumperEnemy
{
public:
	JumperEnemy(Game& game, float x, float y);
	~JumperEnemy();
	void update(sf::Time deltaTime);
	void render(sf::RenderWindow& window);
	void setPosition(sf::Vector2f curPos);
	void setVelocity(float curVel);
	void addForce();
	void subForce();
	void jumpOne();
	void jumpTwo();
	sf::Vector2f getPosition();
	sf::Texture m_texture;
	sf::RectangleShape m_enemyRec;
	bool m_moveRight;
	bool m_moveLeft;
	sf::Vector2f m_velocity;
	bool m_onPlatform;
	bool m_alive = true;
	bool m_onFloor = false;
	bool m_jumpedRight = false;
	bool m_jumpedLeft = false;
	bool m_add = true;
	bool m_subtract = false;
	bool m_inAir = false;
private:
	Game *m_game;
	sf::Time m_cumulativeTime;
	sf::Window m_window;
	sf::Time m_deadTime;
	sf::Vector2f m_position;
	float m_fricCoeff = 0.8f;
	double m_acceleration;
	double m_length;
	
	
};

#endif // !