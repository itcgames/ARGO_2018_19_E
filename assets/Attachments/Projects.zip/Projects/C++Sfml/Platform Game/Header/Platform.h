#pragma once
#ifndef PLATFORM
#define PLATFORM	
#include "Header\Game.h"
#include <SFML\Graphics.hpp>

class Platform
{
public:
	Platform(Game & game, sf::Font font);
	~Platform();
	void update();
	void render(sf::RenderWindow & window);
	void setPosition(float x, float y);
	sf::Vector2<float> m_posVec;
	

protected:


private:
	Game *m_game;//pointer to games class 
	
	float m_xPos;
	float m_yPos;

	sf::Sprite m_sprite;
	sf::Texture m_texture;

};

#endif // !PLATFORM
