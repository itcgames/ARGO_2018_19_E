/// <summary>
/// @author  Conor O'Toole - C00206724
/// simple class for changing in game settings.
/// </summary>

#pragma once
#ifndef SETTINGS
#define SETTINGS

#include "Header\Game.h"
#include <SFML\Graphics.hpp>
#include "Header\KeyHandler.h"


class Settings
{
public:
	Settings(Game & game, sf::Font font, KeyHandler & key);
	~Settings();
	void update(sf::Time deltaTime);
	void render(sf::RenderWindow& window);
	void menuControl();

private:
	Game *m_game;//pointer to games class 
	sf::Time m_cumulativeTime;//the time 
	sf::Font m_font;
	sf::Window m_window;
	sf::Time time;
	sf::Mouse mouse;
	sf::Sprite menuSprite;
	sf::Texture menuTexture;
	sf::RectangleShape settingButton[9];//array for buttons
	KeyHandler & m_keyhandler;
	sf::Text m_textMessage[3];//text
	sf::Text m_difficulty[2]; // Changing difficulty
	sf::Text m_sound; // toggle sound
	sf::Text m_music; // toggle music
	sf::CircleShape m_marker; //position indicator
	int m_index;
	bool m_pressed;

	//toggling
	bool m_soundFX;
	bool m_musicFX;
	bool m_eZhard;
	bool m_toggle;

	//shader
	sf::Shader m_grassShader;
	sf::Texture m_blankTexture;
	sf::Sprite m_blankSprite;
	float m_updateShader;
	sf::Time m_shaderTime;
};

#endif // SETTINGS