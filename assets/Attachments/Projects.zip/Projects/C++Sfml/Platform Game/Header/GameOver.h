#pragma once
#ifndef GAMEOVER
#define GAMEOVER
#include "Header\Game.h"
#include "Header\Keyhandler.h"
#include <SFML\Graphics.hpp>

class Player;
class GameOver
{
public:
	GameOver(Game & game, sf::Font font, KeyHandler & key);
	~GameOver();
	void update(sf::Vector2f pos, Player &player);
	void render(sf::RenderWindow & window);
	void winOrLose();
	bool m_returnToMenu;

private:
	Game * m_game;
	KeyHandler * m_keyhandle;

	int m_score;
	int m_coinsScore;
	int m_enemiesShot;

	//Score Text
	sf::Text m_totalScore;
	sf::Text m_coinTotal;
	sf::Text m_enemyTotal;

	//Score title text
	sf::Text m_titleScore;
	sf::Text m_coinTitle;
	sf::Text m_enemyTitle;

	sf::Text m_finText;
	sf::Sprite m_sprite;
	sf::Texture m_texture;
	sf::Window m_window;
	sf::Font m_font;

	
};

#endif // !
