#pragma once

#include "Header/Game.h"
#include "Header/Particle.h"
#include <list>
#include <SFML\Graphics.hpp>

class ParticleSystem
{
public:
	ParticleSystem(sf::Vector2f& position);
	~ParticleSystem();
	void addParticle();
	void render(sf::RenderWindow& window);
	void run();

private:
	sf::Vector2f m_position;
	sf::Sprite m_sprite;
	sf::Texture m_texture;
	std::vector<std::shared_ptr<Particle>>* m_particles;
};

