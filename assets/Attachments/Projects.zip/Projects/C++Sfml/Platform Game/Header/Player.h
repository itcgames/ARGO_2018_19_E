#pragma once
#ifndef PLAYER
#define PLAYER	
#include "Header\Game.h"
#include <SFML\Graphics.hpp>
#include "KeyHandler.h"
#include "Header\GameOver.h"
#include <SFML\Audio.hpp>


class Game;
class KeyHandler;
class GameScreen;
class GameOver;
class Player
{
public:
	Player(Game& Game, KeyHandler &keyhandle, GameOver &  gameOver);
	~Player();
	void update(sf::Time deltaTime, GameScreen &gScreen);
	void render(sf::RenderWindow& window);
	void changeLives();
	void resetPlayer();
	void init();
	void screenCollide();
	sf::Vector2f getPosition();
	void resetView();
	void setPosition(sf::Vector2f curPos);
	bool getWinner();
	bool getLoser();
	void checkWin(sf::Time dt);
	void moveLeft();
	void moveRight();
	void jump();
	void doubleJump();
	void setHeight(float height);
	void setSpeed(float speed);
	bool m_pressed = false;
	bool m_fired = false;
	bool m_caught = false;
	bool m_colliding = false;
	bool m_doubleJump = false;
	sf::Sprite m_sprite;
	sf::Texture m_texture;
	sf::RectangleShape m_playerRec;
	sf::View m_follow;
	sf::Vector2f m_position;
	sf::Vector2f m_velocity;
private:
	Game *m_game;//pointer to games class 
	GameOver *m_gameOver;
	sf::Time m_cumulativeTime;//the time 
	sf::Font m_font;
	sf::Window m_window;
	sf::Time m_time;
	sf::Mouse m_mouse;
	sf::Vector2f m_lastPos;
	sf::Vector2f m_scrollSpeed;
	KeyHandler m_keyhandler;
	float m_speed;
	float m_height;
	float m_fricCoeff = 0.8f;
	sf::SoundBuffer m_jumpBuffer;
	sf::Sound m_jumpSound;
	double m_acceleration;
	double m_length;
	float speed;
	bool m_winner = false;
	int m_lives;
	bool moving = false;
	bool m_collided = false;
	bool m_onLeft = false;
	bool m_onRight = false;
	bool m_exit = false;
	sf::Vector2f m_otherPos;
};
#endif // !