#pragma once
#ifndef PREGAME
#define PREGAME	
#include "Header\Game.h"
#include <math.h>     
#include <SFML\Graphics.hpp>
#include "Header\KeyHandler.h"

class Game;

class PreGame
{
public:
	PreGame(Game& Game, sf::Font font, KeyHandler & key);
	~PreGame();
	void update(sf::Time time);
	void render(sf::RenderWindow& window);

private:
	Game *m_game;//pointer to games class 
	sf::Font m_font;
	sf::Window m_window;
	sf::Time m_time;
	sf::Texture m_texture;
	sf::Sprite m_sprite;
	sf::Text m_levelText[2];
	KeyHandler & m_keyhandler;
	int m_index;
	bool m_pressed;
	bool m_change = true;
};
#endif // !
