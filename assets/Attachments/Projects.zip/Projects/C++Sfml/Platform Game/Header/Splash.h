#pragma once
#ifndef SPLASH
#define SPLASH	
#include "Header\Game.h"
#include <SFML\Graphics.hpp>
class Game;

class Splash
{
public:
	Splash(Game& Game, sf::Font font);
	~Splash();
	void update(sf::Time deltaTime);
	void render(sf::RenderWindow& window);
	void changeState();
private:
	Game *m_game;//pointer to games class 
	sf::Time m_cumulativeTime;//the time 
	sf::Font m_font;
	sf::Sprite splashSprite;
	sf::Texture texture;
	sf::Window m_window;
	sf::Time time;
	sf::Text text;
	sf::Mouse mouse;
	sf::Texture m_shderTexture;
	sf::Sprite m_shaderSprite;
	sf::Shader m_shader;
	float m_updateShader;
	sf::Time m_shaderTime;
};
#endif // !
