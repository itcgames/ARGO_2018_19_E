#pragma once
#ifndef MAINMENU
#define MAINMENU	
#include "Header\Game.h"
#include <SFML\Graphics.hpp>
#include "Header\KeyHandler.h"
class Game;
class KeyHandler;

class MainMenu
{
public:
	MainMenu(Game& Game, sf::Font font, KeyHandler & key);
	~MainMenu();
	void update(sf::Time deltaTime);
	void render(sf::RenderWindow& window);
	void changeState();
	bool close;
private:
	Game *m_game;//pointer to games class 
	sf::Time m_cumulativeTime;//the time 
	sf::Font m_font;
	sf::Window m_window;
	sf::Time time;
	sf::Mouse mouse;
	sf::Sprite menuSprite;
	sf::Texture menuTexture;
	sf::RectangleShape settingButton[9];//array for buttons
	KeyHandler & keyhandler;
	sf::Text m_textMessage[5];//text
	//used for changing the colour of text on the menu
	int index;
	sf::CircleShape m_marker;
	//bool play = false;
	bool play = true;
	bool GameSettings = false;
	bool audioSettings = false;
	bool pressed = false;
	bool quit = false;
	
	
};
#endif // !