/// <summary>
/// @Authors Conor O'Toole/James Condon
/// A class that creates a simple bullet
/// Loads Texture, assigns texture.
/// listens for button press and adds physics.
/// </summary>

#pragma once
#ifndef BULLET
#define BULLET	
#include "Game.h"
#include <SFML\Graphics.hpp>
#include "KeyHandler.h"
#include <SFML\Audio.hpp>

class Game;
class KeyHandler;
class Player;

class Bullet
{
public:
	Bullet(Game & game, KeyHandler & keyhandle, Player & player);
	~Bullet();

	void initialize();
	void update(sf::Time dt);
	void draw(sf::RenderWindow & window);
	void fireRight();
	void fireLeft();
	bool boundaryCollision();
	bool checkEnemyCollision(sf::Vector2f curPos);
	void resetBullet();
	sf::Vector2f getPosition();
	bool m_fired;
	bool m_aliveRight;
	bool m_aliveLeft;
	//bool m_alive;
	bool m_alive;
private:

	//Vectors,textures,sprites,colliders,bools and tools
	sf::SoundBuffer m_laserbuf;
	sf::Sound m_lasersound;

	Game *m_game;//pointer to games class 
	KeyHandler *m_keyhandle;
	Player * m_player;

	//Vectors,textures,sprites,colliders,bools
	sf::Vector2f m_pos;
	sf::Vector2f m_velocity;
	sf::Vector2f m_holder;
	//images
	sf::Texture m_texture;
	sf::Sprite m_sprite;
	//activasions
	
	int indexRight = 0;
	int indexLeft = 0;
	sf::Time m_time;
	


};

#endif // !BULLET