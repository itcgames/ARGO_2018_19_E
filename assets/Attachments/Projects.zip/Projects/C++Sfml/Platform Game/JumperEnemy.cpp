#include "Header/JumperEnemy.h"
#include <Thor/Vectors.hpp>

JumperEnemy::JumperEnemy(Game& game, float x, float y) :
	m_game(&game),
	m_position(x, y),
	m_moveLeft(false),
	m_moveRight(true),
	m_velocity(0, 0),
	m_onPlatform(false),
	m_acceleration(0),
	m_length(0)
{
	m_enemyRec.setPosition(sf::Vector2f(m_position));
	m_enemyRec.setSize(sf::Vector2f(50, 60));
	m_texture.loadFromFile("./resources/images/jumperSpritesheet.png");
	m_enemyRec.setTexture(&m_texture);
}

JumperEnemy::~JumperEnemy()
{
}

void JumperEnemy::update(sf::Time deltaTime)
{
	m_cumulativeTime += deltaTime;
	m_position.y = m_position.y + m_velocity.y * m_cumulativeTime.asSeconds()
		+ 0.5 * (9.81 * 150) * m_cumulativeTime.asSeconds()  * m_cumulativeTime.asSeconds();
	if (m_velocity.x != 0)
	{
		auto normalisedVel = thor::unitVector(m_velocity);
		m_acceleration = normalisedVel.x;
	}
	
	

	if (m_onPlatform == true && m_alive == true)
	{
		if (m_moveRight == true) {
			if (m_add)
			addForce();
		}
		else if(m_moveLeft == true) {
			if (m_subtract)
				subForce();
		}
	}
	if (!m_alive)
	{
		m_deadTime += deltaTime;
		if (m_deadTime.asMilliseconds() > 300)
		{
			m_onFloor = true;
		}
	}
	else
	{
		m_position.x = m_position.x + m_velocity.x * m_cumulativeTime.asSeconds() + 0.5 * m_acceleration *(m_cumulativeTime.asSeconds() * m_cumulativeTime.asSeconds());
		m_acceleration = -(m_fricCoeff)* 9.81 * -m_acceleration;
	}

	if (m_position.y < 1000)
	{
		m_velocity.y = m_velocity.y + (9.81 * 150) * m_cumulativeTime.asSeconds();
		
	}
	m_velocity.x = m_velocity.x + m_acceleration * m_cumulativeTime.asSeconds();
	//stops the enemy from moving under starting Pos
	if (m_position.y > 1000)
	{
		m_velocity.y = 0;
		m_position.y = 1000;
		//m_colliding = false;
	}

	m_enemyRec.setPosition(m_position);
	m_cumulativeTime = sf::Time::Zero;
}

sf::Vector2f JumperEnemy::getPosition()
{
	return m_position;
}

void JumperEnemy::addForce()
{
	m_velocity.x = 0;
	m_velocity.x = m_velocity.x += 160;
	m_add = false;
}
void JumperEnemy::subForce()
{
	m_velocity.x = 0;
	m_velocity.x = m_velocity.x -= 160;
	m_subtract = false;
}
void JumperEnemy::setPosition(sf::Vector2f curPosition)
{
	m_position = curPosition;
}

void JumperEnemy::setVelocity(float curVelocity)
{
	m_velocity.x = curVelocity;
	m_moveLeft = false;
	m_moveRight = false;
}

void JumperEnemy::render(sf::RenderWindow& window)
{
	if (m_alive)
	window.draw(m_enemyRec);
}

void JumperEnemy::jumpOne()
{
	m_velocity.y -= 500;
	m_jumpedRight = true;
	m_inAir = true;
	//m_velocity.x += 80;
}
void JumperEnemy::jumpTwo()
{
	m_velocity.y -= 500;
	m_jumpedLeft = true;
	m_inAir = true;
	//m_velocity.x += 80;
}

