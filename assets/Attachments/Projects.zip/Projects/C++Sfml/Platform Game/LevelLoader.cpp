#include "Header/LevelLoader.h"
#include <time.h>
void operator >> (const YAML::Node& pathNode, PathData& path)
{
	path.m_type = pathNode["type"].as<std::string>();
	path.m_position.x = pathNode["position"]["x"].as<float>();
	path.m_position.y = pathNode["position"]["y"].as<float>();

}
void operator >> (const YAML::Node& pathNode, FallingPathData& path)
{
	path.m_type = pathNode["type"].as<std::string>();
	path.m_position.x = pathNode["position"]["x"].as<float>();
	path.m_position.y = pathNode["position"]["y"].as<float>();

}
void operator >> (const YAML::Node& pathNode, EnemyData& path)
{
	path.m_type = pathNode["type"].as<std::string>();
	path.m_position.x = pathNode["position"]["x"].as<float>();
	path.m_position.y = pathNode["position"]["y"].as<float>();
	path.m_alive = pathNode["bool"].as<bool>();

}

void operator >> (const YAML::Node& pathNode, StickyPathData& path)
{
	path.m_type = pathNode["type"].as<std::string>();
	path.m_position.x = pathNode["position"]["x"].as<float>();
	path.m_position.y = pathNode["position"]["y"].as<float>();


}
void operator >> (const YAML::Node& pathNode, SlipPathData& path)
{
	path.m_type = pathNode["type"].as<std::string>();
	path.m_position.x = pathNode["position"]["x"].as<float>();
	path.m_position.y = pathNode["position"]["y"].as<float>();

}

void operator >> (const YAML::Node& pathNode, CoinData& path)
{
	path.m_type = pathNode["type"].as<std::string>();
	path.m_position.x = pathNode["position"]["x"].as<float>();
	path.m_position.y = pathNode["position"]["y"].as<float>();
	path.m_alive = pathNode["bool"].as<bool>();
}

void operator >> (const YAML::Node& pathNode, JumperData& path)
{
	path.m_type = pathNode["type"].as<std::string>();
	path.m_position.x = pathNode["position"]["x"].as<float>();
	path.m_position.y = pathNode["position"]["y"].as<float>();
	path.m_alive = pathNode["bool"].as<bool>();
}

void operator >> (const YAML::Node& levelNode, LevelData& level)
{

	const YAML::Node& pathNode = levelNode["paths"].as<YAML::Node>();
	for (unsigned i = 0; i < pathNode.size(); ++i)
	{

		PathData path;
		pathNode[i] >> path;
		level.m_paths.push_back(path);
		level.send(path);
		level.current = path.m_position;
	}
	const YAML::Node& fallpathNode = levelNode["falling"].as<YAML::Node>();
	for (unsigned i = 0; i < fallpathNode.size(); ++i)
	{

		FallingPathData path;
		fallpathNode[i] >> path;
		level.m_fallingPaths.push_back(path);
		level.send(path);
		level.current = path.m_position;
	}
	const YAML::Node& stickyPathData = levelNode["sticky"].as<YAML::Node>();
	for (unsigned i = 0; i < stickyPathData.size(); ++i)
	{

		StickyPathData path;
		stickyPathData[i] >> path;
		level.m_stickyPaths.push_back(path);
		level.send(path);
		level.current = path.m_position;
	}
	const YAML::Node& slippyPathData = levelNode["slippy"].as<YAML::Node>();
	for (unsigned i = 0; i < slippyPathData.size(); ++i)
	{

		SlipPathData path;
		slippyPathData[i] >> path;
		level.m_slipPaths.push_back(path);
		level.send(path);
		level.current = path.m_position;
	}
	const YAML::Node& enemyData = levelNode["enemy"].as<YAML::Node>();
	for (unsigned i = 0; i < enemyData.size(); ++i)
	{
		EnemyData data;
		enemyData[i] >> data;
		level.m_enemyData.push_back(data);
		level.send(data);
		level.current = data.m_position;
		level.m_bool = data.m_alive;
	}

	const YAML::Node& coinData = levelNode["coin"].as<YAML::Node>();
	for (unsigned i = 0; i < coinData.size(); ++i)
	{
		CoinData data;
		coinData[i] >> data;
		level.m_coinData.push_back(data);
		level.send(data);
		level.current = data.m_position;
		level.m_bool = data.m_alive;
	}

	const YAML::Node& jumperData = levelNode["jumper"].as<YAML::Node>();
	for (unsigned i = 0; i < jumperData.size(); ++i)
	{
		JumperData data;
		jumperData[i] >> data;
		level.m_jumperData.push_back(data);
		level.send(data);
		level.current = data.m_position;
		level.m_bool = data.m_alive;
	}

}
LevelLoader::LevelLoader()
{
}

bool LevelLoader::load(int nr, LevelData& level)
{
	std::stringstream ss;
	ss << "./resources/levels/level";
	ss << nr;
	ss << ".yaml";

	try
	{
		YAML::Node baseNode = YAML::LoadFile(ss.str());
		if (baseNode.IsNull())
		{
			std::string message("file: " + ss.str() + " not found");
			throw std::exception(message.c_str());
		}
		baseNode >> level;
	}
	catch (YAML::ParserException& e)
	{
		std::cout << e.what() << "\n";
		return false;
	}
	catch (std::exception& e)
	{
		std::cout << e.what() << "\n";
		return false;
	}

	return true;
}

PathData LevelData::send(PathData data)
{
	return data;
}
FallingPathData LevelData::send(FallingPathData data)
{
	return data;
}

StickyPathData LevelData::send(StickyPathData data)
{
	return data;
}

SlipPathData LevelData::send(SlipPathData data)
{
	return data;
}


CoinData LevelData::send(CoinData data)
{
	return data;
}
EnemyData LevelData::send(EnemyData data)
{
	return data;
}

JumperData LevelData::send(JumperData data)
{
	return data;
}