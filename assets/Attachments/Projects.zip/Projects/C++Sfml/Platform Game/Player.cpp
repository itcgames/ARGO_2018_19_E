#include "Header/Player.h"
#include <Thor/Vectors.hpp>

#include <iostream>

Player::Player(Game & game, KeyHandler & keyhandle, GameOver &  gameOver) :
	m_game(&game),
	m_keyhandler(keyhandle),
	m_gameOver(&gameOver),
	m_scrollSpeed(0,-.5),
	m_position(1000,1000),
	m_velocity(1,1),
	m_speed(5),
	m_acceleration(0),
	m_length(0),
	m_height(250),
	m_lives(3)
{
	m_jumpBuffer.loadFromFile("resources/sounds/jumping.wav");
	m_jumpSound.setBuffer(m_jumpBuffer);
	m_playerRec.setPosition(sf::Vector2f(m_position));
	m_playerRec.setSize(sf::Vector2f(60, 60));
	
	
	
}

void Player::init()
{
	m_texture.loadFromFile("resources/images/tempnew.png");
	m_playerRec.setTexture(&m_texture);
	m_lives = 3;
	m_follow.setViewport(sf::FloatRect(0, 0, 1.5, 1.5));
	m_follow.setSize(1000, 650);
	m_follow.setCenter(m_playerRec.getPosition().x + 170, m_playerRec.getPosition().y + 100);
	m_caught = false;
}

Player::~Player()
{
	std::cout << "destructing Splash" << std::endl;

}
void Player::changeLives()
{
	m_lives--;
}
void Player::update(sf::Time deltaTime, GameScreen &gScreen)
{
	
	m_cumulativeTime += deltaTime;
	
	screenCollide();
	
	if (m_collided == true && m_lives > 0)
	{
		resetPlayer();
		gScreen.changeLives();
		resetView();	
		m_time = sf::Time::Zero;
		changeLives();
		m_collided = false;
	}
	//sets the lastPos of the follow camera every frame 
	m_lastPos.y = m_follow.getCenter().y;

	//will move the follow camera with the player 
	if (m_position.x < 800 && m_position.x > 650)
	{
		m_follow.setCenter(m_playerRec.getPosition().x + 300, m_lastPos.y);

	}
	//will move the follow camera with the player 
	if (m_position.x > 1200)
	{
		m_follow.setCenter(m_playerRec.getPosition().x - 100, m_lastPos.y);

	}

	//std::cout << m_otherPos.x << std::endl;
	
	///uses real time using formula 
	m_position.y = m_position.y + m_velocity.y * m_cumulativeTime.asSeconds()
	+ 0.5 * (9.81 * 150) * m_cumulativeTime.asSeconds()  * m_cumulativeTime.asSeconds();
	
	if (m_position.y < 1000)
	{

		m_velocity.y = m_velocity.y + (9.81 * 150) * m_cumulativeTime.asSeconds();
		/*m_velocity.x = m_velocity.x + m_acceleration * m_cumulativeTime.asSeconds();*/
	}
	//stops the player from moving under starting Pos
	if (m_position.y > 1000)
	{
		m_velocity.y = 0;
		m_position.y = 1000;
		m_pressed = false;
		m_colliding = false;
		m_doubleJump = false;
	}
	
	//follows the player in the y direction
	if (m_game->m_currentLevel != 1)
	{
		m_time += deltaTime;
		if (m_time.asSeconds() > 3 && !m_caught)
		{
			if (!m_winner)
			{
				m_follow.move(m_scrollSpeed);
			}
		}
	}
	if (m_game->m_currentLevel == 1)
	{
		if (m_game->m_bulletShot)
		{
			m_time += deltaTime;
			if (m_time.asSeconds() > 3 && !m_caught)
			{
				if (!m_winner)
				{
					m_follow.move(m_scrollSpeed);
				}
			}
		}
	}

	
	m_playerRec.setPosition(m_position);
	m_cumulativeTime = sf::Time::Zero;
	
	checkWin(deltaTime);

	
}
/// <summary>
/// checks if the player is colliding with the follow camera 
/// offset is created to check for collision
/// </summary>
void Player::screenCollide()
{
	if (m_lives < 1)
	{
		m_caught = true;
		m_game->playedOnce = true;
	}
	if (m_follow.getCenter().y + 120 < m_position.y + 50)
	{
		m_otherPos.x = m_position.x;
		if (m_lives < 1)
		{
			m_caught = true;
		}
		m_collided = true;
	}
	
}

void Player::resetView()
{
	if (m_otherPos.x > 1100) {
		m_follow.setCenter(m_playerRec.getPosition().x - 170, m_playerRec.getPosition().y + 100);
	}
	else if (m_otherPos.x < 800) {
		m_follow.setCenter(m_playerRec.getPosition().x + 670, m_playerRec.getPosition().y + 100);
	}
	else {
		m_follow.setCenter(m_playerRec.getPosition().x + 170, m_playerRec.getPosition().y + 100);
	}
	
}

void Player::render(sf::RenderWindow & window)
{
	
	//window.setView(m_follow);
	if (m_game->inGame == true)
	{
		//m_follow.setViewport(sf::FloatRect(0, 0, 1.5, 1.5));
		window.setView(m_follow);
		window.draw(m_playerRec);
	}
	else
	{
		//m_follow.setViewport(sf::FloatRect(0, 0, 1, 1));
		window.setView(m_follow);
	}
	
}

/// <summary>
/// moves the player in to the left of the screen 
/// as long as within bounds 
/// </summary>
void Player::moveLeft()
{
	if (m_position.x > 465)
		m_position.x -= m_speed;
}
/// <summary>
/// moves the player to the right of the screen 
/// as long as within bounds
/// </summary>
void Player::moveRight()
{
	if (m_position.x  < 1355)
		m_position.x += m_speed;
}
/// <summary>
/// negates a y velocity from the players to jump
/// sets the jump pressed to true
/// </summary>
void Player::jump()
{
	m_pressed = true;
	m_velocity.y -= 500;
	m_jumpSound.play();
}
void Player::doubleJump()
{
	m_doubleJump = true;
	//m_pressed = false;
	m_velocity.y -= m_height;
	m_jumpSound.play();
}



sf::Vector2f Player::getPosition()
{
	return m_position;
}

void Player::setPosition(sf::Vector2f curPosition)
{
	m_position = curPosition;
}

void Player::checkWin(sf::Time dt)
{
	if (m_game->m_win)
	{
		m_winner = true;
		m_game->setGameState(GameState::GameOver);
	}
}

bool Player::getWinner()
{
	return m_winner;
}

bool Player::getLoser()
{
	return m_caught;
}

void Player::setHeight(float height)
{
	m_height = height;
}

void Player::setSpeed(float speed)
{
	m_speed = speed;
}

void Player::resetPlayer()
{
	m_position = sf::Vector2f(1000, 1000);
}
