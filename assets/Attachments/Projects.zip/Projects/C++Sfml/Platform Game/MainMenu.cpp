#include "Header/MainMenu.h"
#include <iostream>

MainMenu::MainMenu(Game & game, sf::Font font, KeyHandler & key) :
	m_game(&game),
	m_font(font),
	index(1),
	m_marker(25, 25),
	keyhandler(key)
	
	
{
	//mouse.setPosition(sf::Vector2i(200, 200));

	menuTexture.loadFromFile("resources/images/mainmenu.png");
	menuSprite.setTexture(menuTexture);
	m_textMessage[0].setCharacterSize(100);
	m_textMessage[0].setFont(m_font);
	m_textMessage[0].setString("Play Game");
	m_textMessage[0].setPosition(600, 200);
	m_textMessage[0].setFillColor(sf::Color(0, 0, 255));
	m_textMessage[0].setOutlineColor(sf::Color(0, 0, 0));
	m_textMessage[0].setOutlineThickness(2);

	m_textMessage[1].setCharacterSize(100);
	m_textMessage[1].setFont(m_font);
	m_textMessage[1].setString("Game settings");
	m_textMessage[1].setPosition(600, 350);
	m_textMessage[1].setFillColor(sf::Color(0, 0, 0));

	m_textMessage[3].setCharacterSize(100);
	m_textMessage[3].setFont(m_font);
	m_textMessage[3].setString("Instructions");
	m_textMessage[3].setPosition(600, 500);
	m_textMessage[3].setFillColor(sf::Color(0, 0, 0));

	m_textMessage[4].setCharacterSize(100);
	m_textMessage[4].setFont(m_font);
	m_textMessage[4].setString("Quit");
	m_textMessage[4].setPosition(600, 650);
	m_textMessage[4].setFillColor(sf::Color(0, 0, 0));

	m_marker.setRadius(25);
	m_marker.setPosition(300, 220);
	m_marker.setFillColor(sf::Color(255, 0, 0));

	

}

MainMenu::~MainMenu()
{
	std::cout << "destructing Splash" << std::endl;

}

/// <summary>
/// Update function for the main menu
/// This update does three things
/// changes menu appearance based on key presses
/// checks index of menunon each key update
/// changes the screen based on the menu index and key press
/// </summary>
/// <param name="deltaTime"></param>
void MainMenu::update(sf::Time deltaTime)
{
	time += deltaTime;
	m_cumulativeTime += deltaTime;
	
	

	if (keyhandler.isPressed(sf::Keyboard::Key::Up) == false && keyhandler.isPressed(sf::Keyboard::Key::Down) == false)
	{
		pressed = false;
	}

	// All checks for going down through the menu
	if (keyhandler.isPressed(sf::Keyboard::Key::Down) && false == pressed && index == 0)
	{
		m_marker.setPosition(300, 220);
		m_textMessage[4].setFillColor(sf::Color(0, 0, 0));
		m_textMessage[0].setFillColor(sf::Color(0, 0, 255));
		index = 1;
		pressed = true;
	}	
	if (keyhandler.isPressed(sf::Keyboard::Key::Down) && false == pressed && index == 1)
	{

		m_marker.setPosition(300, 370);
		m_textMessage[0].setFillColor(sf::Color(0, 0, 0));
		m_textMessage[1].setFillColor(sf::Color(0, 0, 255));
		index = 2;
		pressed = true;
	}	
	if (keyhandler.isPressed(sf::Keyboard::Key::Down) && false == pressed && index == 2)
	{

		m_marker.setPosition(300, 520);
		m_textMessage[1].setFillColor(sf::Color(0, 0, 0));
		m_textMessage[3].setFillColor(sf::Color(0, 0, 255));
		index = 3;
		pressed = true;
	}
	if (keyhandler.isPressed(sf::Keyboard::Key::Down) && false == pressed && index == 3)
	{

		m_marker.setPosition(300, 670);
		m_textMessage[3].setFillColor(sf::Color(0, 0, 0));
		m_textMessage[4].setFillColor(sf::Color(0, 0, 255));
		index = 0;
		pressed = true;
	}
	
	//All checks for indexing up through the menu
	//tried
	if (keyhandler.isPressed(sf::Keyboard::Key::Up) && false == pressed && index == 0)
	{

		m_marker.setPosition(300, 520);
		m_textMessage[4].setFillColor(sf::Color(0, 0, 0));
		m_textMessage[3].setFillColor(sf::Color(0, 0, 255));
		index = 3;
		pressed = true;
	}
	//tried
	if (keyhandler.isPressed(sf::Keyboard::Key::Up) && false == pressed && index == 1)
	{

		m_marker.setPosition(300, 670);
		m_textMessage[0].setFillColor(sf::Color(0, 0, 0));
		m_textMessage[4].setFillColor(sf::Color(0, 0, 255));
		index = 0;
		pressed = true;
	}
	//tried
	if (keyhandler.isPressed(sf::Keyboard::Key::Up) && false == pressed && index == 2)
	{
		
		m_marker.setPosition(300, 220);
		m_textMessage[1].setFillColor(sf::Color(0, 0, 0));
		m_textMessage[0].setFillColor(sf::Color(0, 0, 255));
		index = 1;
		pressed = true;
	}
	if (keyhandler.isPressed(sf::Keyboard::Key::Up) && false == pressed && index == 3)
	{

		m_marker.setPosition(300, 370);
		m_textMessage[3].setFillColor(sf::Color(0, 0, 0));
		m_textMessage[1].setFillColor(sf::Color(0, 0, 255));
		index = 2;
		pressed = true;
	}
	
	if (index == 1)
	{
		if (keyhandler.isPressed(sf::Keyboard::Key::Return))
		{
			m_game->setGameState(GameState::PreGame);
			std::cout << "change state";
		}
	}
	 if (index == 2)
	{
		if (keyhandler.isPressed(sf::Keyboard::Key::Return))
		{

			m_game->setGameState(GameState::GameSettings);
		}
	}
	if (index == 3)
	{
		if (keyhandler.isPressed(sf::Keyboard::Key::Return))
		{
			m_game->setGameState(GameState::Instructions);
		}
	}
	if (index == 0)
	{
		if (keyhandler.isPressed(sf::Keyboard::Key::Return))
		{
			close = true;
		}
	}

}

void MainMenu::changeState()
{

}

void MainMenu::render(sf::RenderWindow & window)
{

	window.draw(menuSprite);
	window.draw(m_textMessage[0]);
	window.draw(m_textMessage[1]);
	window.draw(m_textMessage[2]);
	window.draw(m_textMessage[3]);
	window.draw(m_textMessage[4]);
	window.draw(m_marker);

	for (int i = 0; i <= 4; i++)
	{
		window.draw(m_textMessage[i]);
	}
}

