#include "Header/Particle.h"



Particle::Particle(sf::Vector2f& position):
	m_position(position),
	m_acceleration(0,-.05),
	m_lifespan(1.0)
{
	float r = (rand() / (float)RAND_MAX * 2) + 1;
	float t = (rand() / (float)RAND_MAX * 3) + 1.5;
	m_velocity = sf::Vector2f(r, t);
}


Particle::~Particle()
{
}

bool Particle::isDead() const
{
	if (m_lifespan < 0.0)
	{
		return true;
	}
	else
	{
		return false;
	}
}
void Particle::update()
{
	m_velocity.x += m_acceleration.x;
	m_velocity.y += m_acceleration.y;
	m_position.x += m_velocity.x;
	m_position.y += m_velocity.y;
	m_lifespan -= -0.005;
}

void Particle::run() const
{

}
void Particle::render(sf::RenderWindow& window)
{
	
}
