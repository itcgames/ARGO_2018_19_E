class SmokeSystem
{
  constructor(locationX, locationY,img)
  {
    gameNs.particles = []
    this.originX = locationX
    this.originY = locationY
    this.image = img
    //this.no = 10000
  //  for (var i =0; i< 100; i++)
  //  {
      this.particle = new Smoke(this.originX,this.originY,this.image)
      gameNs.particles.push(this.particle)
    //}


  }

  setPosition(x,y)
  {
    this.originX = x;
    this.originY = y;
  }

  addParticle()
  {
    this.particle = new Particle(this.originX,this.originY,this.image)
		gameNs.particles.push(this.particle)
  }

  run()
  {
    var canvas = document.getElementById("mycanvas");
		var ctx = canvas.getContext("2d");

    //ctx.clearRect(0, 0, canvas.width, canvas.height)
    for (var i = 0; i <gameNs.particles.length;i++)
    {
      gameNs.particles[i].run()
      if (gameNs.particles[i].isDead())
      {
        gameNs.particles.splice(i,1)
      }
    }


  }

}
