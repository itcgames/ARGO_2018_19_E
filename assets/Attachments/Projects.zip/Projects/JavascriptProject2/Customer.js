/**
 * @author James Condon
 * C00207200
 * The scene class parent of the other scenes
 */
class Customer
{
  /**
   * @param {title} string
   * This is the constructor for the scene class
   * This sets the title to the scene
   */
   constructor(xpos,ypos,width,height,load,rand)
   {
      this.px = xpos;
      this.py = ypos;
      this.width = width;
      this.height = height;
      this.touched = false
      this.img = new Image();
      this.food = new Image();
      this.imgPizza = new Image();
      this.imgPasta = new Image();
      this.imgLasagna = new Image();
      this.bubble = new Image();
      this.alive = true;
      this.img.src = load['customerImg']
      this.imgPizza.src = load['PizzaImg'];
      this.imgPasta.src = load['SpagImg'];
      this.imgLasagna.src = load['LasagneImg'];
      this.bubble.src = load['thoughtBubblePOne'];
      document.addEventListener("touchstart", this.onTouchStart.bind(this), false);
      document.addEventListener("touchmove", this.onTouchMove.bind(this), false);
  	  document.addEventListener("touchend", this.onTouchEnd.bind(this), false);
      this.finished = false;
      var seconds;
      var minutes;
      this.seconds = 0;
      this.minutes = 0;
      this.touching = false;
      this.seatedFirst = false;
      this.seatedSecond = false;
      this.fps = 7;
      this.count = 0;
      this.tickPerFrame = 1000 /this.fps;
      this.time = 0;

      this.rnd = rand;

   }
   /**
    * @param {Date} deltaTime time
    * updates the sprite by checking if the tick are less than the time
    * the count is incremented. the count is multiplied by the image
    * width. when the count is more than length of the spritesheet its reset
    */
   update(number, dt)
   {

       if(dt != null)
          {
            this.time += dt;
          }
          var canvas = document.getElementById('mycanvas');
         var ctx = canvas.getContext('2d');


          //changes position of x of the spritesheet
          if(this.tickPerFrame < this.time)
          {

            this.count +=1;
            if(this.count > 5)
            {
              this.count = 0;
            }
              this.time =0;
          }



     if (this.checkCollision(gameNs.tableOne))
     {
         if (!gameNs.tableOne.tableFull)
         {
         gameNs.dinners[0].retrieveIndex(this.index)
         this.seatAtOne(gameNs.tableOne.seat[0])
         gameNs.tableOne.seatOneFull = true
         this.seatedFirst = true}
     }
     else if (this.checkCollision(gameNs.tableTwo))
     {
       if (!gameNs.tableTwo.tableFull && gameNs.game.tutorialOver === true)
       {
         gameNs.dinners[0].retrieveIndex(this.index)
         this.seatAtOne(gameNs.tableTwo.seat[0])
         gameNs.tableTwo.seatOneFull = true
         this.seatedFirst = true
       }
     }
     else if (this.checkCollision(gameNs.tableThree))
     {
       if (!gameNs.tableThree.tableFull && gameNs.game.tutorialOver === true)
       {
         gameNs.dinners[0].retrieveIndex(this.index)
         this.seatAtOne(gameNs.tableThree.seat[0])
         gameNs.tableThree.seatOneFull = true
         this.seatedFirst = true
       }
     }
     else if (this.checkCollision(gameNs.tableFour))
     {
       if (!gameNs.tableFour.tableFull && gameNs.game.tutorialOver === true)
       {
         gameNs.dinners[0].retrieveIndex(this.index)
         this.seatAtOne(gameNs.tableFour.seat[0])
         gameNs.tableFour.seatOneFull = true
         this.seatedFirst = true
       }
     }

     else if (!this.checkCollision(gameNs.tableOne) && this.touching === false ||
        !this.checkCollision(gameNs.tableTwo) && this.touching === false ||
        !this.checkCollision(gameNs.tableThree) && this.touching === false ||
        !this.checkCollision(gameNs.tableFour) && this.touching === false)
        {
          this.px = 500
          this.py = 1000

          if (this.rnd === 0)
          {
            this.food = this.imgPasta;
          }
         else if (this.rnd === 1)
         {
            this.food = this.imgPizza;
         }
         else if (this.rnd === 2)
         {
            this.food = this.imgLasagna;
         }
        }




     //console.log(this.touching)
   }
   detectHit(x1,y1,x2,y2,w,h)
   {
     //Very simple detection here
     if(x2-x1>w) return false;
     if(y2-y1>h) return false;
     return true;
   }
   onTouchStart(e)
   {
     this.touches = e.touches;
     this.touching = false
     this.startX = this.touches[0].clientX;
     this.startY = this.touches[0].clientY;

   }
   onTouchMove(e)
   {
 	   this.touches = e.changedTouches;
 	   this.endX = this.touches[0].clientX;
 	   this.endY = this.touches[0].clientY;
     if(this.detectHit(this.px, this.py, this.startX, this.startY, this.width, this.height) && !this.seatedFirst)
     {
       //console.log("collide")
        this.px = this.endX - 75;
        this.py = this.endY - 50;
        this.touching = true

      }
     this.startX = this.touches[0].clientX;
 	   this.startY = this.touches[0].clientY;
   }
   onTouchEnd(e)
   {
     this.touching = false
 	   this.endX = e.touches.clientX;
  	 this.endY = e.touches.clientY;
   }
   checkCollision(e)
 	{
 		var collides = false;

 		if ((this.px < e.x + e.width) &&
 				(this.px + this.width > e.x) &&
 				(this.py + this.height > e.y) &&
 				(this.py < e.y + e.height))
 		{
 			collides = true;
 		}
 		return collides;
 	}

  seatAtOne(table)
  {
    this.px = table.x
    this.py = table.y - 70
    //this.seatedSecond = true
  }

   render()
   {
     var canvas = document.getElementById('mycanvas');
     var ctx = canvas.getContext('2d');
     if (this.alive === true){
      ctx.drawImage(this.img, this.count * 217, 0, 105, 190, this.px, this.py, 105, 190);
      ctx.drawImage(this.food,this.px +90, this.py -20, 35,35);
      ctx.drawImage(this.bubble, this.px+75, this.py-30 , 60, 60);
      }
   }




 }
