class Spark
{
  constructor(locationX, locationY, img)
  {
    this.accelerationX = (Math.random() * .5) - .25
    this.accelerationY = (Math.random() * .5) - .25
    this.locationX = locationX
    this.locationY = locationY
    this.velocityX = (Math.random() * 2) - 1
    this.velocityY = (Math.random() * 3) - 1.5
    this.lifespan = 1.0
    this.image = img

  }

  run()
  {
    this.update()
    this.render()
  }

  update()
  {
    this.velocityX += this.accelerationX
    this.velocityY += this.accelerationY
    this.locationX += this.velocityX
    this.locationY += this.velocityY
    this.lifespan -= 0
  }

  isDead()
  {
    if (this.lifespan < 0.0) {
      return true
    }
    else {
      return false
    }
  }
  render()
  {
    var canvas = document.getElementById("mycanvas");
		var ctx = canvas.getContext("2d");
    //ctx.globalAlpha= this.lifespan
    //ctx.fillStyle="#6b0909";

    ctx.drawImage(this.image,this.locationX,this.locationY,20,20);

  }

}
