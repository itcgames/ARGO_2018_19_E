#pragma once

class Vector3
{
private:
	// The class has three variables x, y and z 
	double m_x;
	double m_y;
	double m_z;

public:	
	Vector3() = default;
	Vector3(double x, double y, double z);
	Vector3(Vector3 V);


	double length();
	double lengthSquared();		
	void normalise();		
	Vector3 add(Vector3 V1, Vector3 V2);
	Vector3 minus(Vector3 V1, Vector3 V2);
	Vector3 negate(Vector3 V);
	Vector3 multiply(Vector3 V1, Vector3 V2);
	Vector3 scalarDouble(double k, Vector3 V1);
	Vector3 scalarFloat(float k, Vector3 V1);
	Vector3 scalar(int k, Vector3 V1);
	Vector3 vectorProduct(Vector3 V1, Vector3 V2);
		
	
};