
#include <iostream>
#include <SFML/Window.hpp>
#include <SFML/OpenGL.hpp>
#include <gl/GL.h>
#include <gl/GLU.h>
#include "Vector3.h"
#include "Matrix.h"

class Game
{
public:
	Game();
	~Game();
	void run();
private:
	sf::Window window;
	bool isRunning = false;
	void initialize();
	void update();
	void draw();
	void unload();
	const int primitives;

	GLuint index;
	sf::Clock clock;
	sf::Time elapsed;
	Matrix modelMatrix = Matrix();
	Matrix rotateMatZ = Matrix();
	Matrix rotateMatX = Matrix();
	Matrix translateMat = Matrix();
	Matrix scaleMat = Matrix();
	float rotationAngle = 0.10f;
	Vector3 v1;
	Vector3 v2;
	Vector3 v3;
	Vector3 v4;
	Vector3 v5;
	Vector3 v6;
	Vector3 v7;
	Vector3 v8;
};