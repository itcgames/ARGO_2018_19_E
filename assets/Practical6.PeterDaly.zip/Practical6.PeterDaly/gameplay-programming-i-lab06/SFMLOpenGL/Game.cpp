
#ifdef _DEBUG 
#pragma comment(lib,"sfml-graphics-d.lib") 
#pragma comment(lib,"sfml-audio-d.lib") 
#pragma comment(lib,"sfml-system-d.lib") 
#pragma comment(lib,"sfml-window-d.lib") 
#pragma comment(lib,"sfml-network-d.lib") 
#else 
#pragma comment(lib,"sfml-graphics.lib") 
#pragma comment(lib,"sfml-audio.lib") 
#pragma comment(lib,"sfml-system.lib") 
#pragma comment(lib,"sfml-window.lib") 
#pragma comment(lib,"sfml-network.lib") 
#endif 
#pragma comment(lib,"opengl32.lib") 
#pragma comment(lib,"glu32.lib") 

#include "SFML/Graphics.hpp" 
#include "SFML/OpenGL.hpp" 
#include <iostream>
#include "Game.h"

bool flip = false;
int current = 1;

Game::Game() : window(sf::VideoMode(800, 600), "OpenGL Cube"), primitives(1), v1(-1.0f, 1.0f, -5.0f), v2(-1.0f, -1.0f, -5.0f), v3(1.0f, -1.0f, -5.0f), v4(1.0f, 1.0f, -5.0f),
v5(-1.0f, 1.0f, -10.0f), v6(-1.0f, -1.0f, -10.0f), v7(1.0f, -1.0f, -10.0f), v8(1.0f, 1.0f, -10.0f)
{
	
	rotateMatZ = rotateMatZ.rotationZ(rotationAngle);
	rotateMatX = rotateMatX.rotationZ(0.15);
	translateMat = translateMat.translate(0.001, 0.001);
	scaleMat = scaleMat.scale3D(100);

	modelMatrix = scaleMat * rotateMatX * rotateMatZ * translateMat;

	index = glGenLists(primitives);
}

Game::~Game(){}

void Game::run()
{

	initialize();

	sf::Event event;

	while (isRunning)
	{
		std::cout << "Game running..." << std::endl;

		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
			{
				isRunning = false;
			}
		}
		update();
		draw();
	}

}

void Game::initialize()
{
	isRunning = true;

	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0, window.getSize().x / window.getSize().y, 1.0, 500.0);
	glMatrixMode(GL_MODELVIEW);


	// glNewList(index, GL_COMPILE);
	// Creates a new Display List
	// Initalizes and Compiled to GPU
	// https://www.opengl.org/sdk/docs/man2/xhtml/glNewList.xml

}

void Game::update()
{

	v1 = modelMatrix * v1;
	v2 = modelMatrix * v2;
	v3 = modelMatrix * v3;
	v4 = modelMatrix * v4;
	v5 = modelMatrix * v5;
	v6 = modelMatrix * v6;
	v7 = modelMatrix * v7;
	v8 = modelMatrix * v8;

	glNewList(index, GL_COMPILE);
	glBegin(GL_QUADS);
	{
		//Front Face
		glColor3f(0.0f, 0.0f, 1.0f);
		glVertex3f(v1.x, v1.y, v1.z);
		glVertex3f(v2.x, v2.y, v2.z);
		glVertex3f(v3.x, v3.y, v3.z);
		glVertex3f(v4.x, v4.y, v4.z);

		//Back Face
		glColor3f(0.0f, 1.0f, 0.0f);
		glVertex3f(v5.x, v5.y, v5.z);
		glVertex3f(v6.x, v6.y, v6.z);
		glVertex3f(v7.x, v7.y, v7.z);
		glVertex3f(v8.x, v8.y, v8.z);

		//Right Face
		glColor3f(1.0f, 0.0f, 0.0f);
		glVertex3f(v4.x, v4.y, v4.z);
		glVertex3f(v3.x, v3.y, v3.z);
		glVertex3f(v7.x, v7.y, v7.z);
		glVertex3f(v8.x, v8.y, v8.z);

		//Left Face
		glColor3f(1.0f, 1.0f, 0.0f);
		glVertex3f(v1.x, v1.y, v1.z);
		glVertex3f(v2.x, v2.y, v2.z);
		glVertex3f(v6.x, v6.y, v6.z);
		glVertex3f(v5.x, v5.y, v5.z);

		//Top Face
		glColor3f(0.0f, 1.0f, 1.0f);
		glVertex3f(v5.x, v5.y, v5.z);
		glVertex3f(v1.x, v1.y, v1.z);
		glVertex3f(v4.x, v4.y, v4.z);
		glVertex3f(v8.x, v8.y, v8.z);

		//Top Face
		glColor3f(1.0f, 0.0f, 1.0f);
		glVertex3f(v6.x, v6.y, v6.z);
		glVertex3f(v2.x, v2.y, v2.z);
		glVertex3f(v3.x, v3.y, v3.z);
		glVertex3f(v7.x, v7.y, v7.z);
	}
	glEnd();
	glEndList();

	elapsed = clock.getElapsedTime();

	if (elapsed.asSeconds() >= 1.0f)
	{
		clock.restart();

		if (!flip)
		{
			flip = true;
			current++;
			if (current > primitives)
			{
				current = 1;
			}
		}
		else
			flip = false;
	}

	if (flip)
	{
		//rotationAngle += 0.005f;

		if (rotationAngle > 360.0f)
		{
			//rotationAngle -= 360.0f;
		}
	}



	std::cout << "Update up" << std::endl;
}

void Game::draw()
{
	std::cout << "Drawing" << std::endl;

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	std::cout << "Drawing Cube " << current << std::endl;
	glLoadIdentity();

	glCallList(current);

	window.display();

}

void Game::unload()
{
	std::cout << "Cleaning up" << std::endl;
}