#pragma once

#include <math.h>
#include <sstream>
#include <iostream>

class Vector3
{
public:
	Vector3();
	~Vector3();
	double getX();
	double getY();
	double getZ();
	Vector3(double x1, double y1, double z1);
	double length();
	double lengthSquared();
	void normalise();

	Vector3 operator+(Vector3 &vec);
	Vector3 operator+=(Vector3 &vec);

	Vector3 operator-(Vector3 &vec);
	Vector3 operator-=(Vector3 &vec);

	double operator*(Vector3 &vec);
	double operator*=(Vector3 &vec);

	Vector3 operator-(Vector3 V);
	Vector3 operator*(double k);
	Vector3 operator^(Vector3 V);
	std::stringstream toString();
	double x;
	double y;
	double z;

private:

};

