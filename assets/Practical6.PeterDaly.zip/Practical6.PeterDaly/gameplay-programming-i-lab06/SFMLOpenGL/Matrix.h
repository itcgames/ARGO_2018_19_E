#pragma once
//#include "Vector.h"
#include <math.h>
#include "Vector3.h"

class Matrix
{
public:
	Matrix();
	Matrix(Vector3 Row1, Vector3 Row2, Vector3 Row3);
	Matrix(double _A11, double _A12, double _A13,
		double _A21, double _A22, double _A23,
		double _A31, double _A32, double _A33);
	Vector3 operator *(Vector3 &V1);
	Matrix transpose();
	Matrix operator +(Matrix M);
	Matrix operator -(Matrix M);
	Matrix operator =(Matrix M);
	Matrix operator *(double x);
	Matrix operator *(Matrix M);
	double determinant();
	Vector3 row(int i);
	Vector3 column(int i);
	Matrix inverse();
	Matrix rotation(int _angle);
	Matrix translate(float dx, float dy);
	Matrix scale(float dx, float dy);
	Matrix operator -();
	Matrix rotationX(float _angle);
	Matrix rotationY(float _angle);
	Matrix rotationZ(float _angle);
	Matrix scale3D(float dx);
	~Matrix();

private:
	const double PI = 2 * acos(0.0);
	double A11;
	double A12;
	double A13;
	double A21;
	double A22;
	double A23;
	double A31;
	double A32;
	double A33;
};


