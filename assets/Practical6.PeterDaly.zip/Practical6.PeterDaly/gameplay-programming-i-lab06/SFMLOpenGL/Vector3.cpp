#include "Vector3.h"


Vector3::Vector3()
{
	// The class has three variables x, y and z 
	x = 0.0f;
	y = 0.0f;
	z = 0.0f;
}
Vector3::~Vector3() {}

double Vector3::getX()
{
	return x;
}
double Vector3::getY()
{
	return y;
}
double Vector3::getZ()
{
	return z; 
}

	// Constructor 2
Vector3::Vector3(double x1, double y1, double z1)
{ // To allow other values for X, Y and Z to be declared
	x = x1;
	y = y1;
	z = z1;
}


double Vector3::length()
{  // A method to return the length of the Vector3
	return (double)sqrt(x * x + y * y + z * z);
}
double Vector3::lengthSquared()
{  // A method to return the length squared of the Vector3
	return (x * x + y * y + z * z);
}

void Vector3::normalise()
{  // A method to reduce the length of the Vector3 to 1.0 
   // keeping the direction the same
	if (length() > 0.0)
	{  // Check for divide by zero
		double magnit = length();
		x /= magnit;
		y /= magnit;
		z /= magnit;
	}
}

Vector3 Vector3::operator+=(Vector3 &vec)
{  // An overloaded operator + to return the sum of 2 Vector3s
	return Vector3(this->x + vec.x, this->y + vec.y, this->z + vec.z);
}

Vector3 Vector3::operator+(Vector3 &vec)
{  // An overloaded operator + to return the sum of 2 Vector3s
	return Vector3(this->x + vec.x, this->y + vec.y, this->z + vec.z);
}

Vector3 Vector3::operator-=(Vector3 &vec)
{  // An overloaded operator - to return the difference of 2 Vector3s
	return Vector3(this->x - vec.x, this->y - vec.y, this->z - vec.z);
}

Vector3 Vector3::operator-(Vector3 &vec)
{  // An overloaded operator - to return the difference of 2 Vector3s
	return Vector3(this->x - vec.x, this->y - vec.y, this->z - vec.z);
}

double Vector3::operator*=(Vector3 &vec)
{  // An overloaded operator - to return the difference of 2 Vector3s
	return double(this->x * vec.x + this->y * vec.y + this->z * vec.z);
}

double Vector3::operator*(Vector3 &vec)
{  // An overloaded operator - to return the difference of 2 Vector3s
	return double(this->x * vec.x + this->y * vec.y + this->z * vec.z);
}

Vector3 Vector3::operator -(Vector3 V)
{// An overloaded operator - to return the negation of a single Vector3
	Vector3 answer = Vector3(0, 0, 0);
	Vector3 V1 = answer;
	V1.x = -V.x;
	V1.y = -V.y;
	V1.z = -V.z;
	return V1;
}

Vector3 Vector3::operator *(double k)
{// An overloaded operator * to return the product of a scalar by a Vector3
	return Vector3(x * (float)k, y * (float)k, z * (float)k);
}

Vector3 Vector3::operator ^(Vector3 V)
{// An overloaded operator ^ to return the Vector3 product of 2 Vector3s
	return Vector3(y * V.z - z * V.y, z * V.x - x * V.z, x * V.y - y * V.x);
}

std::stringstream Vector3::toString()
{
	std::stringstream ss;
	ss << "(" << x << "," << y << "," << z << ")";
	return ss;
}

