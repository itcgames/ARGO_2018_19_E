# README #

This is LAB 06 

### What is this repository for? ###

* Lab 06 Experiment with a Cube
* Version 2.0

### How do I get set up? ###

* clone repository
* ensure SFML_SDK environment variable exits
* ensure SFML Version SFML 2.3.2 Visual C++ 14 (2015) - 32-bit is installed
* (http://www.sfml-dev.org/files/SFML-2.3.2-windows-vc14-32-bit.zip "SFML-2.3.2-windows-vc14-32-bit.zip")

### Who do I talk to? ###

* philip.bourke@itcarlow.ie