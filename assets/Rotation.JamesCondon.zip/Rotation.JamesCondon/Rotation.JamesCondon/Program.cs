﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rotation.JamesCondon
{
    class Program
    {
        static void Main(string[] args)
        {
            bool working = true;
            int firstNumber = 1;
            int secondNumber = 2;
            int numberGuessed;
            int count = 0;
            int[,] matrixArray = new int[10, 10] { {0,0,0,0,0,0,0,0,0,0},
                                                   {0,0,0,0,1,1,0,0,0,0},
                                                   {0,0,0,0,1,1,0,0,0,0},
                                                   {0,0,0,1,1,1,1,1,0,0},
                                                   {0,1,1,1,1,1,1,1,1,0},
                                                   {0,0,1,0,0,0,0,1,0,0},
                                                   {0,0,1,0,0,0,0,1,0,0},
                                                   {0,0,1,0,1,1,0,1,0,0},
                                                   {0,0,1,0,1,1,0,1,0,0},
                                                   {0,0,1,1,1,1,1,1,0,0} };




            for (int row = 0; row < 10; row++)
            {
                for (int col = 0; col < 10; col++)
                {
                    if (matrixArray[row, col] == 1)
                    {
                        Console.Write("");
                    }
                    if (matrixArray[row, col] == 0)
                    {
                        Console.Write("");

                    }
                    Console.Write("" + matrixArray[row, col]);
                    count++;
                }
                if (count >= 10)
                {
                    Console.Write("\n");
                }

            }
            Console.Write("\n");
            while (working)
            {
                System.Console.WriteLine("\Press 2 to move the house 180 degrees then 1 to move the house 90 degrees :\n ");
                numberGuessed = Convert.ToInt32(System.Console.ReadLine());

                if (firstNumber == numberGuessed)
                {
                    for (int col = 0; col < 10; col++)
                    {
                        for (int row = 0; row < 10; row++)
                        {
                            
                            Console.Write("" + matrixArray[row, col]);
                            count++;
                        }
                        if (count >= 10)
                        {
                            Console.Write("\n");
                        }
                    }
                    numberGuessed = 0;
                    Console.Write("\n");
                }


                if (secondNumber == numberGuessed)
                {
                    for (int row = 9; row >= 0; row--)
                    {
                        for (int col = 9; col >= 0; col--)
                        {
                            Console.Write("" + matrixArray[row, col]);
                            count++;
                        }
                        if (count >= 10)
                        {
                            Console.Write("\n");
                        }
                    }

                }


            }

                Console.ReadLine();
            }
        }
    }


