#include <iostream>
#include <istream>
#include <string>
/* author: James Condon
   Student no: C00207200
   Purpose: This is a text based missile game it is players objective to enter the launch code choose 
   the co-ordinates to attack the enemy and destroy them the game continues until all the enemies are detroyed.
   Time taken: 3 hours 
*/
int main()
{
	//where the missilesinformation is stored 
	struct Missile
	{
	public:
		int launchCode = 123;
		int answer;
		int theLaunch;
		bool armed = true;
		//player co-ordinates
		int chosenX;
		int chosenY;
		
		
	};
	
	//enemy information
	struct Enemy{
		//enemy co-ordinates
		int x;
		int y;
		int enemyCount = 5;//no of enemies 
		int noOfNukes = 1;//no of nukes 
	};

	Enemy target;
	Missile theMissile;
	
	//initialises the targets coordinates
	target.x = 10;
	target.y = 10;

	//print for the screen 
	std::cout << "  __     __                  _          " <<std::endl;
	std::cout << " |  \\   /  |                | |         " <<std::endl;
	std::cout << " | | \\ / / | _  ___  ___  _ | | _____   " <<std::endl;
	std::cout << " | |  \\ /| || |/ __/  __ | || || ____|  " <<std::endl;
	std::cout << " | |     | || |\\__ \\\\__ \\| || || ____|  " <<std::endl;
	std::cout << " |_|     |_||_|\\___/\\___/|_||_||_____|  \n" <<std::endl;

	std::cout << "Welcome Captain, there have been " << target.enemyCount << " Enemy Ships and Planes\non the radar all within 20 clicks." << std::endl
		<< "It is time to launch an attack and destroy the enemy ships.\n" << std::endl
		<< "Please Enter The Launch Code: ";
	std::cin >> theMissile.answer;

	//the game will run
	while (theMissile.armed)
	{
		//the user enters the launch code correctly the the game begins
		if (theMissile.answer == theMissile.launchCode)
		{

			std::cout << "\nThe ships are all in a range of 5 to 20 clicks.\n" << "It is your call Captain.\n";

			std::cout << "Choose the coordinates to fire the missile\n" << "\nChose X-Co-ordinates = ";
			std::cin >> theMissile.chosenX;
			std::cout << "Chose Y-Co-ordinates = ";
			std::cin >> theMissile.chosenY;

			std::cout << "\nTargets chosen\n" << "Time to engage the target!" << std::endl << "\nPress 1 to fire the Missile: " << std::endl << "Press 2 to fir Nuclear Warhead: \n";
			std::cin >> theMissile.theLaunch;
			
			//if the missile is chosen the following takes place 
			if (theMissile.theLaunch == 1)
			{
				std::cout << "Missile Launch in \n\n   3\n\n   2\n\n   1\n" << std::endl << "The Launch was successful\n" <<
					std::endl;
				
				std::cout << "Updating Co-ordinates\n\n";
				//collision detection for the missile
				if ((theMissile.chosenX <= target.x + 5) && (theMissile.chosenX >= target.x - 5)
					&& (theMissile.chosenY <= target.y + 5) && (theMissile.chosenY >= target.y - 5))//allows value of 5 between hits
				{
					target.enemyCount--;//deletes one enemy 
					std::cout << "Successful Hit\n\n" << "Target Destroyed\n" << std::endl << "There are " << target.enemyCount
						<< " enemies remaining.\n";
					
					if (target.enemyCount > 0)//once collided randomises the targets positions
					{
						target.x = rand() % 15 + 5;
						target.y = rand() % 15 + 5;
						
					}
					else
					{
						std::cout << "The mission was a Success.";
						break;
							
					}
				}
				else//if you have missed the enemy the position is randomised and message update 
				{
					std::cout << "Unsuccessful!\nYou have missed the Target!\nThe enemies have  been alerted the enemy.\n" << std::endl <<
						"The coordinates have changed\n";
					std::cout << "More enemies have arrived!" << std::endl;
					target.enemyCount++;
					target.x = rand() % 15 + 5;
					target.y = rand() % 15 + 5;
				}
			}
			// if the user presses 2 to fire a nuke it is only fired if the number is more than 0
			else if (theMissile.theLaunch == 2 && target.noOfNukes > 0)
			{
				std::cout << "Nuke Launch in \n\n3\n\n2\n\n1\n" << std::endl << "The Nuke has been launched\n" <<
					std::endl;
				if ((theMissile.chosenX <= target.x + 15) && (theMissile.chosenX >= target.x - 15)
					&& (theMissile.chosenY <= target.y + 15) && (theMissile.chosenY >= target.y - 15))//allows value of 5 between hits
				{
					target.enemyCount = target.enemyCount-3;//deletes 3 enemy 
					target.noOfNukes--;
					std::cout << "Successful Hit\n\n" << "Multiple Target's Destroyed\n" << std::endl << "There are " << target.enemyCount
						<< " enemies remaining.\n" << std::endl << "You have 0 Nukes Remaining";

					if (target.enemyCount > 0)//once collided randomises the targets positions
					{
						target.x = rand() % 15 + 5;
						target.y = rand() % 15 + 5;

					}
					else
					{
						std::cout << "The mission was a Success.";
						break;

					}
				}
			}
			


		}
		// if the answer for the launch code is incorrect 
		else if (theMissile.answer != theMissile.launchCode)
		{
			std::cout << "That is the incorrect launch code" << std::endl;//the following is outputted onto the screen and looped back to enter the launch code again
			std::cout << "Enter Launch Code: ";
			std::cin >> theMissile.answer;

		}



	}

	

	system("PAUSE");
}