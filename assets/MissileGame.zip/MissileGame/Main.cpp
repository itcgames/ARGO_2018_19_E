#include <iostream>
#include <string>
#include <ctime>
using namespace std;


enum WarHead{EXPLOSIVE, NUCLEAR};	//enum for the different types of missiles

//typedef for the position of an object
typedef struct Position
{
	//Give the position an x and a y position 
	int x;
	int y;

	void print()
	{
		cout << x << y << endl;
	}

} Coordinates;	//Give it then name coordinates

//typedef for the enemy
typedef struct Enemy 
{
	Coordinates coordinates;	//Give the enemy a position
}Target;	//Give the enemy the name target


//Struct for the object missile
struct Missile
{

	WarHead payload;	//Give the missile a warhead
	Coordinates coordinates;	//The coordinates of the missile
	Target target;	//The target for the missile
	bool armed;	//Whether or not the missile is armed
	bool hit;	//Whether or not the missile has hit
	bool miss;	//Whether or not the missile has missed

	//function to arm or disarm the missile
	void arm()
	{
		if (armed)	//Checks if the missile is armed and disarms it if it is
		{
			armed = false;
		}
		else       //Checks if the missile is disarmed and arms it if it is
			armed = true;
	}

	//function to update the position of the missile
	void update()
	{
		coordinates.x++;	//Increments the x value of the missile by 1
		coordinates.y += 2;	//Increments the y value of the missile by 2
	}
};

Missile missile;	//Initializes the object missile

//function to set which type of missile is used
void missiletype()
{
	string type;	
	cout << "Enter 1 for explosive or 2 for nuclear" << endl;
	cin >> type;

	if (type == "1")	//Checks the type
	{
		missile.payload = EXPLOSIVE;	//Sets the missile to explosive
		cout << "Thanks for not causing the end of the world!" << endl;
	}
	else if (type == "2")	//Checks the type
	{
		missile.payload = NUCLEAR;	//Sets the missile to nuclear
		cout << "Bit much dont you think?" << endl;
	}
	else
	{
		cout << "Please pick a correct number!" << endl; //Error checking
		missiletype();
	}

}

//function to choose the starting coordinates of the missile
void selectcoordinates()
{
	int x;
	int y;
	cout << "Please pick the starting x coordinate of your target, it must be a positive     number." << endl;
	cin >> x;

	if (x > 0 && x < 100)	//Error checking
	{
		missile.coordinates.x = x;
	}
	else
	{
		cout << "Please pick a correct number!" << endl;
		selectcoordinates();
	}

	cout << "Please pick the starting y coordinate of your target, it must be a positive     number." << endl;
	cin >> y;

	if (y > 0 && y < 100)	//Error checking
	{
		missile.coordinates.y = y;
	}
	else
	{
		cout << "Please pick a correct number!" << endl;
		selectcoordinates();
	}
}

//function to arm the missile
void armmissile() 
{
	int armcode = 123;	//Code to arm the missile
	int input;

	cout << "Enter in your launch code to acticate the missile, it's 123" << endl;
	cout << "Or enter in anything else to walk away and not start a war!" << endl;

	cin >> input;
	if (input == armcode)	//Checks if the arm code was inputted
	{
		cout << "Launching now!" << endl;
		missile.arm();	//Arms the missile
	}
	else
	{
		cout << "Thank you sir!";
		exit(1);	//Closes down the game
	}
}

//function to check for collision
void checkcollision() 
{
	if (missile.coordinates.x == missile.target.coordinates.x && missile.coordinates.y == missile.target.coordinates.y)	//Checks if the missile coordinates are the same as the targets 
	{
		missile.hit = true;	//Sets the missile to have hit
	}
}

//function to check for the missile to have missed
void checkmiss() 
{
	if (missile.coordinates.x > 100 && missile.coordinates.y > 100)	//Checks if the missile has passed the target bounds
	{
		missile.miss = true;	//Sets the missile to have missed
	}
}

//Main function
int main() 
{
	srand(time(NULL));	//Sets up the random generator 

	//Sets the x and y values to random numbers between 1 and a 100
	missile.target.coordinates.x = (rand() % 100) + 1;
	missile.target.coordinates.y = (rand() % 100) + 1;

	missiletype();	//Calls the missile type function
	selectcoordinates();	//Calls the  function to select the missiles coordinates
	armmissile();	//Calls the arm missile function
	while(!missile.hit && !missile.miss)	//Checks if the missile has missed or hit
	{
		missile.update();	//Updates the position of the missile
		checkcollision();	//checks if the missile has hit
		checkmiss();	//checks if the missile has missed
	}
	if (missile.hit)	//Checks if the missile has hit
	{
		cout << "Well done!" << endl;	
	}
	if (missile.miss)	//checks if the missile has missed
	{
		cout << "Too bad try again!" << endl;
		missile.miss = false;
		main();	//Starts again
	}
	system("pause");
}

