﻿/// <summary>
/// Lab 7 starting project
/// James Condon
/// C00207200
/// Worked on total time 4 hours
/// this is a billiards game which determines the collision between the two balls and if they collide 
/// the red ball moves and white ball moves in the opposite direction
/// 
/// </summary>
/// 


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace lab7_starter1
{
    public partial class Form1 : Form
    {
        Vector3 redCentre = new Vector3();
        Vector3 centre = new Vector3();//centre of the red ball
        Vector3 mouseLocation = new Vector3();
        Vector3 velocity = new Vector3();
        Vector3 velocitySwap = new Vector3(), radius;
        float topLeftX = 5;//top left of the rectangle
        float topLeftY = 5;
        private float cushion = 0.5f;
        float width = 1000;
        float height = 700;
        float diameter = 30;
        float speed;  // we feel the need for speed
        bool drawDirectionLine; // to draw or not
        bool moveBall; // update ball location
        bool moveRedBall;
        

        /// <summary>
        /// Setup from and variables, place ball at location 200,300
        /// and set speed to be 5(yokes per time whatsits)
        /// </summary>
        public Form1()
        {
            InitializeComponent();
            centre = new Vector3(width / 2, height / 2, 0);
            radius = new Vector3(diameter / 2, diameter / 2, 0);
            width = this.Width - 30;
            height = this.Height - 50;
            speed = 10;
            drawDirectionLine = false;
            moveBall = false;
            moveRedBall = false;
            
            
            this.SetStyle(ControlStyles.AllPaintingInWmPaint |
              ControlStyles.UserPaint |
              ControlStyles.DoubleBuffer, true);
        }
        /// <summary>
        /// Draw the game start with a blue box the size of the form (minus our border)
        /// Draw the line (cue) is setting up a shoot
        /// and then draw the ball
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            // Create pens in blue & black
            
            Pen bluePen = new Pen(Color.Blue, 2.5f);
            Pen blackPen = new Pen(Color.Black, 4f);
            SolidBrush greenBrush = new SolidBrush(Color.Green);

            // Create a rectangle for the sides of the box
            Rectangle Rect1 = new Rectangle((int)topLeftX, (int)topLeftY, (int)width, (int)height);
           
            // Draw the box
            e.Graphics.DrawRectangle(bluePen, Rect1);
            e.Graphics.FillRectangle(greenBrush, Rect1);
            
            if (drawDirectionLine == true)
            {
                e.Graphics.DrawLine(blackPen, mouseLocation.X, mouseLocation.Y, centre.X, centre.Y);
            }
            DrawBall(e);
            DrawRedBall(e);
        }
        /// <summary>        /// 
        /// use a black pen and red brush to draw the ball using
        /// an ellipse defined by a square elipse defined by square with x,y coords at centre
        /// so we compute top left corner
        /// </summary>
        /// <param name="e"></param>
        private void DrawBall(PaintEventArgs e)
        {
            Pen blackPen = new Pen(Color.Black, 3);
            
            SolidBrush whiteBrush = new SolidBrush(Color.White);

            RectangleF outerRect = new RectangleF((centre-radius).X, (centre-radius).Y, diameter, diameter);

            e.Graphics.DrawEllipse(blackPen, outerRect);
            e.Graphics.FillEllipse(whiteBrush, outerRect);
            
        }
        private void DrawRedBall(PaintEventArgs e)
        {
            Pen blackPen = new Pen(Color.Black, 3);
            SolidBrush redBrush = new SolidBrush(Color.Red);

            RectangleF outerRect = new RectangleF((redCentre - radius).X, (redCentre - radius).Y, diameter, diameter);
            e.Graphics.DrawEllipse(blackPen, outerRect);
            e.Graphics.FillEllipse(redBrush, outerRect);
        }
        /// <summary>
        /// Start of player interaction 
        /// set moveBall and drawDirection Line Booleans
        /// control the drawing mode.
        /// assign mouseX and mouseY (used to draw line and later calculate direction
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            mouseLocation = new Vector3(e.X, e.Y, 0);
            drawDirectionLine = true;
            moveBall = false;
            moveRedBall = false;
           
            
        }
        /// <summary>
        /// player is dragging mouse so update our mouse co-ords
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            mouseLocation = new Vector3(e.X, e.Y, 0);
        }
        /// <summary>
        /// When the player releases the mouse workout the
        /// line segment specified by the location of the ball to the last
        /// know sighting of the mouse. Normalise this so it's length is one
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            drawDirectionLine = false;
            moveBall = true;
            moveRedBall = false;
            velocity = centre - mouseLocation;
            velocity = 0.1 * velocity;
            

        }
        /// <summary>
        /// if the ball is moving (not aiming) then update it's location
        /// and check it's at the edge of the box if so bounce by negating
        /// the x direction on left right boundrys and the y deirection on
        /// top and bottom boundries
        /// </summary>
        internal void UpdateWorld()
        {
            if (moveBall == true)
            {
                moveRedBall = true;
                centre += velocity;
                redCentre += velocitySwap;
            }
            ProcessCollision(centre, redCentre);

            CheckBoundry(centre, velocity);
            CheckBoundry(redCentre, velocitySwap);
        }
        private Vector3 ApplyFriction(Vector3 ballVelocity)
        {
            ballVelocity = 0.99 * ballVelocity;
            if (ballVelocity.X * ballVelocity.X + ballVelocity.Y * ballVelocity.Y < .5)
            {
                ballVelocity = new Vector3(0, 0, 0);
            }
            return ballVelocity;
        }
        private void ProcessCollision(Vector3 centre, Vector3 redCentre)
        {
            if(CheckCollision(centre, redCentre))
            {
                Bounce(velocity, velocitySwap);
                centre += velocity;
                redCentre += velocitySwap;
            }
        }
        private void Bounce(Vector3 centre, Vector3 redCentre)
        {
            Vector3 tempVector = new Vector3();
            tempVector = velocity;
            velocity = velocitySwap;
            velocitySwap = tempVector;
        }
        private bool CheckCollision(Vector3 centre, Vector3 redCentre)
        {
            if (centre.X < redCentre.X - diameter)
            {
                return false;
            }
            if (centre.X > redCentre.X + diameter)
            {
                return false;
            }
            if (centre.Y > redCentre.Y - diameter)
            {
                return false;
            }
            if (centre.Y < redCentre.Y - diameter)
            {
                return false;
            }
            return CheckDistance(centre, redCentre);
        }

        private bool CheckDistance(Vector3 centre, Vector3 redCentre)
        {
            float distanceSquared;
            distanceSquared = (centre.X - redCentre.X) * (centre.X - redCentre.X) + (centre.Y - redCentre.Y) * (centre.Y - redCentre.Y);
            if (diameter * diameter > distanceSquared)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void CheckBoundry(Vector3 ball, Vector3 velocity)
        {
            if (ball.X < topLeftX + radius.X)
            {
                velocity.cushionX(cushion);
                ball.ResetX(topLeftX + radius.X);
            }
            if (ball.X > topLeftX + width - radius.X)
            {
                velocity.cushionX(cushion);
                ball.ResetX(topLeftX +width - radius.X);
            }
            if (ball.X < topLeftY + radius.Y)
            {
                velocity.cushionY(cushion);
                ball.ResetY(topLeftX + radius.Y);
            }
            if (ball.X > topLeftY + height - radius.Y)
            {
                velocity.cushionY(cushion);
                ball.ResetY(topLeftY + height - radius.Y);
            }
        }
        /// <summary>
        /// Adjust our bounding box to match the from size, take onto account the different borders
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Resize(object sender, EventArgs e)
        {
            width = this.Width - 30;
            height = this.Height - 50;
            centre = new Vector3(width / 2, height / 2, 0);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
