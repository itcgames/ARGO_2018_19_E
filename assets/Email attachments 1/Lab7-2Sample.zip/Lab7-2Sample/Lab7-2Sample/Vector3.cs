using System;
using System.Collections.Generic;
using System.Text;
/*
//peter Lowe
//
 * removed the seter method for x,y,z to ensure full use of vectors.
 * 
 * 
 * *
 * */
namespace SimpleSwapVelocitiers
{
    class Vector3
    {
        // The class has three variables x, y and z 
        private float x, y, z;

        public float X
        {
            get { return x; }           
        }
        public float Y
        {
            get { return y; }           
        }
        public float Z
        {
            get { return z; }           
        }

        // Constructor 1
        public Vector3()
        {
            this.x = 0.0f;
            this.y = 0.0f;
            this.z = 0.0f;
        }

        // Constructor 2
        public Vector3(float x1, float y1, float z1)
        { // To allow other values for X, Y and Z to be declared
            this.x = x1;
            this.y = y1;
            this.z = z1;
        }
        // Constructor 3
        public Vector3(Vector3 V)
        {  // To allow other values for X, Y and Z to be declared
            this.x = V.x;
            this.y = V.y;
            this.z = V.z;
        }

        public float Length()
        {  // A method to return the length of the vector
            return (float)Math.Sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
        }
        public float LengthSquared()
        {  // A method to return the length squared of the vector
            return (this.x * this.x + this.y * this.y + this.z * this.z);
        }

        public void Normalise()
        {  // A method to reduce the length of the vector to 1.0 
            // keeping the direction the same
            if (this.Length() > 0.0)
            {  // Check for divide by zero
                float magnit = this.Length();
                this.x /= magnit;
                this.y /= magnit;
                this.z /= magnit;
            }
        }


        public static bool operator ==(Vector3 V1, Vector3 V2)
        {  // A method to return true if equal and false otherwise
            if (V1.x == V2.x && V1.y == V2.y && V1.z == V2.z)
                return true;
            else return false;
        }

        public static bool operator !=(Vector3 V1, Vector3 V2)
        {  // A method to return true if not equal and false otherwise
            if (V1.x == V2.x && V1.y == V2.y && V1.z == V2.z)
                return false;
            else return true;
        }

        public static Vector3 operator +(Vector3 V1, Vector3 V2)
        {  // An overloaded operator + to return the sum of 2 vectors
            return new Vector3(V1.x + V2.x, V1.y + V2.y, V1.z + V2.z);
        }

        public static Vector3 operator -(Vector3 V1, Vector3 V2)
        { // An overloaded operator - to return the difference of 2 vectors
            return new Vector3(V1.x - V2.x, V1.y - V2.y, V1.z - V2.z);
        }

        public static Vector3 operator -(Vector3 V)
        {// An overloaded operator - to return the negation of a single vector
            Vector3 V1 = new Vector3();
            V1.x = -V.x;
            V1.y = -V.y;
            V1.z = -V.z;
            return V1;
        }

        public static double operator *(Vector3 V1, Vector3 V2)
        {// An overloaded operator * to return the scalar product of 2 vectors
            return (V1.x * V2.x + V1.y * V2.y + V1.z * V2.z);
        }

        public static Vector3 operator *(double k, Vector3 V1)
        {// An overloaded operator * to return the product of a scalar by a vector
            return new Vector3(V1.x * (float)k, V1.y * (float)k, V1.z * (float)k);
        }

        public static Vector3 operator *(float k, Vector3 V1)
        {// An overloaded operator * to return the product of a scalar by a vector
            return new Vector3(V1.x * k, V1.y * k, V1.z * k);
        }

        public static Vector3 operator *(int k, Vector3 V1)
        {// An overloaded operator * to return the product of a scalar by a vector
            return new Vector3(V1.x * k, V1.y * k, V1.z * k);
        }

        public static Vector3 operator ^(Vector3 V1, Vector3 V2)
        {// An overloaded operator ^ to return the vector product of 2 vectors
            return new Vector3(V1.y * V2.z - V1.z * V2.y, V1.z * V2.x - V1.x * V2.z, V1.x * V2.y - V1.y * V2.x);
        }

        /// <summary>
        /// A new inmporved flipX method
        /// applay a momemtum deadning factor to the fliping
        /// </summary>
        /// <param name="loss"></param>
        public void cushionX(float loss)
        {
            x = -x * loss;
        }
        /// <summary>
        /// same as above for top and bottom cushions
        /// </summary>
        /// <param name="loss"></param>
        public void cushionY(float loss)
        {
            y = -y * loss;
        }

        /// <summary>
        /// used to place ball away from cushion
        /// </summary>
        /// <param name="newX"></param>
        public void ResetX(float newX)
        {
            x = newX;
        }
        public void ResetY(float newY)
        {
            y = newY;
        }
    }


}
