﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
/*Sample of second part
 * not fully commented
 * single method to draw ball, check boundaries, friction
 * 
 * simple short updateworl loop easy to understand
 * 
 * know issues balls join when collision occours next to cushion at
 * high speed cause of the repositioning of cushions
 * 
 * */

namespace SimpleSwapVelocitiers
   
{    public partial class Form1 : Form
    {
        Vector3 mouseLocation = new Vector3(), cueBall = new Vector3(500, 350, 0), redBall = new Vector3(50, 50, 0);
        Vector3 cueVelocity = new Vector3(), redVelocity = new Vector3(), radius;
        float width = 1000;
        float height = 700;
        float topLeftX = 5;
        float topLeftY = 5;
        float diameter = 30;
        bool drawDirectionLine;
        bool moveBall;
        float speed;
        private float cushionEffect = 0.5f;

        public Form1()
        {
            InitializeComponent();
            width = this.Width - 30;
            height = this.Height - 50;
            radius = new Vector3(diameter / 2, diameter / 2, 0);            
            cueBall = new Vector3(width / 2,height / 2,0 );
            speed = 5;
            drawDirectionLine = false;
            moveBall = false;
            this.SetStyle(ControlStyles.AllPaintingInWmPaint |
              ControlStyles.UserPaint |
              ControlStyles.DoubleBuffer, true);
        }
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            // Create pens in blue & black
            Pen bluePen = new Pen(Color.DarkGreen, 2.5f);
            Pen blackPen = new Pen(Color.Black, 4f);
            e.Graphics.Clear(Color.Green);
            // Create a rectangle for the sides of the box
            Rectangle Rect1 = new Rectangle((int)topLeftX, (int)topLeftY, (int)width, (int)height);
            // Draw the box
            e.Graphics.DrawRectangle(bluePen, Rect1);
            if (drawDirectionLine == true)
            {
                e.Graphics.DrawLine(blackPen, mouseLocation.X, mouseLocation.Y, cueBall.X, cueBall.Y);
            }
            DrawCueBall(e);
            DrawRedBall(e);
        }
        private void DrawCueBall(PaintEventArgs e)
        {
            Pen edgePen = new Pen(Color.DarkGray, 3);
            SolidBrush fillBrush = new SolidBrush(Color.Wheat);
            // Create a rectangle for enclosing the shape of ellipse
            // the rectangle will be a square so that the ellipse is a circle, i.e. the ball

            RectangleF outerRect = new RectangleF((cueBall - radius).X, (cueBall - radius).Y, diameter, diameter);
            e.Graphics.DrawEllipse(edgePen, outerRect);
            e.Graphics.FillEllipse(fillBrush, outerRect);
        }

        private void DrawRedBall(PaintEventArgs e)
        {
            Pen edgePen = new Pen(Color.DarkRed, 3);
            SolidBrush fillBrush = new SolidBrush(Color.Red);
            // Create a rectangle for enclosing the shape of ellipse
            // the rectangle will be a square so that the ellipse is a circle, i.e. the ball

            RectangleF outerRect = new RectangleF((redBall - radius).X, (redBall - radius).Y, diameter, diameter);
            e.Graphics.DrawEllipse(edgePen, outerRect);
            e.Graphics.FillEllipse(fillBrush, outerRect);
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            // Read the x and y positions of the mouse when it is clicked            
            mouseLocation = new Vector3(e.X, e.Y, 0);
            // Allow the line to be drawn when the mouse is moved
            drawDirectionLine = true;
            moveBall = false; // stop the ball moving
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            // Read the x and y positions of the mouse when it is clicked            
            mouseLocation = new Vector3(e.X, e.Y, 0);
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            drawDirectionLine = false;
            moveBall = true;
            cueVelocity = cueBall - mouseLocation;
            // cueVelocity.Normalise();
            cueVelocity = 0.1 * cueVelocity;
        }
        /// <summary>
        /// if the balls are moving (not aiming) then update their location
        /// check for collisions
        /// and check it's at the edge of the box if so bounce
        /// reduce the spped by a bit
        /// </summary>
        internal void UpdateWorld()
        {
            if (moveBall == true)
            {
                cueBall += cueVelocity;
                redBall += redVelocity;
            }
            
            ProcessCollision(cueBall, redBall);

            CheckBounds(cueBall, cueVelocity);
            CheckBounds(redBall, redVelocity);
            
            cueVelocity = ApplyFriction(cueVelocity);
            redVelocity = ApplyFriction(redVelocity);

        }
    /// <summary>
    /// reduce the velocity buy 1% and set to zero
    /// when it's square is less than .5 (magniture .7ish)
    /// </summary>
    /// <param name="ballVelocity"></param>
    /// <returns></returns>
        private Vector3 ApplyFriction(Vector3 ballVelocity)
        {
            ballVelocity = 0.99 * ballVelocity;
            if (ballVelocity.X * ballVelocity.X + ballVelocity.Y * ballVelocity.Y < .5)
            {                
                ballVelocity = new Vector3(0, 0, 0);
            }
            return ballVelocity;
        }
    /// <summary>
    /// check collision if so then bounce balls and make one move away from collision with new velocities
    /// to avoid union in most cases
    /// </summary>
    /// <param name="cueBall"></param>
    /// <param name="redBall"></param>
        private void ProcessCollision(Vector3 cueBall, Vector3 redBall)
        {
            if (CheckCollision(cueBall, redBall))
            {
                Bounce(cueVelocity, redVelocity);
                cueBall += cueVelocity;
                redBall += redVelocity;
            }
        }
    /// <summary>
    /// simple collision 
    /// sawp velocities
    /// </summary>
    /// <param name="cueBall"></param>
    /// <param name="redBall"></param>
        private void Bounce(Vector3 cueBall, Vector3 redBall)
        {
            Vector3 tempVector = new Vector3();
            tempVector = cueVelocity;
            cueVelocity = redVelocity;
            redVelocity = tempVector;
        }


    /// <summary>
    /// check bounding rectangles and return false ASAP
    /// greater chance of missing based on x co-or rather than y
    /// casue of landscape orientation
    /// </summary>
    /// <param name="cueBall"></param>
    /// <param name="redBall"></param>
    /// <returns></returns>
        private bool CheckCollision(Vector3 cueBall, Vector3 redBall)
        {
            if (cueBall.X < redBall.X - diameter)
            {
                return false;
            }
            if (cueBall.X > redBall.X + diameter)
            {
                return false;
            }
            if (cueBall.Y > redBall.Y + diameter)
            {
                return false;
            }
            if (cueBall.Y < redBall.Y - diameter)
            {
                return false;
            }
            return CheckDistance(cueBall, redBall);
        }
    /// <summary>
    /// check the square of distance between ball centres versu
    /// the square of the diameter of one ball = sum of radus of both
    /// </summary>
    /// <param name="cueBall"></param>
    /// <param name="redBall"></param>
    /// <returns></returns>
        private bool CheckDistance(Vector3 cueBall, Vector3 redBall)
        {
            float distanceSquared;
            distanceSquared = (cueBall.X - redBall.X) * (cueBall.X - redBall.X) + (cueBall.Y - redBall.Y) * (cueBall.Y - redBall.Y);
            if (diameter * diameter > distanceSquared)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    /// <summary>
    /// check the ball location against the edge and apply cushion effect
    /// swap direction and reduce buy 50%, reset ball location next to cushion so
    /// it can move away next frame freely
    /// do this for each edge
    /// </summary>
    /// <param name="ball"></param>
    /// <param name="velocity"></param>
        private void CheckBounds(Vector3 ball, Vector3 velocity)
        {
            if (ball.X < topLeftX + radius.X)
            {   //hits left side change x-direction only
                velocity.cushionX(cushionEffect);
                ball.ResetX(topLeftX + +radius.X);
               
            }
            if (ball.X > topLeftX + width - radius.X)
            {   //hits right side change x-direction
                velocity.cushionX(cushionEffect);
                ball.ResetX(topLeftX + width - radius.X);
            }
            if (ball.Y < topLeftY + radius.Y)
            {//hits top side change y-direction only, leave the x-direction as it was
                velocity.cushionY(cushionEffect);
                ball.ResetY(topLeftY + radius.Y);
            }
            if (ball.Y > topLeftY + height - radius.Y)
            {
                velocity.cushionY(cushionEffect);
                ball.ResetY(topLeftY + height - radius.Y);
            }
        }
        /// <summary>
        /// Adjust our bounding box to match the from size, take onto account the different borders
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Resize(object sender, EventArgs e)
        {
            width = this.Width - 30;
            height = this.Height - 50;
            cueBall = new Vector3(width / 2, height / 2, 0);
        }
    }
}
