#include <iostream>
//the character class both class are derived from this 
//using inheritence the child classes can inherit the variables initialised in the parent
class Character
{
protected :
	int spellDamage = 5;//damage from the casting of a spell
	int meleeDamage = 7;//damage from a melee attack
	int shieldDamage = 3;//damage given and life restord from a shield 
	//bools are initially set to false 
	bool orcDefending = false;
	bool trollDefending = false;
	int orcLife = 20;
	int trollLife = 20;
	int orcCount = 10;
	int trollCount = 10;

public:
	bool winTheGame = false;
	//USES POINTER TO RESET THE PLAYER AND ENEMY LIFE
	void resetLife(int life)
	{
		if ((orcLife <= 0) || (trollLife <= 0))
		{
			orcLife = life;
			trollLife = life;
		}
	}
	virtual void castSpell() = 0;
	virtual void melee() = 0;
	virtual void shield() = 0;
};

class Troll : public Character
{
public:
	
	void winGame()
	{
		if (orcCount <= 0)
		{
			std::cout << "Congratulations, The Troll has won the game" << std::endl;
			winTheGame = true;
		}
	}
	void minusOrc()
	{
		if ((orcLife <= 0) && (orcCount > 0))
		{
			orcCount--;
			std::cout << "Orc down, remaining orc = " << orcCount << std::endl;
		}
	}
	
	//function to cast a spell 
	void castSpell()
	{
		//the function operates if the enemies life is more than zero
		//and the the enmey is not defending 
		if ((orcDefending == false) && (orcLife > 0))
		{
			orcLife = orcLife - spellDamage;//allows damage to be taken from the orcs life 
			//message is printed 
			std::cout << "The Troll has cast a spell" << std::endl << "You have inflicted moderate damage on your enemy" << std::endl;
			std::cout << "Orc Health = " << orcLife << std::endl;
		}
		//if function is called and reduces life to zero 
		
	}
	void melee()
	{
		//the function operates if the enemies life is more than zero
		//and the the enmey is not defending 
		if ((orcDefending == false) && (orcLife > 0))
		{
			orcLife = orcLife - meleeDamage;//allows damage to be taken from the orcs life 
			//message is printed 

			std::cout << "The Troll has used its weapon" << std::endl << "You have inflicted maximum damage on your enemy" << std::endl;
			std::cout << "Orc Health = " << orcLife << std::endl;
		}
		
	}
	void shield()
	{
		//the function operates if the enemies life is more than zero
		//and the the enmey is not defending 
		if ((orcDefending == false) && (orcLife > 0))
		{
			trollLife = trollLife + 3;//adds the players life 
			orcLife = orcLife - shieldDamage;//allows damage to be taken from the orcs life 
			//message is printed 

			std::cout << "The Troll has used a shield" << std::endl << "You have successfully defended the Orcs attack" << std::endl
				<< "You have regained health, Troll Health = " << trollLife << std::endl;
			std::cout << "The Orc has fatigued and lost health." << std::endl << "Orc Health = " << orcLife << std::endl;
		}
		
		else
		{
			std::cout << "The Orc has used the shield" << std::endl << "The Troll also chose to defend your life and theirs remains unchanged"
				<< std::endl;
		}
	}
};

class Orc : public Character
{
public:
	void replay()
	{
		orcLife = 20;
		trollLife = 20;
	}

	void minusTroll()
	{
		if ((trollLife <= 0) && (trollCount > 0))
		{
			trollCount--;
			std::cout << "Troll down, remaining trolls = " << trollCount << std::endl;
		}
	}

	void winGame()
	{
		if (trollCount <= 0)
		{
			std::cout << "Congratulations, The orc has won the game" << std::endl;
			winTheGame = true;
		}
		
	}
	//function to cast a spell
	void castSpell()
	{
		//the function operates if the enemies life is more than zero
		//and the the enmey is not defending 
		if ((trollDefending == false) && (trollLife > 0))
		{
			trollLife = trollLife - spellDamage;//allows damage to be taken from the orcs life 
			//message is printed 
			
			std::cout << "The Orc has cast a spell" << std::endl << "You have inflicted moderate damage on your enemy" << std::endl;
			std::cout 	<< "Troll Health = " << trollLife << std::endl;
		}
		
	}
	//function to melee attack
	void melee()
	{
		//the function operates if the enemies life is more than zero
		//and the the enmey is not defending 
		if ((trollDefending == false) && (trollLife > 0))
		{
			trollLife = trollLife - meleeDamage;//allows damage to be taken from the orcs life 
			//message is printed 
			
			std::cout << "The Orc has used its weapon" << std::endl << "You have inflicted maximum damage on your enemy" << std::endl;
			std::cout << "Troll Health = " << trollLife << std::endl;
		}
	}
	//function to defend 
	void shield()
	{
		//the function operates if the enemies life is more than zero
		//and the the enmey is not defending 
		if ((trollDefending == false) && (trollLife > 0))
		{
			orcLife = orcLife + 3;//adds to the orcs life
			trollLife = trollLife - shieldDamage;//allows damage to be taken from the orcs life 
			//message is printed 
			
			std::cout << "The Orc has used a shield" << std::endl << "You have successfully defended the trolls attack" << std::endl
				<< "You have regained health, Orc Health = " << orcLife << std::endl;
			std::cout << "The Troll has fatigued and lost health." << std::endl << "Troll Health = " << trollLife << std::endl;
		}
		else
		{
			std::cout << "The Orc has used the shield" << std::endl << "The Troll also chose to defend your life and theirs remains unchanged"
				<< std::endl;
		}
	}
};