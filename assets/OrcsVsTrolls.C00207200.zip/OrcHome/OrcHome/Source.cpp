#include <iostream>
#include <string>
#include "Header.h"
/*Author: James Condon
  Student no: C00207200
  Dates Worked on: 12/10/16 - 6:00 - 9:00
				   13/10/16 - 2:30 - 4:00

  Total Time:
  Purpose: This is a text based player vs AI(player) game. The players alternate their turns each player has a life bar 
  they are given a option of three moves cast aspell, melee or use their shield. it wors that each weapon has an advantage 
  on the other shield beats melee, melee beats spell, spell beats shield. The game operates using polymorphism and inheritence
  and pointers. There is a character class and two classes which inherit the variables of the parent. also pointers are used?
*/
int main()
{
	//objects
	Troll troll;
	Orc orc;
	Character* pTroll = &troll;
	Character* pOrc = &orc;
	
	bool playerOnesTurn = true;//turn of player one
	bool playerTwosTurn = false;//turn of player 2
	bool playing = true;
	bool inGame = true;
	std::string replay = "";
	int intChoice;
	int fightChoice;
	//initial choice given to the user to choose to fight for either side
	std::cout << "Choose to be an Orc or a Troll: " << std::endl;
	std::cout << "1 = Orc, 2 = Troll" << std::endl;
	std::cin >> intChoice;

	//alternating choices 
	if (intChoice == 1)
	{
		std::cout << "Player 1 has chosen Orc\nPlayer 2 has chosen Troll" << std::endl;
	}
	else if (intChoice == 2)
	{
		std::cout << "Player 1 has chosen Troll\nPlayer 2 has chosen Orc" << std::endl;
	}
	while (playing)
	{
		
			//if player one chooses the orc 
			if ((playerOnesTurn == true) && (intChoice == 1))
			{
				std::cout << "Its player 1's turn: \n" << std::endl << "Cast a Spell = 1\nMelee Attack = 2\nUse your Shield = 1\n" << std::endl;
				std::cin >> fightChoice;

				//each method sets its bools to true or false 
				//allowing the alternation of turns 
				if (fightChoice == 1)
				{
					orc.castSpell();
					orc.winGame();
					orc.minusTroll();
					pOrc->resetLife(20);
					if (orc.winTheGame)
					{
						break;
					}
					playerOnesTurn = false;
					playerTwosTurn = true;
				}
				else if (fightChoice == 2)
				{
					orc.melee();
					orc.winGame();
					orc.minusTroll();
					pOrc->resetLife(20);
					if (orc.winTheGame)
					{
						break;
					}
					playerOnesTurn = false;
					playerTwosTurn = true;
				}
				else if (fightChoice == 3)
				{
					orc.shield();
					orc.winGame();
					orc.minusTroll();
					pOrc->resetLife(20);
					if (orc.winTheGame)
					{
						break;
					}
					playerOnesTurn = false;
					playerTwosTurn = true;
				}
				else//if their is an incorrect input 
				{
					std::cout << "That is not a valid choice choose again" << std::endl;
					std::cin >> fightChoice;
				}
				


			}
			//if the player chooses the second option
			else if ((playerOnesTurn == true) && (intChoice == 2))
			{
				std::cout << "Its player 1's turn: \n" << std::endl << "Cast a Spell = 1\nMelee Attack = 2\nUse your Shield = 1\n" << std::endl;
				std::cin >> fightChoice;
				//fight choice to cast a spell
				if (fightChoice == 1)
				{
					troll.castSpell();
					troll.winGame();
					troll.minusOrc();
					pTroll->resetLife(20);
					if (troll.winTheGame)
					{
						break;
					}
					playerOnesTurn = false;
					playerTwosTurn = true;
				}
				//function call to melee attack
				else if (fightChoice == 2)
				{
					troll.melee();
					troll.winGame();
					troll.minusOrc();
					pTroll->resetLife(20);
					if (troll.winTheGame)
					{
						break;
					}
					playerOnesTurn = false;
					playerTwosTurn = true;
				}
				//function call to defend 
				else if (fightChoice == 3)
				{
					troll.shield();
					troll.winGame(); 
					troll.minusOrc();
					pTroll->resetLife(20);
					if (troll.winTheGame)
					{
						break;
					}
					playerOnesTurn = false;
					playerTwosTurn = true;
				}
				else//if their is an incorrect input 
				{
					std::cout << "That is not a valid choice choose again" << std::endl;
					std::cin >> fightChoice;
				}
				
			}
			//if the second player is an orc 
			else if ((playerTwosTurn == true) && (intChoice == 1))
			{
				std::cout << "Its player 2's turn: \n" << std::endl << "Cast a Spell = 1\nMelee Attack = 2\nUse your Shield = 3\n" << std::endl;
				std::cin >> fightChoice;
				//function call to cast a spell
				if (fightChoice == 1)
				{
					troll.castSpell();
					troll.winGame();
					troll.minusOrc();
					pTroll->resetLife(20);
					if (troll.winTheGame)
					{
						break;
					}
					playerOnesTurn = true;
					playerTwosTurn = false;
				}
				//function call to melee attack
				else if (fightChoice == 2)
				{
					troll.melee();
					troll.winGame();
					troll.minusOrc();
					pTroll->resetLife(20);
					if (troll.winTheGame)
					{
						break;
					}
					playerOnesTurn = true;
					playerTwosTurn = false;
				}
				//function call to defend against the enemy
				else if (fightChoice == 3)
				{
					troll.shield();
					troll.winGame();
					troll.minusOrc();
					pTroll->resetLife(20);
					if (troll.winTheGame)
					{
						break;
					}
					playerOnesTurn = true;
					playerTwosTurn = false;
				}
				else//incorrect input
				{
					std::cout << "That is not a valid choice choose again" << std::endl;
					std::cin >> fightChoice;
				}
				

			}
			//if the second player chooses the troll
			else if ((playerTwosTurn == true) && (intChoice == 2))
			{
				//gives the player their option of moves 
				std::cout << "Its player 2's turn: \n" << std::endl << "Cast a Spell = 1\nMelee Attack = 2\nUse your Shield = 3\n" << std::endl;
				std::cin >> fightChoice;

				if (fightChoice == 1)
				{
					orc.castSpell();
					orc.winGame();
					orc.minusTroll();
					pOrc->resetLife(20);
					if (orc.winTheGame)
					{
						break;
					}
					playerOnesTurn = true;
					playerTwosTurn = false;
				}
				else if (fightChoice == 2)
				{
					orc.melee();
					orc.winGame();
					orc.minusTroll();
					pOrc->resetLife(20);
					if (orc.winTheGame)
					{
						break;
					}
					playerOnesTurn = true;
					playerTwosTurn = false;
				}
				else if (fightChoice == 3)
				{
					orc.shield();
					orc.winGame();
					orc.minusTroll();
					pOrc->resetLife(20);
					if (orc.winTheGame)
					{
						break;
					}
					playerOnesTurn = true;
					playerTwosTurn = false;
				}
				else
				{
					std::cout << "That is not a valid choice choose again" << std::endl;
					std::cin >> fightChoice;
				}
				

			}
			
		
		

	}
	
		
	
	system("pause");
}